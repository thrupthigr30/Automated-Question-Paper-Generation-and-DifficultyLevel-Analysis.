import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AppLayout } from './layouts/AppLayout';
import { LoginPage } from './features/auth/LoginPage';
import { RegisterPage } from './features/auth/RegisterPage';
import { DashboardPage } from './features/dashboard/DashboardPage';
import { SubjectsPage } from './features/subjects/SubjectsPage';
import { DocumentsPage } from './features/documents/DocumentsPage';
import { QuestionBankPage } from './features/questions/QuestionBankPage';
import { GenerateQuestionsPage } from './features/generation/GenerateQuestionsPage';
import { PYQAnalysisPage } from './features/pyq/PYQAnalysisPage';
import { DatasetsPage } from './features/datasets/DatasetsPage';
import { ExaminationsPage } from './features/examinations/ExaminationsPage';
import { AssessmentsPage } from './features/assessments/AssessmentsPage';
import { DifficultyPage } from './features/difficulty/DifficultyPage';
import { PerformancePage } from './features/performance/PerformancePage';
import { ReportsPage } from './features/reports/ReportsPage';
import { SettingsPage } from './features/settings/SettingsPage';

// Protected Route Wrapper
const ProtectedRoute: React.FC<{ children: React.ReactElement }> = ({ children }) => {
  const token = localStorage.getItem('token') || localStorage.getItem('hacverse_token');
  if (!token) {
    return <Navigate to="/login" replace />;
  }
  return children;
};

export const App: React.FC = () => {
  return (
    <BrowserRouter>
      <Routes>
        {/* Public Auth Routes */}
        <Route path="/login" element={<LoginPage />} />
        <Route path="/register" element={<RegisterPage />} />

        {/* Protected App Routes */}
        <Route
          element={
            <ProtectedRoute>
              <AppLayout />
            </ProtectedRoute>
          }
        >
          <Route path="/" element={<Navigate to="/dashboard" replace />} />
          <Route path="/dashboard" element={<DashboardPage />} />
          <Route path="/subjects" element={<SubjectsPage />} />
          <Route path="/documents" element={<DocumentsPage />} />
          <Route path="/questions" element={<QuestionBankPage />} />
          <Route path="/generate" element={<GenerateQuestionsPage />} />
          <Route path="/pyq" element={<PYQAnalysisPage />} />
          <Route path="/datasets" element={<DatasetsPage />} />
          <Route path="/examinations" element={<ExaminationsPage />} />
          <Route path="/assessments" element={<AssessmentsPage />} />
          <Route path="/difficulty" element={<DifficultyPage />} />
          <Route path="/calibration" element={<DifficultyPage />} />
          <Route path="/performance" element={<PerformancePage />} />
          <Route path="/reports" element={<ReportsPage />} />
          <Route path="/settings" element={<SettingsPage />} />
        </Route>

        {/* Catch-all */}
        <Route path="*" element={<Navigate to="/dashboard" replace />} />
      </Routes>
    </BrowserRouter>
  );
};

export default App;
