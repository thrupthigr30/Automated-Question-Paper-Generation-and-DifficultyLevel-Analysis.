import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardContent } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { Badge } from '../../components/ui/Badge';
import { examinationsApi, pdfApi } from '../../services/api';
import { Examination } from '../../types';
import {
  FileText,
  Download,
  Award,
  Layers,
  Sliders,
  CheckCircle2,
  BookOpen,
  PieChart
} from 'lucide-react';

export const ReportsPage: React.FC = () => {
  const [exams, setExams] = useState<Examination[]>([]);
  const [selectedExamId, setSelectedExamId] = useState<number | ''>('');
  const [loading, setLoading] = useState<boolean>(true);
  const [downloading, setDownloading] = useState<string | null>(null);

  useEffect(() => {
    fetchExams();
  }, []);

  const fetchExams = async () => {
    try {
      setLoading(true);
      const res = await examinationsApi.list();
      setExams(res.data);
      if (res.data.length > 0) {
        setSelectedExamId(res.data[0].id);
      }
    } catch (err) {
      console.error('Error fetching exams:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleDownload = async (type: 'paper' | 'key' | 'report') => {
    if (!selectedExamId) return;
    try {
      setDownloading(type);
      let res;
      if (type === 'paper') res = await pdfApi.downloadQuestionPaper(Number(selectedExamId));
      else if (type === 'key') res = await pdfApi.downloadAnswerKey(Number(selectedExamId));
      else res = await pdfApi.downloadAnalysisReport(Number(selectedExamId));

      const blob = new Blob([res.data], { type: 'application/pdf' });
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `HACVERSE_Exam_${selectedExamId}_${type}.pdf`);
      document.body.appendChild(link);
      link.click();
      link.remove();
    } catch (err) {
      console.error('Failed to download PDF report:', err);
      alert('Error generating ReportLab PDF document.');
    } finally {
      setDownloading(null);
    }
  };

  const selectedExam = exams.find((e) => e.id === Number(selectedExamId));

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-slate-900">
          Official Examination PDF Documents & Reports
        </h1>
        <p className="text-sm text-slate-500">
          Publication-ready PDF generation powered by ReportLab: student papers, official marking schemes, and psychometric calibration reports.
        </p>
      </div>

      {/* Select Examination */}
      <Card className="p-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <label className="text-sm font-semibold text-slate-700">Target Examination:</label>
            <select
              value={selectedExamId}
              onChange={(e) => setSelectedExamId(e.target.value ? Number(e.target.value) : '')}
              className="text-sm border border-slate-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 min-w-[280px]"
            >
              {exams.map((ex) => (
                <option key={ex.id} value={ex.id}>
                  {ex.title} ({ex.subject?.name})
                </option>
              ))}
            </select>
          </div>

          {selectedExam && (
            <div className="flex items-center gap-3 text-xs text-slate-500">
              <span>{selectedExam.total_marks} Marks</span>
              <span>•</span>
              <span>{selectedExam.duration_minutes} Mins</span>
              <span>•</span>
              <Badge variant={selectedExam.status === 'PUBLISHED' ? 'success' : 'secondary'}>
                {selectedExam.status}
              </Badge>
            </div>
          )}
        </div>
      </Card>

      {/* 3 Report Types */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Document 1: Student Question Paper */}
        <Card className="p-6 flex flex-col justify-between hover:border-blue-300 transition-colors">
          <div className="space-y-4">
            <div className="w-12 h-12 bg-blue-50 text-blue-600 rounded-lg flex items-center justify-center">
              <FileText className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">Student Question Paper</h3>
              <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                Standard university examination paper with institutional header, candidate instructions, sectioned questions, and allocated marks. Does not disclose answers.
              </p>
            </div>
          </div>
          <div className="pt-6">
            <Button
              className="w-full justify-center bg-blue-600 hover:bg-blue-700"
              disabled={!selectedExamId || downloading === 'paper'}
              onClick={() => handleDownload('paper')}
            >
              <Download className="w-4 h-4 mr-2" />
              {downloading === 'paper' ? 'Building PDF...' : 'Download Question Paper'}
            </Button>
          </div>
        </Card>

        {/* Document 2: Official Answer Key */}
        <Card className="p-6 flex flex-col justify-between hover:border-emerald-300 transition-colors">
          <div className="space-y-4">
            <div className="w-12 h-12 bg-emerald-50 text-emerald-600 rounded-lg flex items-center justify-center">
              <CheckCircle2 className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">Marking Scheme & Solutions</h3>
              <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                Faculty grading reference containing verified answer keys, step-by-step mathematical solutions, scoring rubrics, and conceptual explanations.
              </p>
            </div>
          </div>
          <div className="pt-6">
            <Button
              className="w-full justify-center bg-emerald-600 hover:bg-emerald-700"
              disabled={!selectedExamId || downloading === 'key'}
              onClick={() => handleDownload('key')}
            >
              <Download className="w-4 h-4 mr-2" />
              {downloading === 'key' ? 'Building PDF...' : 'Download Answer Key'}
            </Button>
          </div>
        </Card>

        {/* Document 3: Psychometric Difficulty Analysis */}
        <Card className="p-6 flex flex-col justify-between hover:border-purple-300 transition-colors">
          <div className="space-y-4">
            <div className="w-12 h-12 bg-purple-50 text-purple-600 rounded-lg flex items-center justify-center">
              <PieChart className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">Psychometric Calibration Report</h3>
              <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                Item-level psychometric breakdown displaying 6 cognitive dimensions, AI predictions vs Wilson 95% confidence intervals, and syllabus coverage audits.
              </p>
            </div>
          </div>
          <div className="pt-6">
            <Button
              className="w-full justify-center bg-purple-600 hover:bg-purple-700"
              disabled={!selectedExamId || downloading === 'report'}
              onClick={() => handleDownload('report')}
            >
              <Download className="w-4 h-4 mr-2" />
              {downloading === 'report' ? 'Building PDF...' : 'Download Analysis Report'}
            </Button>
          </div>
        </Card>
      </div>
    </div>
  );
};
