import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardContent } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { Badge } from '../../components/ui/Badge';
import { Modal } from '../../components/ui/Modal';
import { Input } from '../../components/ui/Input';
import { assessmentsApi, examinationsApi } from '../../services/api';
import { Examination, Assessment, StudentResponse } from '../../types';
import {
  Clock,
  CheckCircle2,
  AlertCircle,
  Play,
  ArrowRight,
  ArrowLeft,
  Award,
  BookOpen,
  Send,
  UserCheck
} from 'lucide-react';

export const AssessmentsPage: React.FC = () => {
  const [exams, setExams] = useState<Examination[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  // Active Assessment Taking Mode
  const [activeExam, setActiveExam] = useState<Examination | null>(null);
  const [activeAssessment, setActiveAssessment] = useState<Assessment | null>(null);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState<number>(0);
  const [studentAnswers, setStudentAnswers] = useState<Record<number, string>>({});
  const [submitting, setSubmitting] = useState<boolean>(false);
  const [assessmentResult, setAssessmentResult] = useState<any>(null);

  useEffect(() => {
    fetchExams();
  }, []);

  const fetchExams = async () => {
    try {
      setLoading(true);
      const res = await examinationsApi.list();
      setExams(res.data.filter((e) => e.status === 'PUBLISHED'));
    } catch (err) {
      console.error('Error fetching available exams:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleStartExam = async (exam: Examination) => {
    try {
      setLoading(true);
      const res = await assessmentsApi.start({ examination_id: exam.id });
      setActiveExam(exam);
      setActiveAssessment(res.data);
      setCurrentQuestionIndex(0);
      setStudentAnswers({});
      setAssessmentResult(null);
    } catch (err: any) {
      alert(err.response?.data?.detail || 'Failed to start examination session');
    } finally {
      setLoading(false);
    }
  };

  const handleAnswerChange = (questionId: number, answer: string) => {
    setStudentAnswers((prev) => ({
      ...prev,
      [questionId]: answer,
    }));
  };

  const handleSubmitAssessment = async () => {
    if (!activeAssessment || !activeExam) return;
    if (!confirm('Are you ready to submit your examination? Objective answers will be auto-evaluated.')) return;

    try {
      setSubmitting(true);
      const questions = activeExam.questions || [];
      const responses = questions.map((eq: any) => {
        const q = eq.question || eq;
        return {
          question_id: q.id,
          response_text: studentAnswers[q.id] || '',
          time_spent_seconds: 60,
        };
      });

      const res = await assessmentsApi.submit(activeAssessment.id, { responses });
      setAssessmentResult(res.data);
    } catch (err: any) {
      alert(err.response?.data?.detail || 'Failed to submit assessment responses');
    } finally {
      setSubmitting(false);
    }
  };

  // If in results mode
  if (assessmentResult) {
    return (
      <div className="max-w-3xl mx-auto space-y-6">
        <Card className="p-8 text-center space-y-4">
          <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto">
            <Award className="w-8 h-8" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-slate-900">Assessment Submitted Successfully</h2>
            <p className="text-sm text-slate-500 mt-1">
              Your responses have been logged to the Student Performance Dataset and will contribute to item difficulty calibration.
            </p>
          </div>

          <div className="grid grid-cols-3 gap-4 max-w-md mx-auto p-4 bg-slate-50 rounded-lg border border-slate-200">
            <div>
              <div className="text-xs text-slate-500">Score Awarded</div>
              <div className="text-xl font-bold text-slate-900">
                {assessmentResult.score_awarded?.toFixed(1) || 0} / {assessmentResult.total_marks || 0}
              </div>
            </div>
            <div>
              <div className="text-xs text-slate-500">Percentage</div>
              <div className="text-xl font-bold text-emerald-600">
                {assessmentResult.total_marks
                  ? ((assessmentResult.score_awarded / assessmentResult.total_marks) * 100).toFixed(1)
                  : 0}%
              </div>
            </div>
            <div>
              <div className="text-xs text-slate-500">Evaluated Items</div>
              <div className="text-xl font-bold text-blue-600">
                {assessmentResult.responses?.length || 0}
              </div>
            </div>
          </div>

          <Button
            onClick={() => {
              setActiveExam(null);
              setActiveAssessment(null);
              setAssessmentResult(null);
              fetchExams();
            }}
          >
            Return to Assessments
          </Button>
        </Card>
      </div>
    );
  }

  // If currently taking an exam
  if (activeExam && activeAssessment) {
    const questions = activeExam.questions || [];
    const currentQWrapper = questions[currentQuestionIndex];
    const currentQuestion = currentQWrapper?.question || currentQWrapper;

    return (
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header Bar */}
        <div className="flex flex-wrap items-center justify-between gap-4 bg-white p-4 rounded-lg border border-slate-200">
          <div>
            <h2 className="text-base font-bold text-slate-900">{activeExam.title}</h2>
            <p className="text-xs text-slate-500">{activeExam.subject?.name} • Total Marks: {activeExam.total_marks}</p>
          </div>
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1.5 text-xs font-mono bg-slate-100 px-3 py-1.5 rounded text-slate-700">
              <Clock className="w-3.5 h-3.5 text-blue-600" />
              <span>{activeExam.duration_minutes} Minutes Allowed</span>
            </div>
            <Button
              variant="default"
              size="sm"
              onClick={handleSubmitAssessment}
              disabled={submitting}
              className="bg-emerald-600 hover:bg-emerald-700"
            >
              <Send className="w-3.5 h-3.5 mr-1.5" />
              {submitting ? 'Submitting...' : 'Submit Assessment'}
            </Button>
          </div>
        </div>

        {/* Question Item Navigator */}
        <div className="flex flex-wrap gap-2 bg-white p-3 rounded-lg border border-slate-200">
          {questions.map((qW: any, idx: number) => {
            const q = qW.question || qW;
            const isAnswered = !!studentAnswers[q.id];
            const isCurrent = idx === currentQuestionIndex;
            return (
              <button
                key={idx}
                onClick={() => setCurrentQuestionIndex(idx)}
                className={`w-8 h-8 rounded text-xs font-bold transition-all ${
                  isCurrent
                    ? 'bg-blue-600 text-white ring-2 ring-blue-300'
                    : isAnswered
                    ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                {idx + 1}
              </button>
            );
          })}
        </div>

        {/* Current Question Body */}
        {currentQuestion && (
          <Card className="p-6 space-y-6">
            <div className="flex justify-between items-center pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <span className="font-bold text-slate-900 text-base">
                  Question {currentQuestionIndex + 1} of {questions.length}
                </span>
                <Badge variant="outline">{currentQuestion.question_type}</Badge>
              </div>
              <span className="text-xs font-semibold text-slate-600">
                {currentQuestion.marks} Marks
              </span>
            </div>

            <div className="text-base font-medium text-slate-900 leading-relaxed">
              {currentQuestion.question_text}
            </div>

            {/* Response Input based on Type */}
            <div className="space-y-3 pt-2">
              {currentQuestion.question_type === 'MCQ' && currentQuestion.options && Array.isArray(currentQuestion.options) && (
                <div className="grid grid-cols-1 gap-2.5">
                  {currentQuestion.options.map((opt: any, optIdx: number) => {
                    const text = typeof opt === 'object' && opt ? (opt.text || opt.label || JSON.stringify(opt)) : String(opt);
                    const label = typeof opt === 'object' && opt && opt.label ? opt.label : String.fromCharCode(65 + optIdx);
                    const isSelected = studentAnswers[currentQuestion.id] === text || studentAnswers[currentQuestion.id] === label;
                    return (
                      <label
                        key={optIdx}
                        className={`p-3 rounded-lg border cursor-pointer text-sm flex items-center gap-3 transition-colors ${
                          isSelected
                            ? 'bg-blue-50 border-blue-400 font-medium text-blue-900'
                            : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                        }`}
                      >
                        <input
                          type="radio"
                          name={`q_${currentQuestion.id}`}
                          value={text}
                          checked={isSelected}
                          onChange={() => handleAnswerChange(currentQuestion.id, text)}
                          className="accent-blue-600"
                        />
                        <span className="font-bold font-mono text-xs w-4">
                          {label}.
                        </span>
                        <span>{text}</span>
                      </label>
                    );
                  })}
                </div>
              )}

              {currentQuestion.question_type === 'TRUE_FALSE' && (
                <div className="flex gap-4">
                  {['True', 'False'].map((opt) => {
                    const isSelected = studentAnswers[currentQuestion.id] === opt;
                    return (
                      <label
                        key={opt}
                        className={`px-6 py-3 rounded-lg border cursor-pointer text-sm flex items-center gap-3 transition-colors ${
                          isSelected
                            ? 'bg-blue-50 border-blue-400 font-medium text-blue-900'
                            : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                        }`}
                      >
                        <input
                          type="radio"
                          name={`q_${currentQuestion.id}`}
                          value={opt}
                          checked={isSelected}
                          onChange={() => handleAnswerChange(currentQuestion.id, opt)}
                          className="accent-blue-600"
                        />
                        <span>{opt}</span>
                      </label>
                    );
                  })}
                </div>
              )}

              {currentQuestion.question_type === 'NUMERICAL' && (
                <div>
                  <label className="block text-xs font-semibold uppercase text-slate-500 mb-1">
                    Your Numerical Answer:
                  </label>
                  <Input
                    type="number"
                    step="any"
                    value={studentAnswers[currentQuestion.id] || ''}
                    onChange={(e) => handleAnswerChange(currentQuestion.id, e.target.value)}
                    placeholder="Enter calculated numerical value..."
                    className="max-w-xs"
                  />
                </div>
              )}

              {currentQuestion.question_type === 'FILL_IN_BLANK' && (
                <div>
                  <label className="block text-xs font-semibold uppercase text-slate-500 mb-1">
                    Your Answer:
                  </label>
                  <Input
                    type="text"
                    value={studentAnswers[currentQuestion.id] || ''}
                    onChange={(e) => handleAnswerChange(currentQuestion.id, e.target.value)}
                    placeholder="Type the missing keyword or phrase..."
                    className="max-w-md"
                  />
                </div>
              )}

              {(currentQuestion.question_type === 'SHORT_ANSWER' || currentQuestion.question_type === 'LONG_ANSWER') && (
                <div>
                  <label className="block text-xs font-semibold uppercase text-slate-500 mb-1">
                    Your Descriptive Solution:
                  </label>
                  <textarea
                    rows={5}
                    value={studentAnswers[currentQuestion.id] || ''}
                    onChange={(e) => handleAnswerChange(currentQuestion.id, e.target.value)}
                    placeholder="Type detailed theoretical explanation, algorithm or proof..."
                    className="w-full text-sm border border-slate-300 rounded-md p-3 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              )}
            </div>

            {/* Navigation buttons */}
            <div className="flex justify-between items-center pt-4 border-t border-slate-100">
              <Button
                variant="outline"
                disabled={currentQuestionIndex === 0}
                onClick={() => setCurrentQuestionIndex((prev) => prev - 1)}
              >
                <ArrowLeft className="w-4 h-4 mr-1.5" /> Previous
              </Button>

              {currentQuestionIndex < questions.length - 1 ? (
                <Button
                  variant="default"
                  onClick={() => setCurrentQuestionIndex((prev) => prev + 1)}
                >
                  Next <ArrowRight className="w-4 h-4 ml-1.5" />
                </Button>
              ) : (
                <Button
                  variant="default"
                  onClick={handleSubmitAssessment}
                  className="bg-emerald-600 hover:bg-emerald-700"
                >
                  Finish & Submit <Send className="w-4 h-4 ml-1.5" />
                </Button>
              )}
            </div>
          </Card>
        )}
      </div>
    );
  }

  // Normal Examination Available Listing
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-slate-900">
          Student Assessments
        </h1>
        <p className="text-sm text-slate-500">
          Live testing environment collecting authentic empirical response data to validate and calibrate question difficulty.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {loading ? (
          <div className="col-span-full py-12 text-center text-slate-400">Loading assessments...</div>
        ) : exams.length === 0 ? (
          <div className="col-span-full py-12 text-center text-slate-500 bg-white rounded-lg border border-slate-200">
            No published examinations currently available for testing. Teachers can publish exams in the Examinations tab.
          </div>
        ) : (
          exams.map((ex) => (
            <Card key={ex.id} className="p-5 flex flex-col justify-between hover:border-slate-300 transition-colors">
              <div className="space-y-3">
                <div className="flex justify-between items-start">
                  <Badge variant="outline">{ex.subject?.name || 'General'}</Badge>
                  <div className="flex items-center gap-1 text-xs text-slate-400">
                    <Clock className="w-3.5 h-3.5" />
                    <span>{ex.duration_minutes}m</span>
                  </div>
                </div>

                <div>
                  <h3 className="font-semibold text-slate-900 text-base">{ex.title}</h3>
                  <p className="text-xs text-slate-500 mt-1">
                    {ex.questions?.length || 0} questions • Total Marks: {ex.total_marks}
                  </p>
                </div>
              </div>

              <div className="pt-4 border-t border-slate-100 mt-4">
                <Button
                  className="w-full justify-center"
                  onClick={() => handleStartExam(ex)}
                >
                  <Play className="w-4 h-4 mr-2" /> Start Assessment
                </Button>
              </div>
            </Card>
          ))
        )}
      </div>
    </div>
  );
};
