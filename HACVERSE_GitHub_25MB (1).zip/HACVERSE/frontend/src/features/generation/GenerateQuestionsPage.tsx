import React, { useState, useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { Card, CardHeader, CardContent } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { Badge } from '../../components/ui/Badge';
import { Input } from '../../components/ui/Input';
import { questionsApi, subjectsApi, documentsApi } from '../../services/api';
import { Subject, Unit, Topic, Question, Document } from '../../types';
import {
  Sparkles,
  Sliders,
  CheckCircle2,
  AlertCircle,
  Save,
  Trash2,
  Layers,
  HelpCircle,
  Cpu,
  ArrowRight,
  FileText,
  Files,
  CheckSquare,
  Square
} from 'lucide-react';

export const GenerateQuestionsPage: React.FC = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [subjectDocuments, setSubjectDocuments] = useState<Document[]>([]);
  const [loadingInitial, setLoadingInitial] = useState<boolean>(true);

  // Form State
  const [subjectId, setSubjectId] = useState<number | ''>('');
  const [unitId, setUnitId] = useState<number | ''>('');
  const [topicId, setTopicId] = useState<number | ''>('');
  const [selectedDocIds, setSelectedDocIds] = useState<number[]>([]);
  const [questionTypes, setQuestionTypes] = useState<string[]>(['MCQ']);
  const [targetDifficulty, setTargetDifficulty] = useState<string>('MEDIUM');
  const [bloomsLevel, setBloomsLevel] = useState<string>('APPLY');
  const [count, setCount] = useState<number>(3);
  const [customInstructions, setCustomInstructions] = useState<string>('');

  // Generation status & results
  const [generating, setGenerating] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [generatedQuestions, setGeneratedQuestions] = useState<Question[]>([]);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  useEffect(() => {
    fetchInitialData();
  }, []);

  const fetchInitialData = async () => {
    try {
      setLoadingInitial(true);
      const res = await subjectsApi.list();
      setSubjects(res.data);

      const paramSubjectId = searchParams.get('subject_id');
      const paramDocIds = searchParams.get('doc_ids');

      let targetSubId: number | '' = '';
      if (paramSubjectId) {
        targetSubId = Number(paramSubjectId);
      } else if (res.data.length > 0) {
        targetSubId = res.data[0].id;
      }

      setSubjectId(targetSubId);

      if (targetSubId) {
        await loadDocumentsForSubject(targetSubId);
      }

      if (paramDocIds) {
        const ids = paramDocIds.split(',').map((id) => Number(id.trim())).filter(Boolean);
        setSelectedDocIds(ids);
      }
    } catch (err) {
      console.error('Error fetching initial generation data:', err);
    } finally {
      setLoadingInitial(false);
    }
  };

  const loadDocumentsForSubject = async (sId: number) => {
    try {
      const res = await documentsApi.list(sId);
      setSubjectDocuments(res.data || []);
    } catch (err) {
      console.error('Error fetching documents for subject:', err);
      setSubjectDocuments([]);
    }
  };

  const handleSubjectChange = async (newId: number | '') => {
    setSubjectId(newId);
    setUnitId('');
    setTopicId('');
    setSelectedDocIds([]);
    if (newId) {
      await loadDocumentsForSubject(Number(newId));
    } else {
      setSubjectDocuments([]);
    }
  };

  const toggleDocSelection = (docId: number) => {
    if (selectedDocIds.includes(docId)) {
      setSelectedDocIds(selectedDocIds.filter((id) => id !== docId));
    } else {
      setSelectedDocIds([...selectedDocIds, docId]);
    }
  };

  const selectAllDocs = () => {
    if (selectedDocIds.length === subjectDocuments.length) {
      setSelectedDocIds([]);
    } else {
      setSelectedDocIds(subjectDocuments.map((d) => d.id));
    }
  };

  const selectedSubject = subjects.find((s) => s.id === Number(subjectId));
  const units: Unit[] = selectedSubject?.units || [];
  const selectedUnit = units.find((u) => u.id === Number(unitId));
  const topics: Topic[] = selectedUnit?.topics || [];

  const handleTypeToggle = (type: string) => {
    if (questionTypes.includes(type)) {
      if (questionTypes.length > 1) {
        setQuestionTypes(questionTypes.filter((t) => t !== type));
      }
    } else {
      setQuestionTypes([...questionTypes, type]);
    }
  };

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!subjectId) {
      setError('Please select a subject.');
      return;
    }

    try {
      setGenerating(true);
      setError(null);
      setSuccessMessage(null);

      const payload = {
        subject_id: Number(subjectId),
        unit_id: unitId ? Number(unitId) : undefined,
        topic_id: topicId ? Number(topicId) : undefined,
        document_ids: selectedDocIds.length > 0 ? selectedDocIds : undefined,
        question_types: questionTypes,
        target_difficulty: targetDifficulty,
        blooms_level: bloomsLevel,
        count: Number(count),
        custom_instructions: customInstructions || undefined,
      };

      const res = await questionsApi.generate(payload);
      const qList = Array.isArray(res.data) ? res.data : (res.data?.questions || []);
      setGeneratedQuestions(qList);
      setSuccessMessage(
        `Generated ${qList.length} questions grounded on ${
          selectedDocIds.length > 0 ? `${selectedDocIds.length} chosen documents` : 'uploaded syllabus materials'
        } with cold-start cognitive difficulty scores.`
      );
    } catch (err: any) {
      setError(err.response?.data?.detail || 'Failed to generate questions. Ensure academic materials or active AI provider are properly configured.');
    } finally {
      setGenerating(false);
    }
  };

  const handleDiscard = (idx: number) => {
    setGeneratedQuestions(generatedQuestions.filter((_, i) => i !== idx));
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-slate-900">
          Document-Grounded Question Generation
        </h1>
        <p className="text-sm text-slate-500">
          Upload and select multiple academic resources (textbooks, lecture notes, syllabi) to generate syllabus-grounded questions.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Form: Configuration */}
        <div className="lg:col-span-5 space-y-6">
          <Card>
            <CardHeader className="border-b border-slate-100 pb-3">
              <h2 className="font-semibold text-slate-900 flex items-center gap-2 text-sm">
                <Sliders className="w-4 h-4 text-blue-600" />
                Generation Parameters
              </h2>
            </CardHeader>
            <CardContent className="pt-4">
              <form onSubmit={handleGenerate} className="space-y-4">
                {error && (
                  <div className="p-3 bg-red-50 text-red-700 text-xs rounded border border-red-200 flex items-start gap-2">
                    <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                    <span>{error}</span>
                  </div>
                )}

                {/* Subject */}
                <div>
                  <label className="block text-xs font-semibold uppercase text-slate-500 mb-1">
                    Target Subject / Course *
                  </label>
                  <select
                    value={subjectId}
                    onChange={(e) => handleSubjectChange(e.target.value ? Number(e.target.value) : '')}
                    required
                    className="w-full text-sm border border-slate-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="">Select Subject</option>
                    {subjects.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.name} ({s.code})
                      </option>
                    ))}
                  </select>
                </div>

                {/* Grounding Source Documents Checklist */}
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-2">
                  <div className="flex justify-between items-center">
                    <label className="text-xs font-bold uppercase text-slate-700 flex items-center gap-1.5">
                      <Files className="w-3.5 h-3.5 text-blue-600" />
                      Grounding Source Documents
                    </label>
                    {subjectDocuments.length > 0 && (
                      <button
                        type="button"
                        onClick={selectAllDocs}
                        className="text-[11px] text-blue-600 hover:text-blue-800 font-medium"
                      >
                        {selectedDocIds.length === subjectDocuments.length ? 'Deselect All' : 'Select All'}
                      </button>
                    )}
                  </div>

                  {subjectDocuments.length === 0 ? (
                    <div className="text-xs text-slate-500 py-2">
                      No documents uploaded for this subject yet.{' '}
                      <button
                        type="button"
                        onClick={() => navigate('/documents')}
                        className="text-blue-600 underline font-medium"
                      >
                        Upload documents now
                      </button>
                    </div>
                  ) : (
                    <div className="max-h-36 overflow-y-auto space-y-1.5 pr-1">
                      {subjectDocuments.map((doc) => {
                        const isChecked = selectedDocIds.includes(doc.id);
                        return (
                          <div
                            key={doc.id}
                            onClick={() => toggleDocSelection(doc.id)}
                            className={`p-2 rounded border text-xs flex items-center justify-between cursor-pointer transition-colors ${
                              isChecked
                                ? 'bg-blue-50/80 border-blue-400 text-blue-900 font-medium'
                                : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                            }`}
                          >
                            <div className="flex items-center gap-2 truncate">
                              <FileText className="w-3.5 h-3.5 shrink-0 text-blue-600" />
                              <span className="truncate">{doc.original_filename || doc.filename}</span>
                            </div>
                            <span className="text-[10px] text-slate-400 font-mono ml-2 shrink-0">
                              {doc.chunk_count || 0} chunks
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  )}

                  <div className="text-[10px] text-slate-400">
                    {selectedDocIds.length > 0
                      ? `Using ${selectedDocIds.length} chosen document(s) as context.`
                      : 'All documents in this subject will be used for grounding.'}
                  </div>
                </div>

                {/* Unit & Topic */}
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold uppercase text-slate-500 mb-1">
                      Unit Filter
                    </label>
                    <select
                      value={unitId}
                      onChange={(e) => {
                        setUnitId(e.target.value ? Number(e.target.value) : '');
                        setTopicId('');
                      }}
                      disabled={!subjectId}
                      className="w-full text-sm border border-slate-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:bg-slate-100"
                    >
                      <option value="">All Units</option>
                      {units.map((u) => (
                        <option key={u.id} value={u.id}>
                          Unit {u.unit_number}: {u.title}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold uppercase text-slate-500 mb-1">
                      Topic Filter
                    </label>
                    <select
                      value={topicId}
                      onChange={(e) => setTopicId(e.target.value ? Number(e.target.value) : '')}
                      disabled={!unitId}
                      className="w-full text-sm border border-slate-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:bg-slate-100"
                    >
                      <option value="">All Topics</option>
                      {topics.map((t) => (
                        <option key={t.id} value={t.id}>
                          {t.name}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Question Types */}
                <div>
                  <label className="block text-xs font-semibold uppercase text-slate-500 mb-1.5">
                    Question Formats
                  </label>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    {[
                      { id: 'MCQ', label: 'Multiple Choice (MCQ)' },
                      { id: 'TRUE_FALSE', label: 'True / False' },
                      { id: 'SHORT_ANSWER', label: 'Short Answer' },
                      { id: 'LONG_ANSWER', label: 'Long Answer' },
                      { id: 'NUMERICAL', label: 'Numerical / Problem' },
                      { id: 'FILL_IN_BLANK', label: 'Fill in Blank' },
                    ].map((type) => {
                      const active = questionTypes.includes(type.id);
                      return (
                        <button
                          type="button"
                          key={type.id}
                          onClick={() => handleTypeToggle(type.id)}
                          className={`p-2 rounded border text-left font-medium transition-colors ${
                            active
                              ? 'bg-blue-50 border-blue-400 text-blue-800'
                              : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                          }`}
                        >
                          {type.label}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Target Difficulty & Bloom's */}
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold uppercase text-slate-500 mb-1">
                      Target Difficulty
                    </label>
                    <select
                      value={targetDifficulty}
                      onChange={(e) => setTargetDifficulty(e.target.value)}
                      className="w-full text-sm border border-slate-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                      <option value="EASY">Easy</option>
                      <option value="MEDIUM">Medium</option>
                      <option value="HARD">Hard</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold uppercase text-slate-500 mb-1">
                      Bloom's Taxonomy
                    </label>
                    <select
                      value={bloomsLevel}
                      onChange={(e) => setBloomsLevel(e.target.value)}
                      className="w-full text-sm border border-slate-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                      <option value="REMEMBER">Remember</option>
                      <option value="UNDERSTAND">Understand</option>
                      <option value="APPLY">Apply</option>
                      <option value="ANALYZE">Analyze</option>
                      <option value="EVALUATE">Evaluate</option>
                      <option value="CREATE">Create</option>
                    </select>
                  </div>
                </div>

                {/* Question Count */}
                <div>
                  <label className="block text-xs font-semibold uppercase text-slate-500 mb-1">
                    Number of Questions to Generate: <span className="font-bold text-slate-900">{count}</span>
                  </label>
                  <input
                    type="range"
                    min="1"
                    max="10"
                    value={count}
                    onChange={(e) => setCount(Number(e.target.value))}
                    className="w-full accent-blue-600 cursor-pointer"
                  />
                  <div className="flex justify-between text-[10px] text-slate-400">
                    <span>1 Item</span>
                    <span>5 Items</span>
                    <span>10 Items</span>
                  </div>
                </div>

                {/* Custom Instructions */}
                <div>
                  <label className="block text-xs font-semibold uppercase text-slate-500 mb-1">
                    Focus / Instructions
                  </label>
                  <textarea
                    rows={2}
                    value={customInstructions}
                    onChange={(e) => setCustomInstructions(e.target.value)}
                    placeholder="e.g. Focus on practical algorithms, complexity proofs, or edge cases from Chapter 3..."
                    className="w-full text-sm border border-slate-300 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <Button
                  type="submit"
                  disabled={generating || !subjectId}
                  className="w-full justify-center"
                >
                  {generating ? (
                    <>
                      <Cpu className="w-4 h-4 mr-2 animate-spin" />
                      Retrieving Chunks & Generating Questions...
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4 mr-2" />
                      Generate Evidence-Grounded Questions
                    </>
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>

        {/* Right Area: Generated Results */}
        <div className="lg:col-span-7 space-y-4">
          {successMessage && (
            <div className="p-3 bg-emerald-50 text-emerald-800 text-sm rounded-lg border border-emerald-200 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>{successMessage}</span>
              </div>
              <Button
                size="sm"
                variant="outline"
                onClick={() => navigate('/questions')}
                className="bg-white text-xs"
              >
                Go to Question Bank <ArrowRight className="w-3.5 h-3.5 ml-1" />
              </Button>
            </div>
          )}

          {generatedQuestions.length === 0 && !generating && (
            <Card className="p-12 text-center text-slate-400">
              <Cpu className="w-12 h-12 mx-auto mb-3 text-slate-300" />
              <h3 className="text-base font-semibold text-slate-700">No Generated Items Yet</h3>
              <p className="text-sm max-w-md mx-auto mt-1 text-slate-500">
                Select your source documents on the left and click generate.
                Questions are synthesized directly from your uploaded materials and evaluated with 6 cognitive difficulty dimensions.
              </p>
            </Card>
          )}

          {generating && (
            <Card className="p-12 text-center space-y-4">
              <div className="inline-block p-4 bg-blue-50 rounded-full">
                <Cpu className="w-8 h-8 text-blue-600 animate-spin" />
              </div>
              <div>
                <h3 className="text-base font-semibold text-slate-800">Synthesizing Questions</h3>
                <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1">
                  1. Retrieving chunks from selected source documents<br />
                  2. Prompting generative language model<br />
                  3. Running 6-dimensional cognitive difficulty formula<br />
                  4. Storing cold-start initial estimation
                </p>
              </div>
            </Card>
          )}

          {generatedQuestions.map((q, idx) => (
            <Card key={q.id || idx} className="p-5 border-l-4 border-l-blue-600 space-y-4">
              {/* Header */}
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <Badge variant="outline">{q.question_type}</Badge>
                  <span className="text-xs font-semibold text-slate-700">{q.marks} Marks</span>
                  <span className="text-xs text-slate-400">•</span>
                  <span className="text-xs font-medium text-slate-600">Bloom's: {q.blooms_level || q.bloom_level}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Badge
                    variant={
                      (q.initial_difficulty || q.ai_difficulty_level) === 'EASY'
                        ? 'success'
                        : (q.initial_difficulty || q.ai_difficulty_level) === 'HARD'
                        ? 'danger'
                        : 'warning'
                    }
                  >
                    Cold-Start: {q.initial_difficulty || q.ai_difficulty_level || 'MEDIUM'}
                  </Badge>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleDiscard(idx)}
                    title="Remove from current review"
                  >
                    <Trash2 className="w-3.5 h-3.5 text-slate-400 hover:text-red-500" />
                  </Button>
                </div>
              </div>

              {/* Question Text */}
              <div className="text-sm font-medium text-slate-900 leading-relaxed">
                {q.question_text}
              </div>

              {/* MCQ Options */}
              {q.options && Array.isArray(q.options) && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  {q.options.map((opt: any, oIdx: number) => {
                    const text = typeof opt === 'object' && opt ? (opt.text || opt.label || JSON.stringify(opt)) : String(opt);
                    const label = typeof opt === 'object' && opt && opt.label ? opt.label : String.fromCharCode(65 + oIdx);
                    const isKey = q.correct_answer === text || q.correct_answer === label;
                    return (
                      <div
                        key={oIdx}
                        className={`p-2 rounded border flex items-center gap-2 ${
                          isKey
                            ? 'bg-emerald-50 border-emerald-300 font-medium text-emerald-900'
                            : 'bg-slate-50 border-slate-200 text-slate-700'
                        }`}
                      >
                        <span className="w-4 h-4 rounded-full bg-slate-200 text-[10px] font-bold flex items-center justify-center shrink-0">
                          {label}
                        </span>
                        <span>{text}</span>
                      </div>
                    );
                  })}
                </div>
              )}

              {/* Answer Key & Explanation */}
              <div className="text-xs space-y-1 bg-slate-50 p-3 rounded border border-slate-200">
                <div className="font-semibold text-slate-800">
                  Model Answer: <span className="text-emerald-700 font-mono">{q.correct_answer}</span>
                </div>
                {q.explanation && (
                  <p className="text-slate-600 italic">"{q.explanation}"</p>
                )}
              </div>

              {/* 6 Dimension Difficulty Metric Preview */}
              <div className="pt-2 border-t border-slate-100 flex flex-wrap items-center justify-between text-[11px] text-slate-500">
                <div className="flex gap-3">
                  <span>Conceptual: <b>{(q.conceptual_complexity || 0).toFixed(1)}/10</b></span>
                  <span>Steps: <b>{q.computational_steps || 0}</b></span>
                  <span>Analytical: <b>{(q.analytical_depth || 0).toFixed(1)}/10</b></span>
                  <span>Novelty: <b>{(q.novelty_ratio || 0).toFixed(1)}/10</b></span>
                </div>
                <div className="font-mono font-bold text-blue-600">
                  Score: {(q.difficulty_score || q.ai_difficulty_score || 0).toFixed(1)}/100
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
};
