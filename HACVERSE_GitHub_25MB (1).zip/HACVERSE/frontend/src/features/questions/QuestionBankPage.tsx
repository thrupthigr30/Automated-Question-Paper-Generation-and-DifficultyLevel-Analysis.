import React, { useState, useEffect } from 'react';
import { Card } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { Badge } from '../../components/ui/Badge';
import { Modal } from '../../components/ui/Modal';
import { Input } from '../../components/ui/Input';
import { questionsApi, subjectsApi } from '../../services/api';
import { Question, Subject } from '../../types';
import {
  Search,
  CheckCircle,
  XCircle,
  Trash2,
  Eye,
  Sliders,
  Check,
  X,
  Filter,
  Layers,
  Sparkles,
  BarChart2
} from 'lucide-react';

export const QuestionBankPage: React.FC = () => {
  const [questions, setQuestions] = useState<Question[]>([]);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  // Filters
  const [selectedSubjectId, setSelectedSubjectId] = useState<number | ''>('');
  const [selectedDifficulty, setSelectedDifficulty] = useState<string>('');
  const [selectedApproval, setSelectedApproval] = useState<string>('');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Modals
  const [previewModalOpen, setPreviewModalOpen] = useState<boolean>(false);
  const [selectedQuestion, setSelectedQuestion] = useState<Question | null>(null);

  useEffect(() => {
    fetchInitialData();
  }, []);

  const fetchInitialData = async () => {
    try {
      setLoading(true);
      const [qRes, sRes] = await Promise.all([
        questionsApi.list(),
        subjectsApi.list(),
      ]);
      const qList = Array.isArray(qRes.data) ? qRes.data : (qRes.data?.questions || []);
      setQuestions(qList);
      setSubjects(Array.isArray(sRes.data) ? sRes.data : []);
    } catch (err) {
      console.error('Error fetching questions:', err);
      setQuestions([]);
    } finally {
      setLoading(false);
    }
  };

  const handleFilter = async () => {
    try {
      setLoading(true);
      const params: any = {};
      if (selectedSubjectId) params.subject_id = selectedSubjectId;
      if (selectedDifficulty) params.difficulty = selectedDifficulty;
      if (selectedApproval) params.approval_status = selectedApproval;
      if (searchQuery) params.search = searchQuery;

      const res = await questionsApi.list(params);
      const qList = Array.isArray(res.data) ? res.data : (res.data?.questions || []);
      setQuestions(qList);
    } catch (err) {
      console.error('Error filtering questions:', err);
      setQuestions([]);
    } finally {
      setLoading(false);
    }
  };

  const handleApprove = async (id: number) => {
    try {
      await questionsApi.approve(id, { approval_status: 'APPROVED' });
      fetchInitialData();
      if (selectedQuestion?.id === id) {
        setSelectedQuestion({ ...selectedQuestion, approval_status: 'APPROVED' });
      }
    } catch (err) {
      console.error('Error approving question:', err);
    }
  };

  const handleReject = async (id: number) => {
    try {
      await questionsApi.approve(id, { approval_status: 'REJECTED' });
      fetchInitialData();
      if (selectedQuestion?.id === id) {
        setSelectedQuestion({ ...selectedQuestion, approval_status: 'REJECTED' });
      }
    } catch (err) {
      console.error('Error rejecting question:', err);
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm('Are you sure you want to delete this question?')) return;
    try {
      await questionsApi.delete(id);
      fetchInitialData();
      setPreviewModalOpen(false);
    } catch (err) {
      console.error('Error deleting question:', err);
    }
  };

  const getDifficultyBadge = (q: Question) => {
    const diff = q.calibrated_difficulty || q.initial_difficulty || 'MEDIUM';
    const isCalibrated = q.calibration_status === 'CALIBRATED';

    let variant: 'success' | 'warning' | 'danger' = 'warning';
    if (diff === 'EASY') variant = 'success';
    if (diff === 'HARD') variant = 'danger';

    return (
      <div className="flex items-center gap-1.5">
        <Badge variant={variant} className="font-semibold text-xs">
          {diff}
        </Badge>
        <span className="text-[10px] text-slate-400 font-mono">
          {isCalibrated ? 'Observed' : 'Cold-Start'}
        </span>
      </div>
    );
  };

  const getApprovalBadge = (status?: string) => {
    switch (status) {
      case 'APPROVED':
        return <Badge variant="success">Approved</Badge>;
      case 'REJECTED':
        return <Badge variant="danger">Rejected</Badge>;
      case 'FLAGGED':
        return <Badge variant="warning">Flagged</Badge>;
      default:
        return <Badge variant="secondary">Draft</Badge>;
    }
  };

  const renderOptionText = (opt: any): string => {
    if (!opt) return '';
    if (typeof opt === 'string') return opt;
    if (typeof opt === 'object') return opt.text || opt.label || JSON.stringify(opt);
    return String(opt);
  };

  const renderOptionLabel = (opt: any, idx: number): string => {
    if (typeof opt === 'object' && opt && opt.label) return opt.label;
    return String.fromCharCode(65 + idx);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">Question Bank</h1>
          <p className="text-sm text-slate-500">
            Validated item repository with separate AI-predicted and student-calibrated difficulty states.
          </p>
        </div>
        <div className="text-sm text-slate-500 font-medium">
          Total Items: <span className="text-slate-900 font-bold">{questions.length}</span>
        </div>
      </div>

      {/* Filter Bar */}
      <Card className="p-4">
        <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
            <input
              type="text"
              placeholder="Search question text..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleFilter()}
              className="w-full text-sm pl-9 pr-3 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div>
            <select
              value={selectedSubjectId}
              onChange={(e) => setSelectedSubjectId(e.target.value ? Number(e.target.value) : '')}
              className="w-full text-sm border border-slate-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="">All Subjects</option>
              {subjects.map((s) => (
                <option key={s.id} value={s.id}>{s.name}</option>
              ))}
            </select>
          </div>

          <div>
            <select
              value={selectedDifficulty}
              onChange={(e) => setSelectedDifficulty(e.target.value)}
              className="w-full text-sm border border-slate-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="">All Difficulties</option>
              <option value="EASY">Easy</option>
              <option value="MEDIUM">Medium</option>
              <option value="HARD">Hard</option>
            </select>
          </div>

          <div>
            <select
              value={selectedApproval}
              onChange={(e) => setSelectedApproval(e.target.value)}
              className="w-full text-sm border border-slate-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="">All Approval States</option>
              <option value="APPROVED">Approved</option>
              <option value="DRAFT">Draft</option>
              <option value="REJECTED">Rejected</option>
              <option value="FLAGGED">Flagged</option>
            </select>
          </div>

          <div className="flex gap-2">
            <Button variant="default" className="w-full" onClick={handleFilter}>
              <Filter className="w-4 h-4 mr-2" /> Filter
            </Button>
            <Button
              variant="outline"
              onClick={() => {
                setSelectedSubjectId('');
                setSelectedDifficulty('');
                setSelectedApproval('');
                setSearchQuery('');
                fetchInitialData();
              }}
            >
              Reset
            </Button>
          </div>
        </div>
      </Card>

      {/* Questions Table */}
      <Card>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-sm">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50/75 text-slate-600 font-semibold">
                <th className="py-3 px-4">Question Details</th>
                <th className="py-3 px-4">Type & Marks</th>
                <th className="py-3 px-4">Bloom's Level</th>
                <th className="py-3 px-4">Difficulty Lifecycle</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {loading ? (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-slate-400">Loading questions...</td>
                </tr>
              ) : questions.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-slate-500">
                    No questions found. Go to "Generate Questions" to synthesize original questions grounded on your syllabus.
                  </td>
                </tr>
              ) : (
                questions.map((q) => (
                  <tr key={q.id} className="hover:bg-slate-50 transition-colors">
                    <td className="py-3 px-4 max-w-md">
                      <div className="font-medium text-slate-900 line-clamp-2">
                        {q.question_text}
                      </div>
                      <div className="text-xs text-slate-400 mt-1 flex items-center gap-2">
                        <span>{q.subject?.name || 'General'}</span>
                        {q.topic && <span>• {q.topic.name}</span>}
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <Badge variant="outline" className="text-xs">
                        {q.question_type}
                      </Badge>
                      <div className="text-xs text-slate-400 mt-1">{q.marks} Marks</div>
                    </td>
                    <td className="py-3 px-4">
                      <span className="text-xs font-medium text-slate-700 bg-slate-100 px-2 py-0.5 rounded">
                        {q.blooms_level || q.bloom_level || 'UNDERSTAND'}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      {getDifficultyBadge(q)}
                      <div className="text-[11px] text-slate-400 mt-1">
                        Composite: {(q.difficulty_score || q.ai_difficulty_score || 0).toFixed(1)} / 100
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      {getApprovalBadge(q.approval_status)}
                    </td>
                    <td className="py-3 px-4 text-right space-x-1">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          setSelectedQuestion(q);
                          setPreviewModalOpen(true);
                        }}
                        title="View Full Details"
                      >
                        <Eye className="w-3.5 h-3.5" />
                      </Button>
                      {q.approval_status !== 'APPROVED' && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleApprove(q.id)}
                          className="text-emerald-600 hover:text-emerald-700 hover:bg-emerald-50"
                          title="Approve Question"
                        >
                          <Check className="w-3.5 h-3.5" />
                        </Button>
                      )}
                      {q.approval_status !== 'REJECTED' && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleReject(q.id)}
                          className="text-amber-600 hover:text-amber-700 hover:bg-amber-50"
                          title="Reject Question"
                        >
                          <X className="w-3.5 h-3.5" />
                        </Button>
                      )}
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={() => handleDelete(q.id)}
                        title="Delete Question"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </Button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </Card>

      {/* Question Details / Cold-Start Inspection Modal */}
      {selectedQuestion && (
        <Modal
          isOpen={previewModalOpen}
          onClose={() => setPreviewModalOpen(false)}
          title="Question Item & Difficulty Inspection"
        >
          <div className="space-y-6 max-h-[75vh] overflow-y-auto pr-1">
            {/* Header badges */}
            <div className="flex flex-wrap items-center justify-between gap-2 p-3 bg-slate-50 rounded-lg border border-slate-200">
              <div className="flex items-center gap-2">
                <Badge variant="outline">{selectedQuestion.question_type}</Badge>
                <span className="text-xs font-semibold text-slate-700">
                  {selectedQuestion.marks} Marks
                </span>
                <span className="text-xs text-slate-400">•</span>
                <span className="text-xs font-medium text-slate-700">
                  Bloom's: {selectedQuestion.blooms_level || selectedQuestion.bloom_level || 'UNDERSTAND'}
                </span>
              </div>
              <div className="flex items-center gap-2">
                {getApprovalBadge(selectedQuestion.approval_status)}
                {getDifficultyBadge(selectedQuestion)}
              </div>
            </div>

            {/* Question Text */}
            <div>
              <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-500 mb-1">
                Question Prompt
              </h4>
              <div className="text-base font-medium text-slate-900 bg-white p-3 rounded-md border border-slate-200 whitespace-pre-wrap">
                {selectedQuestion.question_text}
              </div>
            </div>

            {/* Options for MCQ */}
            {selectedQuestion.options && Array.isArray(selectedQuestion.options) && selectedQuestion.options.length > 0 && (
              <div>
                <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-500 mb-2">
                  Answer Options
                </h4>
                <div className="grid grid-cols-1 gap-2">
                  {selectedQuestion.options.map((opt: any, idx: number) => {
                    const text = renderOptionText(opt);
                    const label = renderOptionLabel(opt, idx);
                    const isCorrect =
                      selectedQuestion.correct_answer === text ||
                      selectedQuestion.correct_answer === label;
                    return (
                      <div
                        key={idx}
                        className={`p-2.5 rounded-md border text-sm flex items-center justify-between ${
                          isCorrect
                            ? 'bg-emerald-50/70 border-emerald-300 text-emerald-900 font-medium'
                            : 'bg-slate-50 border-slate-200 text-slate-700'
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          <span className="w-5 h-5 rounded-full bg-slate-200 text-slate-700 text-xs flex items-center justify-center font-bold">
                            {label}
                          </span>
                          <span>{text}</span>
                        </div>
                        {isCorrect && (
                          <Badge variant="success" className="text-[10px]">
                            Correct
                          </Badge>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Correct Answer & Explanation */}
            <div className="space-y-3">
              <div>
                <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-500 mb-1">
                  Model Answer / Key
                </h4>
                <div className="p-3 bg-emerald-50 rounded-md border border-emerald-200 text-sm font-medium text-emerald-900">
                  {selectedQuestion.correct_answer || 'No answer key provided'}
                </div>
              </div>

              {selectedQuestion.explanation && (
                <div>
                  <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-500 mb-1">
                    Pedagogical Explanation
                  </h4>
                  <div className="p-3 bg-slate-50 rounded-md border border-slate-200 text-xs text-slate-700 leading-relaxed">
                    {selectedQuestion.explanation}
                  </div>
                </div>
              )}
            </div>

            {/* 6 Cognitive Difficulty Dimensions (Cold-Start Breakdown) */}
            <div className="p-4 bg-slate-50 rounded-lg border border-slate-200 space-y-3">
              <div className="flex justify-between items-center">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                  <Sliders className="w-3.5 h-3.5 text-blue-600" />
                  6-Dimensional Cognitive Difficulty Vector
                </h4>
                <span className="text-xs font-mono font-bold text-blue-600">
                  Score: {(selectedQuestion.difficulty_score || selectedQuestion.ai_difficulty_score || 0).toFixed(1)} / 100
                </span>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                <div className="p-2 bg-white rounded border border-slate-200">
                  <div className="text-[10px] text-slate-400 uppercase">Conceptual</div>
                  <div className="text-sm font-bold text-slate-800">
                    {(selectedQuestion.conceptual_complexity || 0).toFixed(1)} <span className="text-[10px] text-slate-400">/ 10</span>
                  </div>
                </div>
                <div className="p-2 bg-white rounded border border-slate-200">
                  <div className="text-[10px] text-slate-400 uppercase">Computational</div>
                  <div className="text-sm font-bold text-slate-800">
                    {selectedQuestion.computational_steps || 0} <span className="text-[10px] text-slate-400">steps</span>
                  </div>
                </div>
                <div className="p-2 bg-white rounded border border-slate-200">
                  <div className="text-[10px] text-slate-400 uppercase">Analytical</div>
                  <div className="text-sm font-bold text-slate-800">
                    {(selectedQuestion.analytical_depth || 0).toFixed(1)} <span className="text-[10px] text-slate-400">/ 10</span>
                  </div>
                </div>
                <div className="p-2 bg-white rounded border border-slate-200">
                  <div className="text-[10px] text-slate-400 uppercase">Retrieval</div>
                  <div className="text-sm font-bold text-slate-800">
                    {(selectedQuestion.retrieval_dependency || 0).toFixed(1)} <span className="text-[10px] text-slate-400">/ 10</span>
                  </div>
                </div>
                <div className="p-2 bg-white rounded border border-slate-200">
                  <div className="text-[10px] text-slate-400 uppercase">Linguistic</div>
                  <div className="text-sm font-bold text-slate-800">
                    {(selectedQuestion.linguistic_complexity || 0).toFixed(1)} <span className="text-[10px] text-slate-400">/ 10</span>
                  </div>
                </div>
                <div className="p-2 bg-white rounded border border-slate-200">
                  <div className="text-[10px] text-slate-400 uppercase">Novelty / Transfer</div>
                  <div className="text-sm font-bold text-slate-800">
                    {(selectedQuestion.novelty_ratio || 0).toFixed(1)} <span className="text-[10px] text-slate-400">/ 10</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Performance Calibration Status */}
            <div className="p-4 bg-blue-50/50 rounded-lg border border-blue-200 space-y-2">
              <h4 className="text-xs font-bold uppercase tracking-wider text-blue-900 flex items-center gap-1.5">
                <BarChart2 className="w-3.5 h-3.5 text-blue-600" />
                Actual Student Response Evidence
              </h4>
              <div className="text-xs text-blue-800 space-y-1">
                <div>
                  Calibration Status: <span className="font-semibold">{selectedQuestion.calibration_status || 'Cold-Start (AI_ESTIMATED)'}</span>
                </div>
                {selectedQuestion.calibration_status === 'CALIBRATED' ? (
                  <p>
                    Calibrated based on validated student attempts with a 95% Wilson confidence interval. Observed difficulty is{' '}
                    <span className="font-bold">{selectedQuestion.calibrated_difficulty}</span>.
                  </p>
                ) : (
                  <p>
                    Cold-Start Item: No real student cohort data recorded yet. Initial classification relies purely on AI cognitive feature estimation.
                  </p>
                )}
              </div>
            </div>

            {/* Modal Actions */}
            <div className="flex justify-between items-center pt-4 border-t border-slate-200">
              <Button
                variant="destructive"
                size="sm"
                onClick={() => handleDelete(selectedQuestion.id)}
              >
                <Trash2 className="w-4 h-4 mr-1.5" /> Delete Question
              </Button>
              <div className="flex gap-2">
                {selectedQuestion.approval_status !== 'APPROVED' && (
                  <Button
                    variant="default"
                    size="sm"
                    onClick={() => handleApprove(selectedQuestion.id)}
                    className="bg-emerald-600 hover:bg-emerald-700"
                  >
                    <CheckCircle className="w-4 h-4 mr-1.5" /> Approve Item
                  </Button>
                )}
                {selectedQuestion.approval_status !== 'REJECTED' && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleReject(selectedQuestion.id)}
                  >
                    <XCircle className="w-4 h-4 mr-1.5" /> Reject Item
                  </Button>
                )}
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setPreviewModalOpen(false)}
                >
                  Close
                </Button>
              </div>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};
