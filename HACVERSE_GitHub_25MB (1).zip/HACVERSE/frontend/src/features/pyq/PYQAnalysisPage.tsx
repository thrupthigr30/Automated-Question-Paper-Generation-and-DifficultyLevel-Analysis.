import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardContent } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { Badge } from '../../components/ui/Badge';
import { Modal } from '../../components/ui/Modal';
import { Input } from '../../components/ui/Input';
import { pyqApi, subjectsApi } from '../../services/api';
import { PYQPaper, PYQQuestion, Subject } from '../../types';
import {
  FileText,
  Upload,
  BarChart2,
  Repeat,
  Calendar,
  AlertCircle,
  TrendingUp,
  Trash2,
  Play
} from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';

export const PYQAnalysisPage: React.FC = () => {
  const [papers, setPapers] = useState<PYQPaper[]>([]);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [selectedSubjectId, setSelectedSubjectId] = useState<number | ''>('');
  const [loading, setLoading] = useState<boolean>(true);

  // Analysis Data
  const [topicFrequencies, setTopicFrequencies] = useState<any[]>([]);
  const [repetitions, setRepetitions] = useState<any[]>([]);
  const [analysisLoading, setAnalysisLoading] = useState<boolean>(false);

  // Upload Modal State
  const [uploadModalOpen, setUploadModalOpen] = useState<boolean>(false);
  const [paperName, setPaperName] = useState<string>('');
  const [year, setYear] = useState<number>(new Date().getFullYear());
  const [semester, setSemester] = useState<string>('Autumn 2024');
  const [subjectId, setSubjectId] = useState<number | ''>('');
  const [file, setFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState<boolean>(false);
  const [uploadError, setUploadError] = useState<string | null>(null);

  useEffect(() => {
    fetchInitialData();
  }, []);

  const fetchInitialData = async () => {
    try {
      setLoading(true);
      const [papersRes, subjectsRes] = await Promise.all([
        pyqApi.listPapers(),
        subjectsApi.list(),
      ]);
      setPapers(papersRes.data);
      setSubjects(subjectsRes.data);
      if (subjectsRes.data.length > 0) {
        setSelectedSubjectId(subjectsRes.data[0].id);
        fetchAnalysis(subjectsRes.data[0].id);
      }
    } catch (err) {
      console.error('Error loading PYQ data:', err);
    } finally {
      setLoading(false);
    }
  };

  const fetchAnalysis = async (subId: number) => {
    try {
      setAnalysisLoading(true);
      const [freqRes, repRes] = await Promise.all([
        pyqApi.getTopicFrequency(subId),
        pyqApi.getRepetitions(subId),
      ]);
      setTopicFrequencies(freqRes.data);
      setRepetitions(repRes.data);
    } catch (err) {
      console.error('Error fetching PYQ analysis:', err);
    } finally {
      setAnalysisLoading(false);
    }
  };

  const handleSubjectChange = (subId: number | '') => {
    setSelectedSubjectId(subId);
    if (subId) {
      fetchAnalysis(Number(subId));
    } else {
      setTopicFrequencies([]);
      setRepetitions([]);
    }
  };

  const handleUploadPaper = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!file || !paperName || !subjectId) {
      setUploadError('Please fill all required fields and choose a paper file.');
      return;
    }

    const formData = new FormData();
    formData.append('file', file);
    formData.append('title', paperName);
    formData.append('year', String(year));
    formData.append('semester', semester);
    formData.append('subject_id', String(subjectId));

    try {
      setUploading(true);
      setUploadError(null);
      await pyqApi.uploadPaper(formData);
      setUploadModalOpen(false);
      setPaperName('');
      setFile(null);
      fetchInitialData();
    } catch (err: any) {
      setUploadError(err.response?.data?.detail || 'Failed to upload and parse PYQ paper');
    } finally {
      setUploading(false);
    }
  };

  const handleParse = async (paperId: number) => {
    try {
      await pyqApi.parsePaper(paperId);
      fetchInitialData();
    } catch (err) {
      console.error('Error parsing PYQ paper:', err);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            Previous Year Question (PYQ) Analysis
          </h1>
          <p className="text-sm text-slate-500">
            Mine historical examination papers for topic recurrence, question repetition, and syllabus weightage patterns.
          </p>
        </div>
        <Button onClick={() => setUploadModalOpen(true)}>
          <Upload className="w-4 h-4 mr-2" />
          Upload PYQ Paper
        </Button>
      </div>

      {/* Subject Selector Bar */}
      <div className="flex items-center justify-between gap-4 bg-white p-4 rounded-lg border border-slate-200">
        <div className="flex items-center gap-2">
          <label className="text-sm font-medium text-slate-700">Subject Analysis Workspace:</label>
          <select
            value={selectedSubjectId}
            onChange={(e) => handleSubjectChange(e.target.value ? Number(e.target.value) : '')}
            className="text-sm border border-slate-300 rounded-md px-3 py-1.5 focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="">Select Subject</option>
            {subjects.map((sub) => (
              <option key={sub.id} value={sub.id}>
                {sub.name} ({sub.code})
              </option>
            ))}
          </select>
        </div>
        <div className="text-xs text-slate-500">
          Total Historical Papers: <span className="font-semibold text-slate-900">{papers.length}</span>
        </div>
      </div>

      {/* Analysis Panels: Topic Frequency & Repetition */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Topic Frequency Chart */}
        <div className="lg:col-span-7">
          <Card className="h-full">
            <CardHeader className="border-b border-slate-100 pb-3 flex justify-between items-center">
              <div>
                <h2 className="font-semibold text-slate-900 text-sm flex items-center gap-2">
                  <BarChart2 className="w-4 h-4 text-blue-600" />
                  Historical Topic Weightage & Frequency
                </h2>
                <p className="text-xs text-slate-500">
                  Total marks and question frequency mapped across examination years.
                </p>
              </div>
            </CardHeader>
            <CardContent className="pt-4">
              {analysisLoading ? (
                <div className="h-64 flex items-center justify-center text-slate-400 text-sm">
                  Analyzing historical topic trends...
                </div>
              ) : topicFrequencies.length === 0 ? (
                <div className="h-64 flex items-center justify-center text-slate-400 text-sm text-center px-4">
                  No PYQ data available for this subject. Upload previous exam papers to generate weightage charts.
                </div>
              ) : (
                <div className="h-64 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={topicFrequencies}
                      margin={{ top: 10, right: 20, left: -10, bottom: 20 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                      <XAxis dataKey="topic_name" tick={{ fontSize: 11 }} />
                      <YAxis tick={{ fontSize: 11 }} />
                      <Tooltip />
                      <Bar dataKey="question_count" fill="#3b82f6" radius={[4, 4, 0, 0]} name="Questions" />
                      <Bar dataKey="total_marks" fill="#93c5fd" radius={[4, 4, 0, 0]} name="Marks" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Repetition Detection */}
        <div className="lg:col-span-5">
          <Card className="h-full">
            <CardHeader className="border-b border-slate-100 pb-3">
              <h2 className="font-semibold text-slate-900 text-sm flex items-center gap-2">
                <Repeat className="w-4 h-4 text-emerald-600" />
                Detected Repetitions & Similar Stems
              </h2>
              <p className="text-xs text-slate-500">
                Fuzzy similarity detection across recurring university questions.
              </p>
            </CardHeader>
            <CardContent className="pt-4">
              {analysisLoading ? (
                <div className="h-64 flex items-center justify-center text-slate-400 text-sm">
                  Checking similarity clusters...
                </div>
              ) : repetitions.length === 0 ? (
                <div className="h-64 flex items-center justify-center text-slate-400 text-sm text-center px-4">
                  No duplicate or repeated questions detected across uploaded papers.
                </div>
              ) : (
                <div className="space-y-3 max-h-64 overflow-y-auto pr-1">
                  {repetitions.map((rep, idx) => (
                    <div
                      key={idx}
                      className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-xs space-y-1.5"
                    >
                      <div className="flex justify-between items-center">
                        <span className="font-semibold text-slate-800">
                          Appeared in {rep.years?.join(', ') || 'Multiple Years'}
                        </span>
                        <Badge variant="outline" className="text-[10px] font-mono text-emerald-700">
                          {rep.similarity ? `${(rep.similarity * 100).toFixed(0)}% Match` : 'Recurring'}
                        </Badge>
                      </div>
                      <p className="text-slate-600 line-clamp-2">
                        "{rep.question_text}"
                      </p>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Historical Papers Table */}
      <Card>
        <CardHeader className="border-b border-slate-100 pb-3">
          <h2 className="font-semibold text-slate-900 text-sm">
            Uploaded Historical Examination Papers
          </h2>
        </CardHeader>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-sm">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50/75 text-slate-600 font-semibold">
                <th className="py-3 px-4">Examination Paper</th>
                <th className="py-3 px-4">Subject</th>
                <th className="py-3 px-4">Year & Semester</th>
                <th className="py-3 px-4">Questions Extracted</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {loading ? (
                <tr>
                  <td colSpan={5} className="py-8 text-center text-slate-400">Loading PYQ papers...</td>
                </tr>
              ) : papers.length === 0 ? (
                <tr>
                  <td colSpan={5} className="py-8 text-center text-slate-500">
                    No historical papers uploaded yet.
                  </td>
                </tr>
              ) : (
                papers.map((p) => (
                  <tr key={p.id} className="hover:bg-slate-50 transition-colors">
                    <td className="py-3 px-4">
                      <div className="font-medium text-slate-900 flex items-center gap-2">
                        <FileText className="w-4 h-4 text-blue-600" />
                        <span>{p.title}</span>
                      </div>
                      <div className="text-xs text-slate-400">{p.filename}</div>
                    </td>
                    <td className="py-3 px-4 text-slate-700">
                      {p.subject?.name || 'Unassigned'}
                    </td>
                    <td className="py-3 px-4">
                      <div className="text-xs font-semibold text-slate-800">{p.year}</div>
                      <div className="text-xs text-slate-400">{p.semester}</div>
                    </td>
                    <td className="py-3 px-4 font-mono text-xs">
                      {p.question_count || 0} questions
                    </td>
                    <td className="py-3 px-4 text-right space-x-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleParse(p.id)}
                        title="Re-parse questions"
                      >
                        <Play className="w-3.5 h-3.5 mr-1" /> Parse
                      </Button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </Card>

      {/* Upload PYQ Paper Modal */}
      <Modal
        isOpen={uploadModalOpen}
        onClose={() => setUploadModalOpen(false)}
        title="Upload Previous Year Question Paper"
      >
        <form onSubmit={handleUploadPaper} className="space-y-4">
          {uploadError && (
            <div className="p-3 bg-red-50 text-red-700 text-sm rounded border border-red-200">
              {uploadError}
            </div>
          )}

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">
              Examination Paper Title *
            </label>
            <Input
              value={paperName}
              onChange={(e) => setPaperName(e.target.value)}
              placeholder="e.g. End Semester Exam Nov 2023"
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">
                Year *
              </label>
              <Input
                type="number"
                value={year}
                onChange={(e) => setYear(Number(e.target.value))}
                min={2000}
                max={2030}
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">
                Semester / Session
              </label>
              <Input
                value={semester}
                onChange={(e) => setSemester(e.target.value)}
                placeholder="e.g. Spring 2024"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">
              Subject *
            </label>
            <select
              value={subjectId}
              onChange={(e) => setSubjectId(e.target.value ? Number(e.target.value) : '')}
              required
              className="w-full text-sm border border-slate-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="">Select Subject</option>
              {subjects.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name} ({s.code})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">
              Paper File (PDF, DOCX, TXT) *
            </label>
            <input
              type="file"
              accept=".pdf,.docx,.txt"
              onChange={(e) => setFile(e.target.files ? e.target.files[0] : null)}
              required
              className="w-full text-sm text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
            />
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t border-slate-100">
            <Button
              type="button"
              variant="outline"
              onClick={() => setUploadModalOpen(false)}
            >
              Cancel
            </Button>
            <Button type="submit" disabled={uploading}>
              {uploading ? 'Parsing Exam Paper...' : 'Upload & Parse Paper'}
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
