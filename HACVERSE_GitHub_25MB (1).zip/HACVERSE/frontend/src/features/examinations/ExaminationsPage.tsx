import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardContent } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { Badge } from '../../components/ui/Badge';
import { Modal } from '../../components/ui/Modal';
import { Input } from '../../components/ui/Input';
import { examinationsApi, subjectsApi, pdfApi } from '../../services/api';
import { Examination, Subject } from '../../types';
import {
  FileText,
  Plus,
  CheckCircle2,
  Sliders,
  Download,
  Trash2,
  Eye,
  Calendar,
  Layers,
  Send,
  AlertCircle
} from 'lucide-react';

export const ExaminationsPage: React.FC = () => {
  const [exams, setExams] = useState<Examination[]>([]);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  // Create Modal
  const [createModalOpen, setCreateModalOpen] = useState<boolean>(false);
  const [title, setTitle] = useState<string>('');
  const [subjectId, setSubjectId] = useState<number | ''>('');
  const [durationMinutes, setDurationMinutes] = useState<number>(60);
  const [totalMarks, setTotalMarks] = useState<number>(50);
  const [easyPercent, setEasyPercent] = useState<number>(30);
  const [mediumPercent, setMediumPercent] = useState<number>(40);
  const [hardPercent, setHardPercent] = useState<number>(30);
  const [creating, setCreating] = useState<boolean>(false);
  const [createError, setCreateError] = useState<string | null>(null);

  // Inspector Modal
  const [selectedExam, setSelectedExam] = useState<Examination | null>(null);
  const [inspectorOpen, setInspectorOpen] = useState<boolean>(false);

  useEffect(() => {
    fetchInitialData();
  }, []);

  const fetchInitialData = async () => {
    try {
      setLoading(true);
      const [exRes, subRes] = await Promise.all([
        examinationsApi.list(),
        subjectsApi.list(),
      ]);
      setExams(exRes.data);
      setSubjects(subRes.data);
    } catch (err) {
      console.error('Error fetching examinations:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (easyPercent + mediumPercent + hardPercent !== 100) {
      setCreateError('Difficulty percentages must sum to exactly 100%.');
      return;
    }

    try {
      setCreating(true);
      setCreateError(null);
      await examinationsApi.create({
        title,
        subject_id: Number(subjectId),
        duration_minutes: Number(durationMinutes),
        total_marks: Number(totalMarks),
        easy_percentage: Number(easyPercent),
        medium_percentage: Number(mediumPercent),
        hard_percentage: Number(hardPercent),
        auto_assemble: true,
      });

      setCreateModalOpen(false);
      setTitle('');
      fetchInitialData();
    } catch (err: any) {
      setCreateError(err.response?.data?.detail || 'Failed to assemble examination paper');
    } finally {
      setCreating(false);
    }
  };

  const handlePublish = async (id: number) => {
    try {
      await examinationsApi.publish(id);
      fetchInitialData();
      if (selectedExam?.id === id) {
        setSelectedExam({ ...selectedExam, status: 'PUBLISHED' });
      }
    } catch (err) {
      console.error('Error publishing exam:', err);
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm('Are you sure you want to delete this examination?')) return;
    try {
      await examinationsApi.delete(id);
      fetchInitialData();
      setInspectorOpen(false);
    } catch (err) {
      console.error('Error deleting examination:', err);
    }
  };

  const downloadPdf = async (examId: number, type: 'paper' | 'key' | 'report') => {
    try {
      let res;
      if (type === 'paper') res = await pdfApi.downloadQuestionPaper(examId);
      else if (type === 'key') res = await pdfApi.downloadAnswerKey(examId);
      else res = await pdfApi.downloadAnalysisReport(examId);

      const blob = new Blob([res.data], { type: 'application/pdf' });
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `Exam_${examId}_${type}.pdf`);
      document.body.appendChild(link);
      link.click();
      link.remove();
    } catch (err) {
      console.error('PDF download error:', err);
      alert('Failed to generate PDF. Check if questions are properly linked.');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            Examination Papers & Blueprints
          </h1>
          <p className="text-sm text-slate-500">
            Assemble multi-section examination papers with target cognitive difficulty distribution and ReportLab PDF export.
          </p>
        </div>
        <Button onClick={() => setCreateModalOpen(true)}>
          <Plus className="w-4 h-4 mr-2" />
          Create Examination
        </Button>
      </div>

      {/* Examinations Table */}
      <Card>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-sm">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50/75 text-slate-600 font-semibold">
                <th className="py-3 px-4">Examination Title</th>
                <th className="py-3 px-4">Subject</th>
                <th className="py-3 px-4">Duration & Marks</th>
                <th className="py-3 px-4">Target Difficulty Ratio</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {loading ? (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-slate-400">Loading examinations...</td>
                </tr>
              ) : exams.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-slate-500">
                    No examination papers created yet. Assemble an exam to begin testing student cohorts.
                  </td>
                </tr>
              ) : (
                exams.map((ex) => (
                  <tr key={ex.id} className="hover:bg-slate-50 transition-colors">
                    <td className="py-3 px-4">
                      <div className="font-medium text-slate-900 flex items-center gap-2">
                        <FileText className="w-4 h-4 text-blue-600" />
                        <span>{ex.title}</span>
                      </div>
                      <div className="text-xs text-slate-400">
                        {ex.questions?.length || 0} questions assigned
                      </div>
                    </td>
                    <td className="py-3 px-4 text-slate-700">
                      {ex.subject?.name || 'General'}
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-semibold text-slate-800">{ex.total_marks} Marks</div>
                      <div className="text-xs text-slate-400">{ex.duration_minutes} Minutes</div>
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-1.5 text-xs font-mono">
                        <span className="text-emerald-700 font-semibold">{ex.easy_percentage}% E</span>
                        <span className="text-slate-300">/</span>
                        <span className="text-amber-700 font-semibold">{ex.medium_percentage}% M</span>
                        <span className="text-slate-300">/</span>
                        <span className="text-red-700 font-semibold">{ex.hard_percentage}% H</span>
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      {ex.status === 'PUBLISHED' ? (
                        <Badge variant="success">Published</Badge>
                      ) : (
                        <Badge variant="secondary">Draft</Badge>
                      )}
                    </td>
                    <td className="py-3 px-4 text-right space-x-1">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          setSelectedExam(ex);
                          setInspectorOpen(true);
                        }}
                        title="View Paper & Sections"
                      >
                        <Eye className="w-3.5 h-3.5" />
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => downloadPdf(ex.id, 'paper')}
                        title="Download Question Paper PDF"
                        className="text-blue-700"
                      >
                        <Download className="w-3.5 h-3.5" />
                      </Button>
                      {ex.status !== 'PUBLISHED' && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handlePublish(ex.id)}
                          title="Publish for Student Assessment"
                          className="text-emerald-700"
                        >
                          <Send className="w-3.5 h-3.5" />
                        </Button>
                      )}
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={() => handleDelete(ex.id)}
                        title="Delete Examination"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </Button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </Card>

      {/* Create Examination Modal */}
      <Modal
        isOpen={createModalOpen}
        onClose={() => setCreateModalOpen(false)}
        title="Assemble Examination Paper"
      >
        <form onSubmit={handleCreate} className="space-y-4">
          {createError && (
            <div className="p-3 bg-red-50 text-red-700 text-xs rounded border border-red-200">
              {createError}
            </div>
          )}

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">
              Examination Title *
            </label>
            <Input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Mid-Term Assessment - Data Structures"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">
              Subject *
            </label>
            <select
              value={subjectId}
              onChange={(e) => setSubjectId(e.target.value ? Number(e.target.value) : '')}
              required
              className="w-full text-sm border border-slate-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="">Select Subject</option>
              {subjects.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name} ({s.code})
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">
                Duration (Minutes) *
              </label>
              <Input
                type="number"
                value={durationMinutes}
                onChange={(e) => setDurationMinutes(Number(e.target.value))}
                min={15}
                max={300}
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">
                Total Marks *
              </label>
              <Input
                type="number"
                value={totalMarks}
                onChange={(e) => setTotalMarks(Number(e.target.value))}
                min={10}
                max={200}
                required
              />
            </div>
          </div>

          {/* Difficulty Ratios */}
          <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-3">
            <div className="flex justify-between items-center text-xs font-semibold text-slate-700">
              <span>Target Cognitive Difficulty Balance</span>
              <span className={`font-mono ${easyPercent + mediumPercent + hardPercent === 100 ? 'text-emerald-600' : 'text-red-500'}`}>
                Sum: {easyPercent + mediumPercent + hardPercent}%
              </span>
            </div>

            <div className="grid grid-cols-3 gap-2">
              <div>
                <label className="text-[10px] uppercase font-bold text-slate-500">Easy %</label>
                <Input
                  type="number"
                  value={easyPercent}
                  onChange={(e) => setEasyPercent(Number(e.target.value))}
                  min={0}
                  max={100}
                />
              </div>
              <div>
                <label className="text-[10px] uppercase font-bold text-slate-500">Medium %</label>
                <Input
                  type="number"
                  value={mediumPercent}
                  onChange={(e) => setMediumPercent(Number(e.target.value))}
                  min={0}
                  max={100}
                />
              </div>
              <div>
                <label className="text-[10px] uppercase font-bold text-slate-500">Hard %</label>
                <Input
                  type="number"
                  value={hardPercent}
                  onChange={(e) => setHardPercent(Number(e.target.value))}
                  min={0}
                  max={100}
                />
              </div>
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t border-slate-100">
            <Button
              type="button"
              variant="outline"
              onClick={() => setCreateModalOpen(false)}
            >
              Cancel
            </Button>
            <Button type="submit" disabled={creating}>
              {creating ? 'Assembling Paper...' : 'Assemble Paper'}
            </Button>
          </div>
        </form>
      </Modal>

      {/* Examination Inspector Modal */}
      {selectedExam && (
        <Modal
          isOpen={inspectorOpen}
          onClose={() => setInspectorOpen(false)}
          title={`Exam Overview: ${selectedExam.title}`}
        >
          <div className="space-y-6 max-h-[75vh] overflow-y-auto pr-1">
            <div className="flex flex-wrap items-center justify-between gap-2 p-3 bg-slate-50 rounded-lg border border-slate-200 text-xs">
              <div>
                <span className="font-semibold text-slate-800">Subject:</span> {selectedExam.subject?.name}
              </div>
              <div>
                <span className="font-semibold text-slate-800">Duration:</span> {selectedExam.duration_minutes} Mins
              </div>
              <div>
                <span className="font-semibold text-slate-800">Total Marks:</span> {selectedExam.total_marks}
              </div>
              <div>
                <Badge variant={selectedExam.status === 'PUBLISHED' ? 'success' : 'secondary'}>
                  {selectedExam.status}
                </Badge>
              </div>
            </div>

            {/* PDF Exports */}
            <div className="p-3 bg-blue-50/50 rounded-lg border border-blue-200 flex flex-wrap items-center justify-between gap-2">
              <span className="text-xs font-semibold text-blue-900">Official ReportLab PDF Documents:</span>
              <div className="flex gap-2">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => downloadPdf(selectedExam.id, 'paper')}
                  className="text-xs bg-white text-blue-700"
                >
                  <Download className="w-3.5 h-3.5 mr-1" /> Question Paper
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => downloadPdf(selectedExam.id, 'key')}
                  className="text-xs bg-white text-emerald-700"
                >
                  <Download className="w-3.5 h-3.5 mr-1" /> Answer Key
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => downloadPdf(selectedExam.id, 'report')}
                  className="text-xs bg-white text-purple-700"
                >
                  <Download className="w-3.5 h-3.5 mr-1" /> Analysis Report
                </Button>
              </div>
            </div>

            {/* Questions List */}
            <div className="space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                Assigned Examination Questions ({selectedExam.questions?.length || 0})
              </h4>

              {(!selectedExam.questions || selectedExam.questions.length === 0) ? (
                <div className="py-6 text-center text-slate-400 text-xs">
                  No questions currently linked to this paper.
                </div>
              ) : (
                selectedExam.questions.map((eq: any, idx: number) => {
                  const q = eq.question || eq;
                  return (
                    <div
                      key={idx}
                      className="p-3 bg-white rounded-lg border border-slate-200 text-xs space-y-1.5"
                    >
                      <div className="flex justify-between items-center">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-slate-900">Q{idx + 1}.</span>
                          <Badge variant="outline">{q.question_type}</Badge>
                          <span className="text-slate-500 font-medium">{q.marks} Marks</span>
                        </div>
                        <Badge
                          variant={
                            (q.calibrated_difficulty || q.initial_difficulty) === 'EASY'
                              ? 'success'
                              : (q.calibrated_difficulty || q.initial_difficulty) === 'HARD'
                              ? 'danger'
                              : 'warning'
                          }
                        >
                          {q.calibrated_difficulty || q.initial_difficulty || 'MEDIUM'}
                        </Badge>
                      </div>
                      <p className="text-slate-800 font-medium">{q.question_text}</p>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};
