import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardContent } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { Badge } from '../../components/ui/Badge';
import { Modal } from '../../components/ui/Modal';
import { datasetsApi } from '../../services/api';
import {
  Database,
  Download,
  Play,
  Trash2,
  Table,
  CheckCircle2,
  AlertTriangle,
  FileSpreadsheet,
  FileCode,
  Activity,
  Layers,
  Sparkles
} from 'lucide-react';

export const DatasetsPage: React.FC = () => {
  const [stats, setStats] = useState<any>(null);
  const [activeTab, setActiveTab] = useState<string>('questions');
  const [tableData, setTableData] = useState<any[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [generating, setGenerating] = useState<boolean>(false);
  const [purging, setPurging] = useState<boolean>(false);
  const [actionMessage, setActionMessage] = useState<string | null>(null);

  const datasetTabs = [
    { id: 'academic_content', name: '1. Academic Content', countKey: 'academic_chunks' },
    { id: 'questions', name: '2. Question Bank', countKey: 'total_questions' },
    { id: 'pyq', name: '3. Historical / PYQ Items', countKey: 'pyq_questions' },
    { id: 'student_performance', name: '4. Student Performance', countKey: 'student_responses' },
    { id: 'difficulty_calibration', name: '5. Difficulty & Calibration', countKey: 'calibration_records' },
  ];

  useEffect(() => {
    fetchStatsAndPreview();
  }, [activeTab]);

  const fetchStatsAndPreview = async () => {
    try {
      setLoading(true);
      const [statsRes, previewRes] = await Promise.all([
        datasetsApi.getStats(),
        datasetsApi.preview(activeTab),
      ]);
      setStats(statsRes.data);
      setTableData(previewRes.data.records || []);
    } catch (err) {
      console.error('Error loading dataset data:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleExport = async (format: 'csv' | 'json' | 'xlsx') => {
    try {
      const res = await datasetsApi.export(activeTab, format);
      const blob = new Blob([res.data], {
        type: format === 'json' ? 'application/json' : format === 'csv' ? 'text/csv' : 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
      });
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `${activeTab}_dataset.${format}`);
      document.body.appendChild(link);
      link.click();
      link.remove();
    } catch (err) {
      console.error('Failed to export dataset:', err);
    }
  };

  const handleGenerateSynthetic = async () => {
    if (!confirm('This will simulate 30 student cohorts attempting uncalibrated questions to test Wilson Score calibration. Proceed?')) return;
    try {
      setGenerating(true);
      setActionMessage(null);
      const res = await datasetsApi.generateSynthetic({ student_count: 30, attempts_per_student: 15 });
      setActionMessage(`Successfully generated synthetic cohort performance: ${res.data.responses_created} responses logged.`);
      fetchStatsAndPreview();
    } catch (err: any) {
      alert(err.response?.data?.detail || 'Failed to generate synthetic data');
    } finally {
      setGenerating(false);
    }
  };

  const handlePurgeSynthetic = async () => {
    if (!confirm('This will remove all synthetic student responses and reset question calibrations. Continue?')) return;
    try {
      setPurging(true);
      setActionMessage(null);
      const res = await datasetsApi.purgeSynthetic();
      setActionMessage(`Purged ${res.data.deleted_responses} synthetic responses and reset calibration states.`);
      fetchStatsAndPreview();
    } catch (err: any) {
      alert(err.response?.data?.detail || 'Failed to purge synthetic data');
    } finally {
      setPurging(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            Mandatory Structured Datasets
          </h1>
          <p className="text-sm text-slate-500">
            5 persistent relational assessment datasets supporting ML calibration, psychometric research, and data portability.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={handleGenerateSynthetic}
            disabled={generating}
            className="text-blue-700 bg-blue-50 border-blue-200 hover:bg-blue-100"
          >
            <Sparkles className="w-3.5 h-3.5 mr-1.5" />
            {generating ? 'Simulating Cohorts...' : 'Generate Synthetic Cohort'}
          </Button>

          <Button
            variant="outline"
            size="sm"
            onClick={handlePurgeSynthetic}
            disabled={purging}
            className="text-red-700 bg-red-50 border-red-200 hover:bg-red-100"
          >
            <Trash2 className="w-3.5 h-3.5 mr-1.5" />
            {purging ? 'Purging...' : 'Purge Synthetic Data'}
          </Button>
        </div>
      </div>

      {actionMessage && (
        <div className="p-3 bg-emerald-50 text-emerald-800 text-sm rounded-lg border border-emerald-200 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{actionMessage}</span>
        </div>
      )}

      {/* Dataset Metrics Strip */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        {datasetTabs.map((tab) => {
          const count = stats ? stats[tab.countKey] || 0 : 0;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`p-3.5 rounded-lg border text-left transition-all ${
                isActive
                  ? 'bg-blue-50/60 border-blue-500 ring-2 ring-blue-500/20'
                  : 'bg-white border-slate-200 hover:bg-slate-50'
              }`}
            >
              <div className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider truncate">
                {tab.name.split('. ')[1]}
              </div>
              <div className="text-xl font-bold text-slate-900 mt-1">
                {count.toLocaleString()}
              </div>
              <div className="text-[10px] text-slate-400 mt-0.5">Records stored</div>
            </button>
          );
        })}
      </div>

      {/* Main Dataset Card */}
      <Card>
        <CardHeader className="border-b border-slate-100 pb-3 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
          <div>
            <h2 className="font-semibold text-slate-900 text-sm flex items-center gap-2">
              <Table className="w-4 h-4 text-blue-600" />
              Live Record Inspector: {datasetTabs.find((t) => t.id === activeTab)?.name}
            </h2>
            <p className="text-xs text-slate-500">
              Sample of current database records for verification and tabular export.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400 font-medium mr-1">Export Dataset:</span>
            <Button
              variant="outline"
              size="sm"
              onClick={() => handleExport('csv')}
              className="text-xs gap-1"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" /> CSV
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => handleExport('json')}
              className="text-xs gap-1"
            >
              <FileCode className="w-3.5 h-3.5 text-blue-600" /> JSON
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => handleExport('xlsx')}
              className="text-xs gap-1"
            >
              <Download className="w-3.5 h-3.5 text-slate-600" /> Excel
            </Button>
          </div>
        </CardHeader>

        <CardContent className="p-0">
          <div className="overflow-x-auto max-h-[500px]">
            {loading ? (
              <div className="py-12 text-center text-slate-400 text-sm">Loading dataset preview...</div>
            ) : tableData.length === 0 ? (
              <div className="py-12 text-center text-slate-500 text-sm">
                No records found in this dataset. Create subjects, generate questions, or simulate student cohorts to populate.
              </div>
            ) : (
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50/90 text-slate-700 font-semibold sticky top-0 z-10">
                    {Object.keys(tableData[0]).map((key) => (
                      <th key={key} className="py-2.5 px-3 uppercase tracking-wider text-[10px] font-mono whitespace-nowrap">
                        {key}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {tableData.map((row, rIdx) => (
                    <tr key={rIdx} className="hover:bg-slate-50 font-mono">
                      {Object.entries(row).map(([col, val], cIdx) => (
                        <td key={cIdx} className="py-2 px-3 whitespace-nowrap max-w-xs truncate text-slate-700">
                          {typeof val === 'boolean' ? (
                            val ? (
                              <Badge variant="success" className="text-[10px]">TRUE</Badge>
                            ) : (
                              <Badge variant="danger" className="text-[10px]">FALSE</Badge>
                            )
                          ) : typeof val === 'number' ? (
                            Number.isInteger(val) ? val : val.toFixed(2)
                          ) : (
                            String(val ?? '—')
                          )}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
