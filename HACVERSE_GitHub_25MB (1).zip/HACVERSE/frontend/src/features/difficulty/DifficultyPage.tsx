import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardContent } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { Badge } from '../../components/ui/Badge';
import { Modal } from '../../components/ui/Modal';
import { Input } from '../../components/ui/Input';
import { calibrationApi, questionsApi } from '../../services/api';
import { Question } from '../../types';
import {
  Activity,
  Play,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  Sliders,
  TrendingUp,
  BarChart2,
  Edit3,
  Award
} from 'lucide-react';

export const DifficultyPage: React.FC = () => {
  const [questions, setQuestions] = useState<Question[]>([]);
  const [evaluation, setEvaluation] = useState<any>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [calibrating, setCalibrating] = useState<boolean>(false);
  const [calibrationSuccess, setCalibrationSuccess] = useState<string | null>(null);

  // Override Modal
  const [overrideModalOpen, setOverrideModalOpen] = useState<boolean>(false);
  const [selectedQuestion, setSelectedQuestion] = useState<Question | null>(null);
  const [overrideDifficulty, setOverrideDifficulty] = useState<string>('MEDIUM');
  const [overrideReason, setOverrideReason] = useState<string>('');
  const [submittingOverride, setSubmittingOverride] = useState<boolean>(false);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      setLoading(true);
      const [qRes, evalRes] = await Promise.all([
        questionsApi.list(),
        calibrationApi.getEvaluation(),
      ]);
      const qList = Array.isArray(qRes.data) ? qRes.data : (qRes.data?.questions || []);
      setQuestions(qList);
      setEvaluation(evalRes.data);
    } catch (err) {
      console.error('Error fetching calibration data:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleRunCalibration = async () => {
    try {
      setCalibrating(true);
      setCalibrationSuccess(null);
      const res = await calibrationApi.runCalibration({ min_attempts: 10 });
      setCalibrationSuccess(
        `Calibration completed! Processed ${res.data.questions_calibrated || 0} questions with sufficient empirical evidence.`
      );
      fetchData();
    } catch (err: any) {
      alert(err.response?.data?.detail || 'Failed to run calibration cycle');
    } finally {
      setCalibrating(false);
    }
  };

  const handleOpenOverride = (q: Question) => {
    setSelectedQuestion(q);
    setOverrideDifficulty(q.calibrated_difficulty || q.initial_difficulty || 'MEDIUM');
    setOverrideReason('');
    setOverrideModalOpen(true);
  };

  const handleSubmitOverride = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedQuestion) return;

    try {
      setSubmittingOverride(true);
      await calibrationApi.override(selectedQuestion.id, {
        overridden_difficulty: overrideDifficulty,
        reason: overrideReason || 'Manual faculty pedagogical judgment override',
      });
      setOverrideModalOpen(false);
      fetchData();
    } catch (err: any) {
      alert(err.response?.data?.detail || 'Failed to submit override');
    } finally {
      setSubmittingOverride(false);
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'CALIBRATED':
        return <Badge variant="success">Calibrated</Badge>;
      case 'MANUALLY_OVERRIDDEN':
        return <Badge variant="secondary">Manual Override</Badge>;
      case 'INSUFFICIENT_DATA':
        return <Badge variant="warning">Low Attempts (&lt;10)</Badge>;
      default:
        return <Badge variant="outline">Cold-Start (AI)</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            Adaptive Difficulty Calibration & Evaluation
          </h1>
          <p className="text-sm text-slate-500">
            Psychometric calibration engine comparing initial cognitive predictions with Wilson Score confidence intervals.
          </p>
        </div>

        <Button
          onClick={handleRunCalibration}
          disabled={calibrating}
          className="bg-blue-600 hover:bg-blue-700"
        >
          <Play className="w-4 h-4 mr-2" />
          {calibrating ? 'Calculating Wilson Scores...' : 'Run Calibration Engine'}
        </Button>
      </div>

      {calibrationSuccess && (
        <div className="p-3 bg-emerald-50 text-emerald-800 text-sm rounded-lg border border-emerald-200 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{calibrationSuccess}</span>
        </div>
      )}

      {/* Research & Psychometric Metrics Banner */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="p-4">
          <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
            Weighted Cohen's Kappa
          </div>
          <div className="text-2xl font-bold text-slate-900 mt-1">
            {evaluation?.weighted_cohen_kappa !== undefined
              ? evaluation.weighted_cohen_kappa.toFixed(3)
              : '0.000'}
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5">
            Inter-rater agreement metric
          </div>
        </Card>

        <Card className="p-4">
          <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
            Prediction Accuracy
          </div>
          <div className="text-2xl font-bold text-emerald-600 mt-1">
            {evaluation?.agreement_rate !== undefined
              ? `${(evaluation.agreement_rate * 100).toFixed(1)}%`
              : '0.0%'}
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5">
            AI vs Observed difficulty
          </div>
        </Card>

        <Card className="p-4">
          <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
            Macro F1 Score
          </div>
          <div className="text-2xl font-bold text-blue-600 mt-1">
            {evaluation?.macro_f1 !== undefined ? evaluation.macro_f1.toFixed(3) : '0.000'}
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5">
            Balanced across difficulty tiers
          </div>
        </Card>

        <Card className="p-4">
          <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
            Calibrated Questions
          </div>
          <div className="text-2xl font-bold text-purple-600 mt-1">
            {questions.filter((q) => q.calibration_status === 'CALIBRATED').length} / {questions.length}
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5">
            Cohort sample size &ge; 10
          </div>
        </Card>
      </div>

      {/* Confusion Matrix Card */}
      {evaluation?.confusion_matrix && (
        <Card>
          <CardHeader className="border-b border-slate-100 pb-3">
            <h2 className="font-semibold text-slate-900 text-sm flex items-center gap-2">
              <BarChart2 className="w-4 h-4 text-blue-600" />
              Confusion Matrix: AI Predicted vs Empirical Student Observed Difficulty
            </h2>
            <p className="text-xs text-slate-500">
              Evaluates alignment and calibration drift between initial cold-start estimates and realized test outcomes.
            </p>
          </CardHeader>
          <CardContent className="pt-4">
            <div className="max-w-md mx-auto">
              <table className="w-full text-center border-collapse text-xs">
                <thead>
                  <tr>
                    <th className="p-2 border border-slate-200 bg-slate-50"></th>
                    <th colSpan={3} className="p-2 border border-slate-200 bg-blue-50 font-semibold text-blue-900">
                      Real Student Observed Difficulty
                    </th>
                  </tr>
                  <tr className="bg-slate-50 font-semibold text-slate-700">
                    <th className="p-2 border border-slate-200 bg-blue-50 text-blue-900">AI Initial</th>
                    <th className="p-2 border border-slate-200">Observed Easy</th>
                    <th className="p-2 border border-slate-200">Observed Medium</th>
                    <th className="p-2 border border-slate-200">Observed Hard</th>
                  </tr>
                </thead>
                <tbody>
                  {['EASY', 'MEDIUM', 'HARD'].map((aiDiff, rIdx) => (
                    <tr key={aiDiff}>
                      <td className="p-2.5 font-bold border border-slate-200 bg-slate-50 text-slate-800">
                        Predicted {aiDiff}
                      </td>
                      {['EASY', 'MEDIUM', 'HARD'].map((obsDiff, cIdx) => {
                        const count = evaluation.confusion_matrix[aiDiff]?.[obsDiff] || 0;
                        const isDiagonal = rIdx === cIdx;
                        return (
                          <td
                            key={obsDiff}
                            className={`p-2.5 border border-slate-200 font-mono font-bold text-sm ${
                              isDiagonal
                                ? 'bg-emerald-50 text-emerald-800'
                                : count > 0
                                ? 'bg-amber-50 text-amber-800'
                                : 'text-slate-400'
                            }`}
                          >
                            {count}
                          </td>
                        );
                      })}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Item-Level Difficulty & Calibration Table */}
      <Card>
        <CardHeader className="border-b border-slate-100 pb-3">
          <h2 className="font-semibold text-slate-900 text-sm">
            Question Lifecycle Difficulty Ledger
          </h2>
        </CardHeader>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-sm">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50/75 text-slate-600 font-semibold text-xs">
                <th className="py-3 px-4">Question Details</th>
                <th className="py-3 px-4">Initial AI Estimate</th>
                <th className="py-3 px-4">Student Evidence</th>
                <th className="py-3 px-4">Calibrated Difficulty</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {loading ? (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-slate-400">Loading calibration ledger...</td>
                </tr>
              ) : questions.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-slate-500">
                    No questions available. Generate questions and collect student responses to run calibration.
                  </td>
                </tr>
              ) : (
                questions.map((q) => (
                  <tr key={q.id} className="hover:bg-slate-50 transition-colors">
                    <td className="py-3 px-4 max-w-sm">
                      <div className="font-medium text-slate-900 line-clamp-2">
                        {q.question_text}
                      </div>
                      <div className="text-xs text-slate-400 mt-0.5">{q.subject?.name}</div>
                    </td>
                    <td className="py-3 px-4">
                      <Badge
                        variant={
                          q.initial_difficulty === 'EASY'
                            ? 'success'
                            : q.initial_difficulty === 'HARD'
                            ? 'danger'
                            : 'warning'
                        }
                      >
                        {q.initial_difficulty}
                      </Badge>
                      <div className="text-xs text-slate-400 mt-1">
                        Score: {q.difficulty_score?.toFixed(1) || '0.0'}
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <div className="text-xs font-semibold text-slate-800">
                        {q.total_attempts || 0} attempts
                      </div>
                      <div className="text-xs text-slate-400 mt-0.5">
                        Success: {q.success_rate ? `${(q.success_rate * 100).toFixed(0)}%` : '—'}
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      {q.calibrated_difficulty ? (
                        <div>
                          <Badge
                            variant={
                              q.calibrated_difficulty === 'EASY'
                                ? 'success'
                                : q.calibrated_difficulty === 'HARD'
                                ? 'danger'
                                : 'warning'
                            }
                          >
                            {q.calibrated_difficulty}
                          </Badge>
                          {q.wilson_ci_lower !== undefined && q.wilson_ci_upper !== undefined && (
                            <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                              95% CI: [{q.wilson_ci_lower.toFixed(2)}, {q.wilson_ci_upper.toFixed(2)}]
                            </div>
                          )}
                        </div>
                      ) : (
                        <span className="text-xs text-slate-400 italic">Uncalibrated</span>
                      )}
                    </td>
                    <td className="py-3 px-4">
                      {getStatusBadge(q.calibration_status)}
                    </td>
                    <td className="py-3 px-4 text-right">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleOpenOverride(q)}
                        className="text-xs"
                      >
                        <Edit3 className="w-3.5 h-3.5 mr-1" /> Override
                      </Button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </Card>

      {/* Manual Override Modal */}
      {selectedQuestion && (
        <Modal
          isOpen={overrideModalOpen}
          onClose={() => setOverrideModalOpen(false)}
          title="Teacher Calibration Override"
        >
          <form onSubmit={handleSubmitOverride} className="space-y-4">
            <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-xs space-y-1">
              <div className="font-semibold text-slate-800">{selectedQuestion.question_text}</div>
              <div className="text-slate-500">
                Initial: <span className="font-bold">{selectedQuestion.initial_difficulty}</span> | Observed: <span className="font-bold">{selectedQuestion.calibrated_difficulty || 'None'}</span>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">
                Faculty Overridden Classification *
              </label>
              <select
                value={overrideDifficulty}
                onChange={(e) => setOverrideDifficulty(e.target.value)}
                required
                className="w-full text-sm border border-slate-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="EASY">Easy</option>
                <option value="MEDIUM">Medium</option>
                <option value="HARD">Hard</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">
                Pedagogical Justification / Evidence Note *
              </label>
              <textarea
                rows={3}
                value={overrideReason}
                onChange={(e) => setOverrideReason(e.target.value)}
                placeholder="Explain why statistical calibration or AI estimation deviates from target curriculum expectations..."
                required
                className="w-full text-sm border border-slate-300 rounded-md p-2.5 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div className="flex justify-end gap-3 pt-4 border-t border-slate-100">
              <Button
                type="button"
                variant="outline"
                onClick={() => setOverrideModalOpen(false)}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={submittingOverride}>
                {submittingOverride ? 'Saving Override...' : 'Confirm Faculty Override'}
              </Button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
};
