import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardContent } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { Badge } from '../../components/ui/Badge';
import { performanceApi, subjectsApi } from '../../services/api';
import { Subject } from '../../types';
import {
  TrendingUp,
  BarChart2,
  Users,
  Target,
  Award,
  Layers,
  CheckCircle2,
  PieChart
} from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';

export const PerformancePage: React.FC = () => {
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [selectedSubjectId, setSelectedSubjectId] = useState<number | ''>('');
  const [analytics, setAnalytics] = useState<any>(null);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    fetchInitialData();
  }, []);

  const fetchInitialData = async () => {
    try {
      setLoading(true);
      const [sRes, aRes] = await Promise.all([
        subjectsApi.list(),
        performanceApi.getAnalytics(),
      ]);
      setSubjects(sRes.data);
      setAnalytics(aRes.data);
    } catch (err) {
      console.error('Error loading performance analytics:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleFilter = async (sId: number | '') => {
    setSelectedSubjectId(sId);
    try {
      setLoading(true);
      const res = await performanceApi.getAnalytics(sId ? sId : undefined);
      setAnalytics(res.data);
    } catch (err) {
      console.error('Error filtering analytics:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            Performance Analytics & Item Discrimination
          </h1>
          <p className="text-sm text-slate-500">
            Empirical student outcome analysis, topic mastery profiles, and item discrimination indices.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <label className="text-xs font-semibold text-slate-600 uppercase">Subject:</label>
          <select
            value={selectedSubjectId}
            onChange={(e) => handleFilter(e.target.value ? Number(e.target.value) : '')}
            className="text-sm border border-slate-300 rounded-md px-3 py-1.5 focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="">All Subjects</option>
            {subjects.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name} ({s.code})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="p-4">
          <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
            Total Student Attempts
          </div>
          <div className="text-2xl font-bold text-slate-900 mt-1">
            {analytics?.total_responses || 0}
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5">Logged item evaluations</div>
        </Card>

        <Card className="p-4">
          <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
            Overall Mean Accuracy
          </div>
          <div className="text-2xl font-bold text-emerald-600 mt-1">
            {analytics?.overall_accuracy ? `${(analytics.overall_accuracy * 100).toFixed(1)}%` : '0.0%'}
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5">Cohort success rate</div>
        </Card>

        <Card className="p-4">
          <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
            Exams Administered
          </div>
          <div className="text-2xl font-bold text-blue-600 mt-1">
            {analytics?.total_exams || 0}
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5">Completed assessments</div>
        </Card>

        <Card className="p-4">
          <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
            Active Student Cohort
          </div>
          <div className="text-2xl font-bold text-purple-600 mt-1">
            {analytics?.unique_students || 0}
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5">Distinct candidates</div>
        </Card>
      </div>

      {/* Charts: Topic Mastery & Bloom's Taxonomy Performance */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-7">
          <Card className="h-full">
            <CardHeader className="border-b border-slate-100 pb-3">
              <h2 className="font-semibold text-slate-900 text-sm flex items-center gap-2">
                <BarChart2 className="w-4 h-4 text-blue-600" />
                Topic Accuracy & Curriculum Mastery (%)
              </h2>
            </CardHeader>
            <CardContent className="pt-4">
              {loading ? (
                <div className="h-64 flex items-center justify-center text-slate-400 text-sm">
                  Loading performance metrics...
                </div>
              ) : !analytics?.topic_mastery || analytics.topic_mastery.length === 0 ? (
                <div className="h-64 flex items-center justify-center text-slate-400 text-sm text-center px-4">
                  No topic performance data available yet. Administer exams or generate synthetic student test cohorts.
                </div>
              ) : (
                <div className="h-64 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={analytics.topic_mastery}
                      margin={{ top: 10, right: 20, left: -10, bottom: 20 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                      <XAxis dataKey="topic_name" tick={{ fontSize: 11 }} />
                      <YAxis domain={[0, 100]} tick={{ fontSize: 11 }} />
                      <Tooltip />
                      <Bar dataKey="accuracy_percentage" fill="#3b82f6" radius={[4, 4, 0, 0]} name="Accuracy %" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        <div className="lg:col-span-5">
          <Card className="h-full">
            <CardHeader className="border-b border-slate-100 pb-3">
              <h2 className="font-semibold text-slate-900 text-sm flex items-center gap-2">
                <Target className="w-4 h-4 text-emerald-600" />
                Bloom's Taxonomy Cognitive Success Rate
              </h2>
            </CardHeader>
            <CardContent className="pt-4">
              {loading ? (
                <div className="h-64 flex items-center justify-center text-slate-400 text-sm">
                  Loading cognitive profiles...
                </div>
              ) : !analytics?.blooms_performance || analytics.blooms_performance.length === 0 ? (
                <div className="h-64 flex items-center justify-center text-slate-400 text-sm text-center px-4">
                  No cognitive breakdown data recorded.
                </div>
              ) : (
                <div className="space-y-3">
                  {analytics.blooms_performance.map((bp: any, idx: number) => (
                    <div key={idx} className="space-y-1">
                      <div className="flex justify-between text-xs font-semibold text-slate-700">
                        <span>{bp.level}</span>
                        <span>{(bp.accuracy * 100).toFixed(1)}%</span>
                      </div>
                      <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                        <div
                          className="bg-blue-600 h-full rounded-full transition-all"
                          style={{ width: `${bp.accuracy * 100}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};
