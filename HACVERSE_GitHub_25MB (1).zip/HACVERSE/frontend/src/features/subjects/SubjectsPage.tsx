import React, { useState, useEffect } from 'react';
import api from '../../services/api';
import { Card, CardHeader, CardTitle, CardContent } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { Input } from '../../components/ui/Input';
import { Modal } from '../../components/ui/Modal';
import { Badge } from '../../components/ui/Badge';
import { Subject } from '../../types';
import { BookOpen, Plus, FolderTree, ChevronRight, Trash2, Edit3, Layers } from 'lucide-react';

export const SubjectsPage: React.FC = () => {
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedSubject, setSelectedSubject] = useState<Subject | null>(null);
  const [syllabusTree, setSyllabusTree] = useState<any>(null);

  // Modal states
  const [isCreateSubjOpen, setIsCreateSubjOpen] = useState(false);
  const [isCreateUnitOpen, setIsCreateUnitOpen] = useState(false);
  const [isCreateTopicOpen, setIsCreateTopicOpen] = useState(false);

  // Form states
  const [subjName, setSubjName] = useState('');
  const [subjCode, setSubjCode] = useState('');
  const [subjDesc, setSubjDesc] = useState('');

  const [unitName, setUnitName] = useState('');
  const [unitNumber, setUnitNumber] = useState(1);

  const [selectedUnitId, setSelectedUnitId] = useState<number | null>(null);
  const [topicName, setTopicName] = useState('');
  const [topicDesc, setTopicDesc] = useState('');

  useEffect(() => {
    fetchSubjects();
  }, []);

  const fetchSubjects = async () => {
    try {
      setLoading(true);
      const res = await api.get('/subjects');
      setSubjects(res.data);
      if (res.data.length > 0 && !selectedSubject) {
        selectSubject(res.data[0]);
      }
    } catch (err) {
      console.error('Failed to fetch subjects:', err);
    } finally {
      setLoading(false);
    }
  };

  const selectSubject = async (subj: Subject) => {
    setSelectedSubject(subj);
    try {
      const res = await api.get(`/subjects/${subj.id}/syllabus`);
      setSyllabusTree(res.data);
    } catch (err) {
      console.error('Failed to load syllabus tree:', err);
    }
  };

  const handleCreateSubject = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await api.post('/subjects', {
        name: subjName,
        code: subjCode,
        description: subjDesc
      });
      setIsCreateSubjOpen(false);
      setSubjName('');
      setSubjCode('');
      setSubjDesc('');
      fetchSubjects();
    } catch (err: any) {
      alert(err.response?.data?.detail || 'Failed to create subject');
    }
  };

  const handleCreateUnit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedSubject) return;
    try {
      await api.post('/subjects/units', {
        name: unitName,
        unit_number: unitNumber,
        subject_id: selectedSubject.id
      });
      setIsCreateUnitOpen(false);
      setUnitName('');
      selectSubject(selectedSubject);
    } catch (err: any) {
      alert(err.response?.data?.detail || 'Failed to create unit');
    }
  };

  const handleCreateTopic = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedUnitId || !selectedSubject) return;
    try {
      await api.post('/subjects/topics', {
        name: topicName,
        description: topicDesc,
        unit_id: selectedUnitId
      });
      setIsCreateTopicOpen(false);
      setTopicName('');
      setTopicDesc('');
      selectSubject(selectedSubject);
    } catch (err: any) {
      alert(err.response?.data?.detail || 'Failed to create topic');
    }
  };

  const handleDeleteSubject = async (id: number) => {
    if (!window.confirm('Are you sure you want to delete this subject and its associated syllabus?')) return;
    try {
      await api.delete(`/subjects/${id}`);
      setSelectedSubject(null);
      setSyllabusTree(null);
      fetchSubjects();
    } catch (err) {
      alert('Failed to delete subject');
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-slate-900">Subjects & Syllabus Architecture</h2>
          <p className="text-sm text-slate-500 mt-1">
            Configure hierarchical subject structures: Subject → Unit → Topic → Subtopic.
          </p>
        </div>
        <Button onClick={() => setIsCreateSubjOpen(true)}>
          <Plus className="h-4 w-4 mr-2" />
          Add Subject
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Left Column: Subject List */}
        <div className="space-y-3">
          <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-500 px-1">
            Subjects ({subjects.length})
          </h3>
          <div className="space-y-2">
            {subjects.map((s) => (
              <div
                key={s.id}
                onClick={() => selectSubject(s)}
                className={`p-4 rounded-xl border transition-all cursor-pointer flex items-center justify-between ${
                  selectedSubject?.id === s.id
                    ? 'bg-blue-50/80 border-blue-500/80 shadow-xs'
                    : 'bg-white border-slate-200/80 hover:border-slate-300'
                }`}
              >
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-sm text-slate-900 truncate">{s.name}</span>
                    {s.code && <Badge size="sm">{s.code}</Badge>}
                  </div>
                  <div className="flex items-center gap-3 text-xs text-slate-500 mt-2">
                    <span>{s.unit_count || 0} Units</span>
                    <span>•</span>
                    <span>{s.topic_count || 0} Topics</span>
                  </div>
                </div>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    handleDeleteSubject(s.id);
                  }}
                  className="p-1.5 text-slate-300 hover:text-rose-600 rounded-md transition-colors"
                  title="Delete subject"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            ))}

            {subjects.length === 0 && !loading && (
              <div className="p-8 text-center border-2 border-dashed border-slate-200 rounded-xl">
                <BookOpen className="h-8 w-8 text-slate-300 mx-auto mb-2" />
                <p className="text-xs text-slate-500 font-medium">No subjects found.</p>
                <Button size="sm" variant="outline" className="mt-3" onClick={() => setIsCreateSubjOpen(true)}>
                  Create First Subject
                </Button>
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Syllabus Hierarchy Tree */}
        <div className="md:col-span-2">
          {selectedSubject ? (
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>{selectedSubject.name} — Syllabus Structure</CardTitle>
                  <p className="text-xs text-slate-500 mt-0.5">{selectedSubject.description || 'No description provided.'}</p>
                </div>
                <Button size="sm" variant="outline" onClick={() => {
                  setUnitNumber((syllabusTree?.units?.length || 0) + 1);
                  setIsCreateUnitOpen(true);
                }}>
                  <Plus className="h-3.5 w-3.5 mr-1.5" />
                  Add Unit
                </Button>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {syllabusTree?.units?.map((u: any) => (
                    <div key={u.id} className="border border-slate-200 rounded-xl p-4 bg-slate-50/50">
                      <div className="flex items-center justify-between pb-3 border-b border-slate-200/60">
                        <div className="flex items-center gap-2">
                          <span className="h-6 w-6 rounded-md bg-blue-100 text-blue-700 font-bold text-xs flex items-center justify-center">
                            {u.unit_number}
                          </span>
                          <h4 className="font-semibold text-sm text-slate-800">{u.name}</h4>
                        </div>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => {
                            setSelectedUnitId(u.id);
                            setIsCreateTopicOpen(true);
                          }}
                        >
                          <Plus className="h-3.5 w-3.5 mr-1" />
                          Add Topic
                        </Button>
                      </div>

                      {/* Topics list */}
                      <div className="mt-3 space-y-2 pl-3">
                        {u.topics?.map((t: any) => (
                          <div key={t.id} className="p-2.5 rounded-lg bg-white border border-slate-200/80 flex items-center justify-between">
                            <div>
                              <p className="text-xs font-semibold text-slate-800">{t.name}</p>
                              {t.description && <p className="text-[11px] text-slate-500 mt-0.5">{t.description}</p>}
                            </div>
                            <span className="text-[10px] text-slate-400">
                              {t.subtopics?.length || 0} subtopics
                            </span>
                          </div>
                        ))}

                        {(!u.topics || u.topics.length === 0) && (
                          <p className="text-xs text-slate-400 italic py-2">No topics added to this unit yet.</p>
                        )}
                      </div>
                    </div>
                  ))}

                  {(!syllabusTree?.units || syllabusTree.units.length === 0) && (
                    <div className="text-center py-12">
                      <FolderTree className="h-10 w-10 text-slate-300 mx-auto mb-2" />
                      <p className="text-sm font-medium text-slate-600">No units defined for this subject.</p>
                      <p className="text-xs text-slate-400 mt-1">Start by adding Unit 1 above.</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ) : (
            <div className="h-64 flex items-center justify-center text-slate-400 text-sm border-2 border-dashed border-slate-200 rounded-xl">
              Select a subject to inspect and manage syllabus units and topics.
            </div>
          )}
        </div>
      </div>

      {/* Modal: Create Subject */}
      <Modal isOpen={isCreateSubjOpen} onClose={() => setIsCreateSubjOpen(false)} title="Create New Subject">
        <form onSubmit={handleCreateSubject} className="space-y-4">
          <Input label="Subject Name" value={subjName} onChange={(e) => setSubjName(e.target.value)} required placeholder="e.g. Operating Systems" />
          <Input label="Course Code" value={subjCode} onChange={(e) => setSubjCode(e.target.value)} placeholder="e.g. CS402" />
          <div className="space-y-1.5">
            <label className="block text-xs font-medium text-slate-700">Description</label>
            <textarea
              className="w-full rounded-lg border border-slate-300 p-2.5 text-sm"
              rows={3}
              value={subjDesc}
              onChange={(e) => setSubjDesc(e.target.value)}
              placeholder="Brief course objectives..."
            />
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <Button type="button" variant="ghost" onClick={() => setIsCreateSubjOpen(false)}>Cancel</Button>
            <Button type="submit">Create Subject</Button>
          </div>
        </form>
      </Modal>

      {/* Modal: Create Unit */}
      <Modal isOpen={isCreateUnitOpen} onClose={() => setIsCreateUnitOpen(false)} title={`Add Unit to ${selectedSubject?.name}`}>
        <form onSubmit={handleCreateUnit} className="space-y-4">
          <Input label="Unit Number" type="number" min={1} value={unitNumber} onChange={(e) => setUnitNumber(parseInt(e.target.value))} required />
          <Input label="Unit Title" value={unitName} onChange={(e) => setUnitName(e.target.value)} required placeholder="e.g. Process Management & Concurrency" />
          <div className="flex justify-end gap-2 pt-2">
            <Button type="button" variant="ghost" onClick={() => setIsCreateUnitOpen(false)}>Cancel</Button>
            <Button type="submit">Save Unit</Button>
          </div>
        </form>
      </Modal>

      {/* Modal: Create Topic */}
      <Modal isOpen={isCreateTopicOpen} onClose={() => setIsCreateTopicOpen(false)} title="Add Syllabus Topic">
        <form onSubmit={handleCreateTopic} className="space-y-4">
          <Input label="Topic Name" value={topicName} onChange={(e) => setTopicName(e.target.value)} required placeholder="e.g. CPU Scheduling Algorithms" />
          <Input label="Subtopics / Description" value={topicDesc} onChange={(e) => setTopicDesc(e.target.value)} placeholder="e.g. FCFS, SJF, Round Robin, Priority" />
          <div className="flex justify-end gap-2 pt-2">
            <Button type="button" variant="ghost" onClick={() => setIsCreateTopicOpen(false)}>Cancel</Button>
            <Button type="submit">Save Topic</Button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
