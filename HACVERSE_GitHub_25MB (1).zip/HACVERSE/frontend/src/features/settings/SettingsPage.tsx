import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardContent } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { Badge } from '../../components/ui/Badge';
import { Input } from '../../components/ui/Input';
import { settingsApi } from '../../services/api';
import {
  Settings,
  Cpu,
  Key,
  Sliders,
  CheckCircle2,
  AlertCircle,
  Activity,
  Server,
  Save,
  HelpCircle
} from 'lucide-react';

export const SettingsPage: React.FC = () => {
  const [provider, setProvider] = useState<string>('gemini');
  const [modelName, setModelName] = useState<string>('gemini-2.0-flash');
  const [apiKey, setApiKey] = useState<string>('');
  const [ollamaUrl, setOllamaUrl] = useState<string>('http://localhost:11434');

  // Calibration settings
  const [minAttempts, setMinAttempts] = useState<number>(10);
  const [easyThreshold, setEasyThreshold] = useState<number>(0.70);
  const [hardThreshold, setHardThreshold] = useState<number>(0.40);

  const [loading, setLoading] = useState<boolean>(true);
  const [saving, setSaving] = useState<boolean>(false);
  const [testing, setTesting] = useState<boolean>(false);
  const [testResult, setTestResult] = useState<{ success: boolean; message: string } | null>(null);
  const [saveSuccess, setSaveSuccess] = useState<boolean>(false);

  useEffect(() => {
    fetchSettings();
  }, []);

  const fetchSettings = async () => {
    try {
      setLoading(true);
      const res = await settingsApi.get();
      if (res.data) {
        setProvider(res.data.ai_provider || 'gemini');
        setModelName(res.data.ai_model || 'gemini-2.0-flash');
        setOllamaUrl(res.data.ollama_base_url || 'http://localhost:11434');
        setMinAttempts(res.data.min_calibration_attempts || 10);
        setEasyThreshold(res.data.easy_threshold || 0.70);
        setHardThreshold(res.data.hard_threshold || 0.40);
      }
    } catch (err) {
      console.error('Error fetching settings:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleProviderChange = (p: string) => {
    setProvider(p);
    setTestResult(null);
    if (p === 'gemini') setModelName('gemini-2.0-flash');
    else if (p === 'openai') setModelName('gpt-4o-mini');
    else if (p === 'anthropic') setModelName('claude-3-5-sonnet-20241022');
    else if (p === 'groq') setModelName('llama-3.3-70b-versatile');
    else if (p === 'openrouter') setModelName('anthropic/claude-3.5-sonnet');
    else if (p === 'ollama') setModelName('llama3:latest');
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setSaving(true);
      setSaveSuccess(false);
      await settingsApi.update({
        ai_provider: provider,
        ai_model: modelName,
        api_key: apiKey ? apiKey : undefined,
        ollama_base_url: ollamaUrl,
        min_calibration_attempts: Number(minAttempts),
        easy_threshold: Number(easyThreshold),
        hard_threshold: Number(hardThreshold),
      });
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 4000);
    } catch (err: any) {
      alert(err.response?.data?.detail || 'Failed to save system settings');
    } finally {
      setSaving(false);
    }
  };

  const handleTestConnection = async () => {
    try {
      setTesting(true);
      setTestResult(null);
      const res = await settingsApi.testAi({
        provider,
        model: modelName,
        api_key: apiKey || undefined,
        ollama_url: ollamaUrl,
      });
      setTestResult({
        success: res.data.success,
        message: res.data.message || (res.data.success ? 'AI Provider connected and verified successfully!' : 'Provider responded with an error.'),
      });
    } catch (err: any) {
      setTestResult({
        success: false,
        message: err.response?.data?.detail || 'Failed to connect to AI provider.',
      });
    } finally {
      setTesting(false);
    }
  };

  return (
    <div className="space-y-6 max-w-4xl">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-slate-900">
          System & AI Provider Configuration
        </h1>
        <p className="text-sm text-slate-500">
          Configure multi-provider LLM backends (Gemini, OpenAI, Claude, Groq, Ollama) and psychometric calibration thresholds.
        </p>
      </div>

      {saveSuccess && (
        <div className="p-3 bg-emerald-50 text-emerald-800 text-sm rounded-lg border border-emerald-200 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>System configuration successfully saved and loaded into active backend.</span>
        </div>
      )}

      <form onSubmit={handleSave} className="space-y-6">
        {/* Card 1: Multi-Provider AI Settings */}
        <Card>
          <CardHeader className="border-b border-slate-100 pb-3">
            <h2 className="font-semibold text-slate-900 text-sm flex items-center gap-2">
              <Cpu className="w-4 h-4 text-blue-600" />
              Multi-Provider Generative AI Architecture
            </h2>
            <p className="text-xs text-slate-500">
              Select your AI runtime. Switch between Google Gemini, OpenAI, Anthropic, Groq, or self-hosted local Ollama with zero code changes.
            </p>
          </CardHeader>
          <CardContent className="pt-4 space-y-4">
            <div>
              <label className="block text-xs font-semibold uppercase text-slate-500 mb-1.5">
                Active AI Provider Engine
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {[
                  { id: 'gemini', name: 'Google Gemini', desc: 'google-genai SDK' },
                  { id: 'openai', name: 'OpenAI', desc: 'GPT-4o & Mini' },
                  { id: 'anthropic', name: 'Anthropic Claude', desc: 'Claude 3.5 Sonnet' },
                  { id: 'groq', name: 'Groq Cloud', desc: 'Ultra-fast LPU' },
                  { id: 'openrouter', name: 'OpenRouter', desc: 'Unified API' },
                  { id: 'ollama', name: 'Ollama (Local)', desc: 'Self-hosted LLMs' },
                ].map((p) => {
                  const isSelected = provider === p.id;
                  return (
                    <button
                      type="button"
                      key={p.id}
                      onClick={() => handleProviderChange(p.id)}
                      className={`p-3 rounded-lg border text-left transition-all ${
                        isSelected
                          ? 'bg-blue-50 border-blue-500 ring-2 ring-blue-500/20'
                          : 'bg-white border-slate-200 hover:bg-slate-50'
                      }`}
                    >
                      <div className="font-semibold text-xs text-slate-900">{p.name}</div>
                      <div className="text-[10px] text-slate-400 mt-0.5">{p.desc}</div>
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold uppercase text-slate-500 mb-1">
                  Model Identifier *
                </label>
                <Input
                  value={modelName}
                  onChange={(e) => setModelName(e.target.value)}
                  placeholder="e.g. gemini-2.0-flash, gpt-4o-mini"
                  required
                />
              </div>

              {provider !== 'ollama' ? (
                <div>
                  <label className="block text-xs font-semibold uppercase text-slate-500 mb-1">
                    API Key (Leave empty to use .env key)
                  </label>
                  <Input
                    type="password"
                    value={apiKey}
                    onChange={(e) => setApiKey(e.target.value)}
                    placeholder="••••••••••••••••••••••••"
                  />
                </div>
              ) : (
                <div>
                  <label className="block text-xs font-semibold uppercase text-slate-500 mb-1">
                    Ollama Host Endpoint
                  </label>
                  <Input
                    value={ollamaUrl}
                    onChange={(e) => setOllamaUrl(e.target.value)}
                    placeholder="http://localhost:11434"
                  />
                </div>
              )}
            </div>

            {/* Test Connection */}
            <div className="pt-2 flex items-center justify-between">
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={handleTestConnection}
                disabled={testing}
              >
                <Activity className="w-3.5 h-3.5 mr-1.5" />
                {testing ? 'Testing Endpoint...' : 'Test AI Connection'}
              </Button>

              {testResult && (
                <div
                  className={`text-xs flex items-center gap-1.5 font-medium ${
                    testResult.success ? 'text-emerald-700' : 'text-red-600'
                  }`}
                >
                  {testResult.success ? (
                    <CheckCircle2 className="w-4 h-4 shrink-0" />
                  ) : (
                    <AlertCircle className="w-4 h-4 shrink-0" />
                  )}
                  <span>{testResult.message}</span>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Card 2: Adaptive Difficulty & Wilson Score Calibration Thresholds */}
        <Card>
          <CardHeader className="border-b border-slate-100 pb-3">
            <h2 className="font-semibold text-slate-900 text-sm flex items-center gap-2">
              <Sliders className="w-4 h-4 text-emerald-600" />
              Psychometric Calibration Thresholds
            </h2>
            <p className="text-xs text-slate-500">
              Configure parameters governing when cold-start predictions transition to verified empirical calibration.
            </p>
          </CardHeader>
          <CardContent className="pt-4 space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-semibold uppercase text-slate-500 mb-1">
                  Minimum Cohort Sample Size
                </label>
                <Input
                  type="number"
                  value={minAttempts}
                  onChange={(e) => setMinAttempts(Number(e.target.value))}
                  min={5}
                  max={100}
                  required
                />
                <p className="text-[10px] text-slate-400 mt-1">Default: 10 attempts</p>
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase text-slate-500 mb-1">
                  Easy Threshold (Success Rate &gt;)
                </label>
                <Input
                  type="number"
                  step="0.05"
                  value={easyThreshold}
                  onChange={(e) => setEasyThreshold(Number(e.target.value))}
                  min={0.5}
                  max={0.95}
                  required
                />
                <p className="text-[10px] text-slate-400 mt-1">e.g. 0.70 (70% pass)</p>
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase text-slate-500 mb-1">
                  Hard Threshold (Success Rate &lt;)
                </label>
                <Input
                  type="number"
                  step="0.05"
                  value={hardThreshold}
                  onChange={(e) => setHardThreshold(Number(e.target.value))}
                  min={0.1}
                  max={0.5}
                  required
                />
                <p className="text-[10px] text-slate-400 mt-1">e.g. 0.40 (40% pass)</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Submit */}
        <div className="flex justify-end">
          <Button type="submit" disabled={saving} className="bg-slate-900 hover:bg-slate-800">
            <Save className="w-4 h-4 mr-2" />
            {saving ? 'Applying Settings...' : 'Save Configuration'}
          </Button>
        </div>
      </form>
    </div>
  );
};
