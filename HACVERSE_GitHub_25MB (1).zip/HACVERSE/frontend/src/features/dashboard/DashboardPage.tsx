import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../../services/api';
import { Card, CardHeader, CardTitle, CardContent } from '../../components/ui/Card';
import { Badge } from '../../components/ui/Badge';
import { Button } from '../../components/ui/Button';
import { DashboardStats } from '../../types';
import {
  BookOpen,
  FileText,
  Database,
  GraduationCap,
  Scale,
  Sparkles,
  ArrowRight,
  TrendingUp,
  Activity,
  CheckCircle2,
  Clock
} from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend } from 'recharts';

export const DashboardPage: React.FC = () => {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [distribution, setDistribution] = useState<any>(null);
  const [activities, setActivities] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      setLoading(true);
      const [statsRes, distRes, actRes] = await Promise.all([
        api.get('/dashboard/stats'),
        api.get('/dashboard/question-distribution'),
        api.get('/dashboard/activity')
      ]);
      setStats(statsRes.data);
      setDistribution(distRes.data);
      setActivities(actRes.data);
    } catch (err) {
      console.error('Failed to load dashboard data:', err);
    } finally {
      setLoading(false);
    }
  };

  const chartData = distribution
    ? [
        {
          name: 'Easy',
          'AI Predicted': distribution.ai_predicted?.easy || 0,
          'Observed Student Evidence': distribution.performance_observed?.easy || 0,
        },
        {
          name: 'Medium',
          'AI Predicted': distribution.ai_predicted?.medium || 0,
          'Observed Student Evidence': distribution.performance_observed?.medium || 0,
        },
        {
          name: 'Hard',
          'AI Predicted': distribution.ai_predicted?.hard || 0,
          'Observed Student Evidence': distribution.performance_observed?.hard || 0,
        },
      ]
    : [];

  return (
    <div className="space-y-8">
      {/* Welcome Hero */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-slate-900">Academic Overview</h2>
          <p className="text-sm text-slate-500 mt-1">
            Real-time assessment intelligence, cold-start difficulty tracking, and student performance calibration.
          </p>
        </div>
        <div className="flex gap-3">
          <Link to="/generate">
            <Button className="shadow-sm">
              <Sparkles className="h-4 w-4 mr-2" />
              Generate Questions
            </Button>
          </Link>
          <Link to="/calibration">
            <Button variant="outline">
              <Scale className="h-4 w-4 mr-2" />
              Run Calibration
            </Button>
          </Link>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        <Card className="border-l-4 border-l-blue-500">
          <CardContent className="p-5 flex items-center justify-between">
            <div>
              <p className="text-xs font-medium text-slate-500 uppercase tracking-wider">Subjects Active</p>
              <h3 className="text-2xl font-bold text-slate-900 mt-1">{stats?.total_subjects ?? 0}</h3>
              <p className="text-xs text-slate-400 mt-1">{stats?.total_documents ?? 0} syllabus documents</p>
            </div>
            <div className="p-3 bg-blue-50 rounded-xl text-blue-600">
              <BookOpen className="h-6 w-6" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-indigo-500">
          <CardContent className="p-5 flex items-center justify-between">
            <div>
              <p className="text-xs font-medium text-slate-500 uppercase tracking-wider">Total Questions</p>
              <h3 className="text-2xl font-bold text-slate-900 mt-1">{stats?.total_questions ?? 0}</h3>
              <div className="flex items-center gap-2 mt-1">
                <Badge variant="success" size="sm">{stats?.approved_questions ?? 0} approved</Badge>
                <Badge variant="warning" size="sm">{stats?.pending_questions ?? 0} pending</Badge>
              </div>
            </div>
            <div className="p-3 bg-indigo-50 rounded-xl text-indigo-600">
              <Database className="h-6 w-6" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-emerald-500">
          <CardContent className="p-5 flex items-center justify-between">
            <div>
              <p className="text-xs font-medium text-slate-500 uppercase tracking-wider">Student Responses</p>
              <h3 className="text-2xl font-bold text-slate-900 mt-1">{stats?.total_responses ?? 0}</h3>
              <p className="text-xs text-emerald-600 font-medium mt-1">Real attempt records</p>
            </div>
            <div className="p-3 bg-emerald-50 rounded-xl text-emerald-600">
              <Activity className="h-6 w-6" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-amber-500">
          <CardContent className="p-5 flex items-center justify-between">
            <div>
              <p className="text-xs font-medium text-slate-500 uppercase tracking-wider">Calibrated Questions</p>
              <h3 className="text-2xl font-bold text-slate-900 mt-1">{stats?.questions_with_evidence ?? 0}</h3>
              <p className="text-xs text-slate-400 mt-1">with ≥ 10 valid student attempts</p>
            </div>
            <div className="p-3 bg-amber-50 rounded-xl text-amber-600">
              <Scale className="h-6 w-6" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Charts & Activity Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Difficulty Distribution Chart */}
        <div className="lg:col-span-2">
          <Card className="h-full">
            <CardHeader>
              <div>
                <CardTitle>Difficulty Estimation vs. Performance Evidence</CardTitle>
                <p className="text-xs text-slate-500 mt-0.5">
                  Comparison between cold-start AI predictions and real student-observed difficulty.
                </p>
              </div>
            </CardHeader>
            <CardContent>
              {chartData.length > 0 ? (
                <div className="h-72 w-full pt-4">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={chartData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                      <XAxis dataKey="name" stroke="#94A3B8" fontSize={12} tickLine={false} />
                      <YAxis stroke="#94A3B8" fontSize={12} tickLine={false} />
                      <Tooltip
                        contentStyle={{ backgroundColor: '#1E293B', color: '#FFF', borderRadius: '8px', border: 'none' }}
                        itemStyle={{ color: '#FFF' }}
                      />
                      <Legend wrapperStyle={{ fontSize: '12px', paddingTop: '10px' }} />
                      <Bar dataKey="AI Predicted" fill="#93C5FD" radius={[4, 4, 0, 0]} />
                      <Bar dataKey="Observed Student Evidence" fill="#2563EB" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              ) : (
                <div className="h-64 flex flex-col items-center justify-center text-slate-400 text-sm">
                  <TrendingUp className="h-10 w-10 text-slate-300 mb-2" />
                  No question distribution data available yet.
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Real Activity Stream */}
        <div>
          <Card className="h-full">
            <CardHeader>
              <CardTitle>Audit & Activity Log</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4 max-h-80 overflow-y-auto pr-1">
                {activities.length > 0 ? (
                  activities.map((act) => (
                    <div key={act.id} className="flex items-start gap-3 text-xs border-b border-slate-100 pb-3 last:border-none">
                      <div className="mt-0.5 p-1 rounded-full bg-blue-50 text-blue-600 flex-shrink-0">
                        <Clock className="h-3.5 w-3.5" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-semibold text-slate-800 capitalize truncate">
                          {act.action.replace(/_/g, ' ')}
                        </p>
                        <p className="text-slate-500 text-[11px]">
                          Entity: {act.entity_type} {act.entity_id ? `#${act.entity_id}` : ''}
                        </p>
                        <span className="text-[10px] text-slate-400">
                          {new Date(act.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                    </div>
                  ))
                ) : (
                  <p className="text-xs text-slate-400 text-center py-8">No recent activity recorded.</p>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};
