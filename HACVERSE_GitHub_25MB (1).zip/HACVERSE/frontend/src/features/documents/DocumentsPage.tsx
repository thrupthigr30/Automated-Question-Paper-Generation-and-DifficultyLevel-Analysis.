import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardHeader, CardContent } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { Badge } from '../../components/ui/Badge';
import { Modal } from '../../components/ui/Modal';
import { Input } from '../../components/ui/Input';
import { documentsApi, subjectsApi } from '../../services/api';
import { Document, Chunk, Subject } from '../../types';
import {
  Upload,
  FileText,
  Trash2,
  Eye,
  RefreshCw,
  AlertCircle,
  CheckCircle2,
  Sparkles,
  Files
} from 'lucide-react';

export const DocumentsPage: React.FC = () => {
  const navigate = useNavigate();
  const [documents, setDocuments] = useState<Document[]>([]);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [selectedSubjectId, setSelectedSubjectId] = useState<number | ''>('');
  const [loading, setLoading] = useState<boolean>(true);
  const [uploadModalOpen, setUploadModalOpen] = useState<boolean>(false);
  const [chunksModalOpen, setChunksModalOpen] = useState<boolean>(false);
  const [selectedDoc, setSelectedDoc] = useState<Document | null>(null);
  const [chunks, setChunks] = useState<Chunk[]>([]);
  const [loadingChunks, setLoadingChunks] = useState<boolean>(false);

  // Selected documents for batch question generation
  const [selectedDocIds, setSelectedDocIds] = useState<number[]>([]);

  // Multi-upload form state
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [subjectId, setSubjectId] = useState<number | ''>('');
  const [category, setCategory] = useState<string>('textbook');
  const [uploading, setUploading] = useState<boolean>(false);
  const [uploadError, setUploadError] = useState<string | null>(null);

  useEffect(() => {
    fetchInitialData();
  }, []);

  const fetchInitialData = async () => {
    try {
      setLoading(true);
      const [docsRes, subjectsRes] = await Promise.all([
        documentsApi.list(),
        subjectsApi.list(),
      ]);
      setDocuments(docsRes.data);
      setSubjects(subjectsRes.data);
      if (subjectsRes.data.length > 0 && !selectedSubjectId) {
        setSelectedSubjectId(subjectsRes.data[0].id);
      }
    } catch (err) {
      console.error('Error fetching documents data:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleFilter = async (sId: number | '') => {
    setSelectedSubjectId(sId);
    try {
      setLoading(true);
      const res = await documentsApi.list(sId ? sId : undefined);
      setDocuments(res.data);
    } catch (err) {
      console.error('Error filtering documents:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setSelectedFiles(Array.from(e.target.files));
    }
  };

  const handleUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedFiles.length === 0 || !subjectId) {
      setUploadError('Please select at least one document and choose a subject.');
      return;
    }

    try {
      setUploading(true);
      setUploadError(null);

      const formData = new FormData();
      formData.append('subject_id', String(subjectId));
      formData.append('category', category);
      selectedFiles.forEach((f) => {
        formData.append('files', f);
      });

      await documentsApi.uploadMultiple(formData);
      setUploadModalOpen(false);
      setSelectedFiles([]);
      fetchInitialData();
    } catch (err: any) {
      setUploadError(err.response?.data?.detail || 'Failed to upload documents');
    } finally {
      setUploading(false);
    }
  };

  const handleViewChunks = async (doc: Document) => {
    setSelectedDoc(doc);
    setChunksModalOpen(true);
    setLoadingChunks(true);
    try {
      const res = await documentsApi.getChunks(doc.id);
      setChunks(res.data);
    } catch (err) {
      console.error('Error fetching chunks:', err);
    } finally {
      setLoadingChunks(false);
    }
  };

  const handleReprocess = async (id: number) => {
    try {
      await documentsApi.process(id);
      fetchInitialData();
    } catch (err) {
      console.error('Error processing document:', err);
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm('Are you sure you want to delete this document and all its chunks?')) return;
    try {
      await documentsApi.delete(id);
      fetchInitialData();
    } catch (err) {
      console.error('Error deleting document:', err);
    }
  };

  const toggleSelectDoc = (id: number) => {
    if (selectedDocIds.includes(id)) {
      setSelectedDocIds(selectedDocIds.filter((item) => item !== id));
    } else {
      setSelectedDocIds([...selectedDocIds, id]);
    }
  };

  const handleGenerateFromSelected = () => {
    const sId = selectedSubjectId || (documents[0]?.subject_id || '');
    navigate(`/generate?subject_id=${sId}&doc_ids=${selectedDocIds.join(',')}`);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">Academic Resources</h1>
          <p className="text-sm text-slate-500">
            Upload multiple textbooks, lecture slides, and notes (PDF, DOCX, TXT) to ground intelligent question synthesis.
          </p>
        </div>
        <div className="flex items-center gap-2">
          {selectedDocIds.length > 0 && (
            <Button
              variant="default"
              onClick={handleGenerateFromSelected}
              className="bg-purple-600 hover:bg-purple-700"
            >
              <Sparkles className="w-4 h-4 mr-2" />
              Generate from {selectedDocIds.length} Selected Documents
            </Button>
          )}
          <Button onClick={() => setUploadModalOpen(true)}>
            <Upload className="w-4 h-4 mr-2" />
            Upload Documents
          </Button>
        </div>
      </div>

      {/* Filter and stats */}
      <div className="flex items-center justify-between gap-4 bg-white p-4 rounded-lg border border-slate-200">
        <div className="flex items-center gap-2">
          <label className="text-sm font-medium text-slate-700">Filter by Subject:</label>
          <select
            value={selectedSubjectId}
            onChange={(e) => handleFilter(e.target.value ? Number(e.target.value) : '')}
            className="text-sm border border-slate-300 rounded-md px-3 py-1.5 focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="">All Subjects</option>
            {subjects.map((sub) => (
              <option key={sub.id} value={sub.id}>
                {sub.name} ({sub.code})
              </option>
            ))}
          </select>
        </div>
        <div className="text-sm text-slate-500">
          Showing <span className="font-semibold text-slate-900">{documents.length}</span> documents
        </div>
      </div>

      {/* Documents Table */}
      <Card>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-sm">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50/75 text-slate-600 font-semibold">
                <th className="py-3 px-4 w-10">
                  <input
                    type="checkbox"
                    checked={documents.length > 0 && selectedDocIds.length === documents.length}
                    onChange={(e) => {
                      if (e.target.checked) setSelectedDocIds(documents.map((d) => d.id));
                      else setSelectedDocIds([]);
                    }}
                    className="rounded accent-blue-600"
                  />
                </th>
                <th className="py-3 px-4">Document Title & Filename</th>
                <th className="py-3 px-4">Subject</th>
                <th className="py-3 px-4">Type & Size</th>
                <th className="py-3 px-4">Extraction Status</th>
                <th className="py-3 px-4">Chunks</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {loading ? (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-slate-400">Loading resources...</td>
                </tr>
              ) : documents.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-slate-500">
                    No documents found. Click "Upload Documents" to add course materials.
                  </td>
                </tr>
              ) : (
                documents.map((doc) => {
                  const isChecked = selectedDocIds.includes(doc.id);
                  return (
                    <tr key={doc.id} className={`hover:bg-slate-50 transition-colors ${isChecked ? 'bg-blue-50/40' : ''}`}>
                      <td className="py-3 px-4">
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={() => toggleSelectDoc(doc.id)}
                          className="rounded accent-blue-600"
                        />
                      </td>
                      <td className="py-3 px-4">
                        <div className="font-medium text-slate-900 flex items-center gap-2">
                          <FileText className="w-4 h-4 text-blue-600 shrink-0" />
                          <span>{doc.original_filename || doc.filename}</span>
                        </div>
                        <div className="text-xs text-slate-400 mt-0.5">{doc.filename}</div>
                      </td>
                      <td className="py-3 px-4">
                        <span className="text-slate-700">{doc.subject?.name || 'Assigned Subject'}</span>
                      </td>
                      <td className="py-3 px-4">
                        <Badge variant="outline" className="uppercase font-mono text-[10px]">
                          {doc.file_extension || doc.file_type || 'PDF'}
                        </Badge>
                        <span className="text-xs text-slate-400 ml-2">
                          {doc.file_size ? (doc.file_size / 1024).toFixed(1) : '0'} KB
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        {(doc.processing_status === 'completed' || doc.processing_status === 'PROCESSED') && (
                          <Badge variant="success" className="gap-1">
                            <CheckCircle2 className="w-3 h-3" /> Processed
                          </Badge>
                        )}
                        {(doc.processing_status === 'pending' || doc.processing_status === 'PENDING') && (
                          <Badge variant="warning" className="gap-1">
                            <RefreshCw className="w-3 h-3 animate-spin" /> Pending
                          </Badge>
                        )}
                        {(doc.processing_status === 'failed' || doc.processing_status === 'FAILED') && (
                          <Badge variant="danger" className="gap-1">
                            <AlertCircle className="w-3 h-3" /> Failed
                          </Badge>
                        )}
                      </td>
                      <td className="py-3 px-4 font-mono text-xs">
                        {doc.chunk_count || 0} chunks
                      </td>
                      <td className="py-3 px-4 text-right space-x-1">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => navigate(`/generate?subject_id=${doc.subject_id}&doc_ids=${doc.id}`)}
                          className="text-purple-700 hover:bg-purple-50"
                          title="Generate Questions from this document"
                        >
                          <Sparkles className="w-3.5 h-3.5 mr-1" /> Generate
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleViewChunks(doc)}
                          title="Inspect Chunks"
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleReprocess(doc.id)}
                          title="Reprocess Document"
                        >
                          <RefreshCw className="w-3.5 h-3.5" />
                        </Button>
                        <Button
                          variant="destructive"
                          size="sm"
                          onClick={() => handleDelete(doc.id)}
                          title="Delete Document"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </Button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </Card>

      {/* Multiple Upload Modal */}
      <Modal
        isOpen={uploadModalOpen}
        onClose={() => setUploadModalOpen(false)}
        title="Upload Academic Materials (Batch Supported)"
      >
        <form onSubmit={handleUpload} className="space-y-4">
          {uploadError && (
            <div className="p-3 bg-red-50 text-red-700 text-sm rounded border border-red-200">
              {uploadError}
            </div>
          )}

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">
              Select Subject *
            </label>
            <select
              value={subjectId}
              onChange={(e) => setSubjectId(e.target.value ? Number(e.target.value) : '')}
              required
              className="w-full text-sm border border-slate-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="">Choose Course</option>
              {subjects.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name} ({s.code})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">
              Material Category
            </label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="w-full text-sm border border-slate-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="textbook">Textbook</option>
              <option value="lecture_notes">Lecture Notes</option>
              <option value="syllabus">Syllabus Outline</option>
              <option value="research_paper">Reference Paper</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">
              Select One or Multiple Files (PDF, DOCX, TXT, MD) *
            </label>
            <input
              type="file"
              multiple
              accept=".pdf,.docx,.doc,.txt,.md"
              onChange={handleFileChange}
              required
              className="w-full text-sm text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
            />
            {selectedFiles.length > 0 && (
              <div className="mt-2 p-2.5 bg-slate-50 rounded border border-slate-200 text-xs space-y-1">
                <div className="font-semibold text-slate-700">
                  {selectedFiles.length} file(s) selected for batch upload:
                </div>
                <ul className="list-disc list-inside text-slate-500 max-h-24 overflow-y-auto">
                  {selectedFiles.map((f, i) => (
                    <li key={i}>{f.name} ({(f.size / 1024).toFixed(1)} KB)</li>
                  ))}
                </ul>
              </div>
            )}
            <p className="text-xs text-slate-400 mt-1">
              All files are automatically parsed with PyMuPDF, indexed for tokens, and chunked for question generation.
            </p>
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t border-slate-100">
            <Button
              type="button"
              variant="outline"
              onClick={() => setUploadModalOpen(false)}
            >
              Cancel
            </Button>
            <Button type="submit" disabled={uploading}>
              {uploading ? 'Processing & Chunking Documents...' : `Upload & Process ${selectedFiles.length || ''} File(s)`}
            </Button>
          </div>
        </form>
      </Modal>

      {/* Chunk Inspector Modal */}
      <Modal
        isOpen={chunksModalOpen}
        onClose={() => setChunksModalOpen(false)}
        title={`Grounding Chunks: ${selectedDoc?.original_filename || selectedDoc?.filename || ''}`}
      >
        <div className="space-y-4 max-h-[70vh] overflow-y-auto pr-1">
          <p className="text-xs text-slate-500">
            Extracted text segments indexed for context retrieval and syllabus-grounded question synthesis.
          </p>

          {loadingChunks ? (
            <div className="py-8 text-center text-slate-400">Loading document chunks...</div>
          ) : chunks.length === 0 ? (
            <div className="py-8 text-center text-slate-500">No chunks available for this document.</div>
          ) : (
            <div className="space-y-3">
              {chunks.map((chunk) => (
                <div
                  key={chunk.id}
                  className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-xs space-y-2"
                >
                  <div className="flex justify-between items-center text-slate-500 font-mono">
                    <span>Chunk #{chunk.chunk_index + 1} {chunk.page_number ? `(Page ${chunk.page_number})` : ''}</span>
                    <span>{chunk.token_count || chunk.content?.length || 0} chars/tokens</span>
                  </div>
                  <div className="text-slate-800 leading-relaxed font-sans bg-white p-2.5 rounded border border-slate-100 whitespace-pre-wrap">
                    {chunk.content}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </Modal>
    </div>
  );
};
