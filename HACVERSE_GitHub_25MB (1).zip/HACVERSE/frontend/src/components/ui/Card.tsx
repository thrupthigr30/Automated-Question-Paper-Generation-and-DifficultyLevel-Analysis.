import React from 'react';
import { clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';

interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  children: React.ReactNode;
}

export const Card: React.FC<CardProps> = ({ children, className, ...props }) => (
  <div className={twMerge(clsx("bg-white border border-slate-200/80 rounded-xl shadow-sm", className))} {...props}>
    {children}
  </div>
);

export const CardHeader: React.FC<CardProps> = ({ children, className, ...props }) => (
  <div className={twMerge(clsx("px-5 py-4 border-b border-slate-100 flex items-center justify-between", className))} {...props}>
    {children}
  </div>
);

export const CardTitle: React.FC<React.HTMLAttributes<HTMLHeadingElement>> = ({ children, className, ...props }) => (
  <h3 className={twMerge(clsx("text-base font-semibold text-slate-900 tracking-tight", className))} {...props}>
    {children}
  </h3>
);

export const CardContent: React.FC<CardProps> = ({ children, className, ...props }) => (
  <div className={twMerge(clsx("p-5", className))} {...props}>
    {children}
  </div>
);
