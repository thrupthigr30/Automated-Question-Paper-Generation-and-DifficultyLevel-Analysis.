import axios from 'axios';

export const API_BASE_URL = 'http://127.0.0.1:8000/api';

const api = axios.create({
  baseURL: API_BASE_URL,
});

// Interceptor to attach Authorization Bearer token from localStorage
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token') || localStorage.getItem('hacverse_token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Interceptor to handle 401 unauthorized
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response && error.response.status === 401) {
      if (!window.location.pathname.includes('/login') && !window.location.pathname.includes('/register')) {
        localStorage.removeItem('token');
        localStorage.removeItem('hacverse_token');
        localStorage.removeItem('user');
        localStorage.removeItem('hacverse_user');
        window.location.href = '/login';
      }
    }
    return Promise.reject(error);
  }
);

export const authApi = {
  login: (data: any) => api.post('/auth/login', data),
  register: (data: any) => api.post('/auth/register', data),
  me: () => api.get('/auth/me'),
};

export const subjectsApi = {
  list: () => api.get('/subjects'),
  get: (id: number) => api.get(`/subjects/${id}`),
  create: (data: any) => api.post('/subjects', data),
  delete: (id: number) => api.delete(`/subjects/${id}`),
  createUnit: (subjectId: number, data: any) => api.post(`/subjects/${subjectId}/units`, data),
  createTopic: (unitId: number, data: any) => api.post(`/subjects/units/${unitId}/topics`, data),
};

export const documentsApi = {
  list: (subjectId?: number) => api.get('/documents', { params: { subject_id: subjectId } }),
  get: (id: number) => api.get(`/documents/${id}`),
  upload: (formData: FormData) => api.post('/documents/upload', formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  }),
  uploadMultiple: (formData: FormData) => api.post('/documents/upload-batch', formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  }),
  getChunks: (id: number) => api.get(`/documents/${id}/chunks`),
  process: (id: number) => api.post(`/documents/${id}/process`),
  delete: (id: number) => api.delete(`/documents/${id}`),
};

export const questionsApi = {
  list: (params?: any) => api.get('/questions', { params }),
  get: (id: number) => api.get(`/questions/${id}`),
  generate: (data: any) => api.post('/questions/generate', data),
  create: (data: any) => api.post('/questions', data),
  approve: (id: number, data: any) => api.put(`/questions/${id}/approve`, data),
  delete: (id: number) => api.delete(`/questions/${id}`),
};

export const pyqApi = {
  listPapers: (subjectId?: number) => api.get('/pyq/papers', { params: { subject_id: subjectId } }),
  uploadPaper: (formData: FormData) => api.post('/pyq/papers/upload', formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  }),
  parsePaper: (id: number) => api.post(`/pyq/papers/${id}/parse`),
  getTopicFrequency: (subjectId: number) => api.get(`/pyq/topic-frequency/${subjectId}`),
  getRepetitions: (subjectId: number) => api.get(`/pyq/repetitions/${subjectId}`),
};

export const datasetsApi = {
  getStats: () => api.get('/datasets/stats'),
  preview: (name: string, limit: number = 25) => api.get(`/datasets/preview/${name}`, { params: { limit } }),
  export: (name: string, format: string) => api.get(`/datasets/export/${name}`, {
    params: { format },
    responseType: 'blob',
  }),
  generateSynthetic: (data?: any) => api.post('/datasets/synthetic/generate', data || {}),
  purgeSynthetic: () => api.post('/datasets/synthetic/purge'),
};

export const examinationsApi = {
  list: () => api.get('/examinations'),
  get: (id: number) => api.get(`/examinations/${id}`),
  create: (data: any) => api.post('/examinations', data),
  publish: (id: number) => api.post(`/examinations/${id}/publish`),
  delete: (id: number) => api.delete(`/examinations/${id}`),
};

export const assessmentsApi = {
  start: (data: { examination_id: number }) => api.post('/assessments/start', data),
  submit: (id: number, data: any) => api.post(`/assessments/${id}/submit`, data),
  evaluate: (id: number, data: any) => api.put(`/assessments/${id}/evaluate`, data),
  myAttempts: () => api.get('/assessments/my-attempts'),
};

export const calibrationApi = {
  runCalibration: (params?: any) => api.post('/calibration/run', null, { params }),
  getEvaluation: () => api.get('/calibration/evaluation'),
  override: (questionId: number, data: any) => api.post(`/calibration/${questionId}/override`, data),
};

export const performanceApi = {
  getAnalytics: (subjectId?: number) => api.get('/performance/analytics', { params: { subject_id: subjectId } }),
  getQuestionAnalytics: (id: number) => api.get(`/performance/question/${id}`),
};

export const pdfApi = {
  downloadQuestionPaper: (examId: number) => api.get(`/export/pdf/question-paper/${examId}`, { responseType: 'blob' }),
  downloadAnswerKey: (examId: number) => api.get(`/export/pdf/answer-key/${examId}`, { responseType: 'blob' }),
  downloadAnalysisReport: (examId: number) => api.get(`/export/pdf/analysis-report/${examId}`, { responseType: 'blob' }),
};

export const dashboardApi = {
  getStats: () => api.get('/dashboard/stats'),
};

export const settingsApi = {
  get: () => api.get('/settings'),
  update: (data: any) => api.put('/settings', data),
  testAi: (data: any) => api.post('/settings/test-ai', data),
};

export default api;
