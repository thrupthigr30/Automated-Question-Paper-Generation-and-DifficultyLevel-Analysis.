import React, { useState } from 'react';
import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import {
  LayoutDashboard,
  BookOpen,
  FileText,
  Database,
  Sparkles,
  History,
  FolderGit2,
  GraduationCap,
  ClipboardCheck,
  Scale,
  LineChart,
  FileDown,
  Settings as SettingsIcon,
  LogOut,
  ChevronLeft,
  ChevronRight,
  User,
  GraduationCap as LogoIcon
} from 'lucide-react';

export const AppLayout: React.FC = () => {
  const [collapsed, setCollapsed] = useState(false);
  const navigate = useNavigate();

  const userJson = localStorage.getItem('hacverse_user');
  const currentUser = userJson ? JSON.parse(userJson) : { full_name: 'Faculty User', role: 'teacher' };

  const handleLogout = () => {
    localStorage.removeItem('hacverse_token');
    localStorage.removeItem('hacverse_user');
    navigate('/login');
  };

  const navItems = [
    { label: 'Dashboard', path: '/dashboard', icon: LayoutDashboard },
    { label: 'Subjects & Syllabus', path: '/subjects', icon: BookOpen },
    { label: 'Academic Resources', path: '/documents', icon: FileText },
    { label: 'Question Bank', path: '/questions', icon: Database },
    { label: 'Generate Questions', path: '/generate', icon: Sparkles },
    { label: 'PYQ Analysis', path: '/pyq', icon: History },
    { label: 'Datasets', path: '/datasets', icon: FolderGit2 },
    { label: 'Examinations', path: '/examinations', icon: GraduationCap },
    { label: 'Student Assessments', path: '/assessments', icon: ClipboardCheck },
    { label: 'Difficulty Calibration', path: '/calibration', icon: Scale },
    { label: 'Performance Analytics', path: '/performance', icon: LineChart },
    { label: 'Reports', path: '/reports', icon: FileDown },
    { label: 'Settings', path: '/settings', icon: SettingsIcon },
  ];

  return (
    <div className="flex h-screen bg-[#F8FAFC] overflow-hidden">
      {/* Sidebar */}
      <aside
        className={`bg-white border-r border-slate-200/80 flex flex-col justify-between transition-all duration-200 z-30 ${
          collapsed ? 'w-16' : 'w-64'
        }`}
      >
        <div className="flex flex-col h-full overflow-hidden">
          {/* Logo / Header */}
          <div className="h-16 flex items-center px-4 border-b border-slate-100 justify-between">
            <div className="flex items-center gap-3 overflow-hidden">
              <div className="h-9 w-9 rounded-lg bg-blue-600 flex items-center justify-center text-white font-bold flex-shrink-0 shadow-sm shadow-blue-500/20">
                <LogoIcon className="h-5 w-5" />
              </div>
              {!collapsed && (
                <div className="flex flex-col">
                  <span className="font-bold text-slate-900 tracking-tight text-sm">HACVERSE</span>
                  <span className="text-[10px] text-slate-400 font-medium tracking-wider uppercase">Assessment Platform</span>
                </div>
              )}
            </div>
            <button
              onClick={() => setCollapsed(!collapsed)}
              className="p-1 rounded-md text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors"
              title={collapsed ? "Expand sidebar" : "Collapse sidebar"}
            >
              {collapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
            </button>
          </div>

          {/* Navigation Links */}
          <nav className="flex-1 overflow-y-auto p-3 space-y-1">
            {navItems.map((item) => (
              <NavLink
                key={item.path}
                to={item.path}
                className={({ isActive }) =>
                  `flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                    isActive
                      ? 'bg-blue-50 text-blue-700 font-semibold shadow-xs'
                      : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                  }`
                }
                title={collapsed ? item.label : undefined}
              >
                <item.icon className="h-4 w-4 flex-shrink-0" />
                {!collapsed && <span className="truncate">{item.label}</span>}
              </NavLink>
            ))}
          </nav>

          {/* Footer User Info */}
          <div className="p-3 border-t border-slate-100">
            <div className={`flex items-center gap-3 p-2 rounded-lg bg-slate-50 ${collapsed ? 'justify-center' : 'justify-between'}`}>
              <div className="flex items-center gap-2.5 overflow-hidden">
                <div className="h-8 w-8 rounded-full bg-slate-200 flex items-center justify-center text-slate-700 font-semibold text-xs flex-shrink-0">
                  <User className="h-4 w-4 text-slate-600" />
                </div>
                {!collapsed && (
                  <div className="flex flex-col truncate">
                    <span className="text-xs font-semibold text-slate-900 truncate">{currentUser.full_name || currentUser.username}</span>
                    <span className="text-[10px] text-slate-500 capitalize">{currentUser.role || 'Faculty'}</span>
                  </div>
                )}
              </div>
              {!collapsed && (
                <button
                  onClick={handleLogout}
                  className="p-1.5 text-slate-400 hover:text-rose-600 rounded-md hover:bg-white transition-colors"
                  title="Logout"
                >
                  <LogOut className="h-4 w-4" />
                </button>
              )}
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col h-screen overflow-hidden">
        {/* Top Header */}
        <header className="h-16 bg-white border-b border-slate-200/80 px-8 flex items-center justify-between z-20">
          <div className="flex items-center gap-4">
            <h1 className="text-sm font-semibold text-slate-800">
              Evidence-Aware Assessment & Calibration System
            </h1>
          </div>
          <div className="flex items-center gap-3">
            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-emerald-50 text-emerald-700 border border-emerald-200/60">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
              Live Backend
            </span>
          </div>
        </header>

        {/* Viewport Content */}
        <main className="flex-1 overflow-y-auto p-8">
          <div className="max-w-7xl mx-auto">
            <Outlet />
          </div>
        </main>
      </div>
    </div>
  );
};
