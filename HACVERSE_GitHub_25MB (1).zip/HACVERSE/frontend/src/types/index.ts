export interface User {
  id: number;
  username: string;
  email: string;
  full_name?: string;
  role: 'admin' | 'teacher' | 'student';
  is_active: boolean;
  created_at: string;
}

export interface Subject {
  id: number;
  name: string;
  code: string;
  description?: string;
  units?: Unit[];
  unit_count?: number;
  topic_count?: number;
  question_count?: number;
  document_count?: number;
  created_at?: string;
}

export interface Unit {
  id: number;
  subject_id: number;
  unit_number: number;
  title: string;
  name?: string;
  description?: string;
  topics?: Topic[];
}

export interface Topic {
  id: number;
  unit_id: number;
  name: string;
  description?: string;
}

export interface Document {
  id: number;
  title: string;
  filename: string;
  file_type: string;
  file_size: number;
  processing_status: 'PENDING' | 'PROCESSED' | 'FAILED' | 'pending' | 'processing' | 'completed' | 'failed';
  chunk_count: number;
  subject_id: number;
  unit_id?: number;
  subject?: Subject;
  unit?: Unit;
  created_at: string;
}

export interface Chunk {
  id: number;
  document_id: number;
  chunk_index: number;
  content: string;
  page_number?: number;
  token_count?: number;
  created_at?: string;
}

export type DocumentChunk = Chunk;

export interface Question {
  id: number;
  question_text: string;
  question_type: string;
  subject_id: number;
  unit_id?: number;
  topic_id?: number;
  subject?: Subject;
  unit?: Unit;
  topic?: Topic;
  marks: number;
  options?: any;
  correct_answer?: string;
  explanation?: string;
  blooms_level?: string;
  bloom_level?: string;

  // Cold-Start & Cognitive Dimensions
  initial_difficulty?: string;
  difficulty_score?: number;
  ai_difficulty_score?: number;
  conceptual_complexity?: number;
  computational_steps?: number;
  analytical_depth?: number;
  retrieval_dependency?: number;
  linguistic_complexity?: number;
  novelty_ratio?: number;

  // Real Student Evidence & Calibration
  calibrated_difficulty?: string;
  calibration_status?: string;
  total_attempts?: number;
  success_rate?: number;
  wilson_ci_lower?: number;
  wilson_ci_upper?: number;

  approval_status: string;
  created_at?: string;
}

export interface Examination {
  id: number;
  title?: string;
  name?: string;
  subject_id: number;
  subject?: Subject;
  duration_minutes: number;
  total_marks: number;
  easy_percentage: number;
  medium_percentage: number;
  hard_percentage: number;
  status: string;
  questions?: any[];
  created_at?: string;
}

export interface PYQPaper {
  id: number;
  title: string;
  filename: string;
  subject_id: number;
  subject?: Subject;
  year: number;
  semester?: string;
  question_count?: number;
  created_at?: string;
}

export interface PYQQuestion {
  id: number;
  paper_id: number;
  question_text: string;
  marks?: number;
  topic_id?: number;
  year?: number;
}

export interface Assessment {
  id: number;
  examination_id: number;
  student_id: number;
  status: string;
  total_marks?: number;
  score_awarded?: number;
  started_at?: string;
  completed_at?: string;
  responses?: StudentResponse[];
}

export interface StudentResponse {
  id?: number;
  assessment_id?: number;
  question_id: number;
  response_text: string;
  score_awarded?: number;
  is_correct?: boolean;
  time_spent_seconds?: number;
}

export interface DashboardStats {
  total_subjects: number;
  total_documents: number;
  total_questions: number;
  approved_questions: number;
  pending_questions?: number;
  total_examinations: number;
  total_responses: number;
  calibrated_questions: number;
  questions_with_evidence?: number;
  questions_awaiting_review?: number;
  recent_activity?: any[];
  difficulty_distribution?: any[];
}
