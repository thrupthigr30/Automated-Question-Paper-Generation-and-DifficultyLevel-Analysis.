# Starts HACVERSE Frontend (Vite Dev Server)
Write-Host "Starting HACVERSE Frontend on http://localhost:5173..." -ForegroundColor Cyan
$nodeDir = "$PSScriptRoot\tools\node-v20.18.1-win-x64"
$env:Path = "$nodeDir;$env:Path"
Set-Location "$PSScriptRoot\frontend"
npm run dev
