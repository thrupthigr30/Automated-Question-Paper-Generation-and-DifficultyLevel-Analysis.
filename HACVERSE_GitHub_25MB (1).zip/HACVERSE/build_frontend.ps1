$nodeDir = "D:\@\CEC\PROJECTS\HACVERSE\tools\node-v20.18.1-win-x64"
$env:Path = "$nodeDir;$env:Path"
Set-Location "D:\@\CEC\PROJECTS\HACVERSE\frontend"
npm run build
