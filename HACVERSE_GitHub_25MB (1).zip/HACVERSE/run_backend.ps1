# Starts HACVERSE FastAPI Backend
Write-Host "Starting HACVERSE Backend on http://127.0.0.1:8000..." -ForegroundColor Cyan
Set-Location "$PSScriptRoot\backend"
& "D:\Anaconda\python.exe" -m uvicorn app.main:app --host 127.0.0.1 --port 8000 --reload
