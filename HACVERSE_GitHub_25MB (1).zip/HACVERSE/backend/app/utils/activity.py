"""Audit and Activity logging helper."""
from typing import Optional, Dict, Any
from sqlalchemy.orm import Session
from app.models import ActivityLog


def log_activity(
    db: Session,
    user_id: Optional[int],
    action: str,
    entity_type: Optional[str] = None,
    entity_id: Optional[int] = None,
    details: Optional[Dict[str, Any]] = None,
    ip_address: Optional[str] = None
) -> ActivityLog:
    """Record an audit trail activity record."""
    log = ActivityLog(
        user_id=user_id,
        action=action,
        entity_type=entity_type,
        entity_id=entity_id,
        details=details,
        ip_address=ip_address
    )
    db.add(log)
    try:
        db.commit()
    except Exception:
        db.rollback()
    return log
