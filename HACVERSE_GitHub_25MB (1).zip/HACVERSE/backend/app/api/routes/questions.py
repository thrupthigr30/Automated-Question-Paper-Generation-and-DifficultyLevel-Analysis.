"""Question Bank and AI Question Generation API endpoints."""
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session
from sqlalchemy import func

from app.database.session import get_db
from app.models import Question, QuestionVersion, QuestionGenerationRun, User
from app.schemas.base import (
    QuestionGenerateRequest, QuestionCreate, QuestionUpdate,
    QuestionResponse, QuestionListResponse, GenerationRunResponse
)
from app.core.security import get_current_user, require_role
from app.services.questions.generator import QuestionGenerator
from app.utils.activity import log_activity

router = APIRouter(prefix="/questions", tags=["Questions & Generation"])


@router.get("", response_model=QuestionListResponse)
def list_questions(
    subject_id: Optional[int] = None,
    topic_id: Optional[int] = None,
    question_type: Optional[str] = None,
    difficulty: Optional[str] = None,
    approval_status: Optional[str] = None,
    evidence_status: Optional[str] = None,
    search: Optional[str] = None,
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    q = db.query(Question)

    if subject_id:
        q = q.filter(Question.subject_id == subject_id)
    if topic_id:
        q = q.filter(Question.topic_id == topic_id)
    if question_type:
        q = q.filter(Question.question_type == question_type)
    if difficulty:
        q = q.filter((Question.current_difficulty == difficulty) | (Question.ai_difficulty_level == difficulty))
    if approval_status:
        q = q.filter(Question.approval_status == approval_status)
    if evidence_status:
        q = q.filter(Question.evidence_status == evidence_status)
    if search:
        q = q.filter(Question.question_text.ilike(f"%{search}%"))

    total = q.count()
    offset = (page - 1) * page_size
    items = q.order_by(Question.created_at.desc()).offset(offset).limit(page_size).all()

    return {
        "questions": items,
        "total": total,
        "page": page,
        "page_size": page_size
    }


@router.post("/generate", response_model=GenerationRunResponse)
async def generate_questions(
    req: QuestionGenerateRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role("teacher", "admin"))
):
    generator = QuestionGenerator(db)
    try:
        run = await generator.generate_and_save(
            subject_id=req.subject_id,
            unit_id=req.unit_id,
            topic_id=req.topic_id,
            subtopic_id=req.subtopic_id,
            document_ids=req.document_ids,
            count=req.count,
            question_types=req.question_types,
            marks=req.marks,
            target_difficulty=req.difficulty,
            bloom_level=req.bloom_level,
            generation_mode=req.generation_mode,
            additional_instructions=req.additional_instructions,
            user_id=current_user.id
        )
        log_activity(db, current_user.id, "generate_questions", "generation_run", run.id, {"count": run.accepted_count})
        return run
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Generation failed: {str(e)}")


@router.post("/create", response_model=QuestionResponse, status_code=status.HTTP_201_CREATED)
def manual_create_question(
    q_in: QuestionCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role("teacher", "admin"))
):
    q = Question(
        question_text=q_in.question_text,
        subject_id=q_in.subject_id,
        unit_id=q_in.unit_id,
        topic_id=q_in.topic_id,
        subtopic_id=q_in.subtopic_id,
        question_type=q_in.question_type,
        marks=q_in.marks,
        options=q_in.options,
        correct_answer=q_in.correct_answer,
        explanation=q_in.explanation,
        answer_rubric=q_in.answer_rubric,
        answer_status="teacher_verified",
        approval_status="approved",
        data_origin="manually_created",
        ai_difficulty_level="medium",
        ai_difficulty_score=50.0,
        current_difficulty="medium",
        evidence_status="ai_estimated",
        valid_attempt_count=0,
        created_by=current_user.id
    )
    db.add(q)
    db.commit()
    db.refresh(q)
    log_activity(db, current_user.id, "manual_create_question", "question", q.id)
    return q


@router.get("/{id}", response_model=QuestionResponse)
def get_question(id: int, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    q = db.query(Question).filter(Question.id == id).first()
    if not q:
        raise HTTPException(status_code=404, detail="Question not found")
    return q


@router.put("/{id}", response_model=QuestionResponse)
def update_question(
    id: int,
    q_in: QuestionUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role("teacher", "admin"))
):
    q = db.query(Question).filter(Question.id == id).first()
    if not q:
        raise HTTPException(status_code=404, detail="Question not found")

    # Save version history before updating
    current_version_count = db.query(func.count(QuestionVersion.id)).filter(QuestionVersion.question_id == q.id).scalar() or 0
    version = QuestionVersion(
        question_id=q.id,
        version_number=current_version_count + 1,
        question_text=q.question_text,
        options=q.options,
        correct_answer=q.correct_answer,
        explanation=q.explanation,
        marks=q.marks,
        change_reason=q_in.change_reason or "Teacher update",
        changed_by=current_user.id
    )
    db.add(version)

    # Apply updates
    if q_in.question_text is not None:
        q.question_text = q_in.question_text
    if q_in.unit_id is not None:
        q.unit_id = q_in.unit_id
    if q_in.topic_id is not None:
        q.topic_id = q_in.topic_id
    if q_in.subtopic_id is not None:
        q.subtopic_id = q_in.subtopic_id
    if q_in.question_type is not None:
        q.question_type = q_in.question_type
    if q_in.marks is not None:
        q.marks = q_in.marks
    if q_in.options is not None:
        q.options = q_in.options
    if q_in.correct_answer is not None:
        q.correct_answer = q_in.correct_answer
    if q_in.explanation is not None:
        q.explanation = q_in.explanation
    if q_in.answer_rubric is not None:
        q.answer_rubric = q_in.answer_rubric
    if q_in.ai_difficulty_level is not None:
        q.ai_difficulty_level = q_in.ai_difficulty_level
        q.current_difficulty = q_in.ai_difficulty_level
    if q_in.bloom_level is not None:
        q.bloom_level = q_in.bloom_level

    db.commit()
    db.refresh(q)
    log_activity(db, current_user.id, "update_question", "question", q.id)
    return q


@router.post("/{id}/approve", response_model=QuestionResponse)
def approve_question(
    id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role("teacher", "admin"))
):
    q = db.query(Question).filter(Question.id == id).first()
    if not q:
        raise HTTPException(status_code=404, detail="Question not found")
    q.approval_status = "approved"
    db.commit()
    db.refresh(q)
    log_activity(db, current_user.id, "approve_question", "question", q.id)
    return q


@router.post("/{id}/reject", response_model=QuestionResponse)
def reject_question(
    id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role("teacher", "admin"))
):
    q = db.query(Question).filter(Question.id == id).first()
    if not q:
        raise HTTPException(status_code=404, detail="Question not found")
    q.approval_status = "rejected"
    db.commit()
    db.refresh(q)
    log_activity(db, current_user.id, "reject_question", "question", q.id)
    return q


@router.delete("/{id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_question(
    id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role("teacher", "admin"))
):
    q = db.query(Question).filter(Question.id == id).first()
    if not q:
        raise HTTPException(status_code=404, detail="Question not found")
    db.delete(q)
    db.commit()
    log_activity(db, current_user.id, "delete_question", "question", id)
    return None
