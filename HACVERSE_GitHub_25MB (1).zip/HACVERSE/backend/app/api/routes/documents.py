"""Academic Document Management API endpoints."""
import os
import shutil
from typing import List, Optional
from pathlib import Path
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form, status
from sqlalchemy.orm import Session

from app.database.session import get_db
from app.models import Document, DocumentChunk, Subject, User
from app.schemas.base import DocumentResponse, DocumentChunkResponse
from app.core.security import get_current_user, require_role
from app.core.config import settings
from app.services.documents.processor import DocumentProcessor
from app.utils.activity import log_activity

router = APIRouter(prefix="/documents", tags=["Academic Documents"])


@router.get("", response_model=List[DocumentResponse])
def list_documents(
    subject_id: Optional[int] = None,
    category: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    q = db.query(Document)
    if subject_id:
        q = q.filter(Document.subject_id == subject_id)
    if category:
        q = q.filter(Document.category == category)
    return q.order_by(Document.created_at.desc()).all()


@router.post("/upload", response_model=DocumentResponse, status_code=status.HTTP_201_CREATED)
async def upload_document(
    subject_id: int = Form(...),
    category: str = Form("textbook"),
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role("teacher", "admin"))
):
    # Verify subject exists
    subject = db.query(Subject).filter(Subject.id == subject_id).first()
    if not subject:
        raise HTTPException(status_code=404, detail="Subject not found")

    # Validate file extension
    ext = Path(file.filename).suffix.lower()
    allowed_exts = [".pdf", ".docx", ".doc", ".txt", ".md"]
    if ext not in allowed_exts:
        raise HTTPException(
            status_code=400,
            detail=f"Unsupported file format '{ext}'. Allowed: {', '.join(allowed_exts)}"
        )

    # Save file to storage
    upload_dir = Path(settings.UPLOAD_DIRECTORY)
    upload_dir.mkdir(parents=True, exist_ok=True)

    safe_filename = f"{subject_id}_{file.filename}"
    target_path = upload_dir / safe_filename

    # Read and validate size
    content = await file.read()
    file_size = len(content)
    max_bytes = settings.MAX_UPLOAD_SIZE_MB * 1024 * 1024
    if file_size > max_bytes:
        raise HTTPException(
            status_code=400,
            detail=f"File exceeds maximum allowed size of {settings.MAX_UPLOAD_SIZE_MB}MB."
        )

    with open(target_path, "wb") as f:
        f.write(content)

    doc = Document(
        filename=safe_filename,
        original_filename=file.filename,
        file_path=str(target_path),
        file_size=file_size,
        file_extension=ext.lstrip("."),
        category=category,
        subject_id=subject_id,
        uploaded_by=current_user.id,
        processing_status="pending"
    )
    db.add(doc)
    db.commit()
    db.refresh(doc)

    # Automatically process extraction and chunking
    processor = DocumentProcessor()
    extract_res = processor.process_file(str(target_path), doc.file_extension)

    doc.page_count = extract_res.get("page_count", 1)
    doc.is_scanned = extract_res.get("is_scanned", False)
    doc.extraction_status = extract_res.get("extraction_status", "success")
    doc.processing_error = extract_res.get("error_message")

    if doc.extraction_status in ["success", "scanned_needs_ocr"]:
        chunks = processor.create_chunks(extract_res.get("pages", []))
        for c in chunks:
            chunk = DocumentChunk(
                document_id=doc.id,
                chunk_index=c["chunk_index"],
                content=c["content"],
                page_number=c.get("page_number"),
                heading=c.get("heading"),
                char_count=c.get("char_count"),
                extraction_method=c.get("extraction_method", "text_extracted")
            )
            db.add(chunk)
        doc.processing_status = "completed"
    else:
        doc.processing_status = "failed"

    db.commit()
    db.refresh(doc)

    log_activity(db, current_user.id, "upload_document", "document", doc.id, {"filename": file.filename})
    return doc


@router.post("/upload-batch", response_model=List[DocumentResponse], status_code=status.HTTP_201_CREATED)
async def upload_multiple_documents(
    subject_id: int = Form(...),
    category: str = Form("textbook"),
    files: List[UploadFile] = File(...),
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role("teacher", "admin"))
):
    """Upload and process multiple academic documents simultaneously."""
    subject = db.query(Subject).filter(Subject.id == subject_id).first()
    if not subject:
        raise HTTPException(status_code=404, detail="Subject not found")

    upload_dir = Path(settings.UPLOAD_DIRECTORY)
    upload_dir.mkdir(parents=True, exist_ok=True)
    allowed_exts = [".pdf", ".docx", ".doc", ".txt", ".md"]
    max_bytes = settings.MAX_UPLOAD_SIZE_MB * 1024 * 1024
    processor = DocumentProcessor()
    created_docs = []

    for file in files:
        ext = Path(file.filename).suffix.lower()
        if ext not in allowed_exts:
            continue

        content = await file.read()
        file_size = len(content)
        if file_size > max_bytes:
            continue

        safe_filename = f"{subject_id}_{file.filename}"
        target_path = upload_dir / safe_filename
        with open(target_path, "wb") as f:
            f.write(content)

        doc = Document(
            filename=safe_filename,
            original_filename=file.filename,
            file_path=str(target_path),
            file_size=file_size,
            file_extension=ext.lstrip("."),
            category=category,
            subject_id=subject_id,
            uploaded_by=current_user.id,
            processing_status="pending"
        )
        db.add(doc)
        db.commit()
        db.refresh(doc)

        extract_res = processor.process_file(str(target_path), doc.file_extension)
        doc.page_count = extract_res.get("page_count", 1)
        doc.is_scanned = extract_res.get("is_scanned", False)
        doc.extraction_status = extract_res.get("extraction_status", "success")
        doc.processing_error = extract_res.get("error_message")

        if doc.extraction_status in ["success", "scanned_needs_ocr"]:
            chunks = processor.create_chunks(extract_res.get("pages", []))
            for c in chunks:
                chunk = DocumentChunk(
                    document_id=doc.id,
                    chunk_index=c["chunk_index"],
                    content=c["content"],
                    page_number=c.get("page_number"),
                    heading=c.get("heading"),
                    char_count=c.get("char_count"),
                    extraction_method=c.get("extraction_method", "text_extracted")
                )
                db.add(chunk)
            doc.processing_status = "completed"
        else:
            doc.processing_status = "failed"

        db.commit()
        db.refresh(doc)
        log_activity(db, current_user.id, "upload_document", "document", doc.id, {"filename": file.filename})
        created_docs.append(doc)

    return created_docs


@router.get("/{id}", response_model=DocumentResponse)
def get_document(id: int, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    doc = db.query(Document).filter(Document.id == id).first()
    if not doc:
        raise HTTPException(status_code=404, detail="Document not found")
    return doc


@router.get("/{id}/content", response_model=List[DocumentChunkResponse])
def get_document_chunks(id: int, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    doc = db.query(Document).filter(Document.id == id).first()
    if not doc:
        raise HTTPException(status_code=404, detail="Document not found")
    return doc.chunks


@router.post("/{id}/process", response_model=DocumentResponse)
def reprocess_document(
    id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role("teacher", "admin"))
):
    doc = db.query(Document).filter(Document.id == id).first()
    if not doc:
        raise HTTPException(status_code=404, detail="Document not found")

    # Clear old chunks
    db.query(DocumentChunk).filter(DocumentChunk.document_id == doc.id).delete()

    processor = DocumentProcessor()
    extract_res = processor.process_file(doc.file_path, doc.file_extension)

    doc.page_count = extract_res.get("page_count", 1)
    doc.is_scanned = extract_res.get("is_scanned", False)
    doc.extraction_status = extract_res.get("extraction_status", "success")
    doc.processing_error = extract_res.get("error_message")

    if doc.extraction_status in ["success", "scanned_needs_ocr"]:
        chunks = processor.create_chunks(extract_res.get("pages", []))
        for c in chunks:
            chunk = DocumentChunk(
                document_id=doc.id,
                chunk_index=c["chunk_index"],
                content=c["content"],
                page_number=c.get("page_number"),
                heading=c.get("heading"),
                char_count=c.get("char_count"),
                extraction_method=c.get("extraction_method", "text_extracted")
            )
            db.add(chunk)
        doc.processing_status = "completed"
    else:
        doc.processing_status = "failed"

    db.commit()
    db.refresh(doc)
    log_activity(db, current_user.id, "reprocess_document", "document", doc.id)
    return doc


@router.delete("/{id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_document(
    id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role("teacher", "admin"))
):
    doc = db.query(Document).filter(Document.id == id).first()
    if not doc:
        raise HTTPException(status_code=404, detail="Document not found")

    # Delete physical file safely
    try:
        if os.path.exists(doc.file_path):
            os.remove(doc.file_path)
    except Exception as e:
        logger.warning(f"Could not remove physical file {doc.file_path}: {e}")

    db.delete(doc)
    db.commit()
    log_activity(db, current_user.id, "delete_document", "document", id)
    return None
