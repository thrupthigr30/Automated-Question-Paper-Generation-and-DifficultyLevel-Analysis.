"""Performance Analytics API endpoints."""
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database.session import get_db
from app.models import User
from app.schemas.base import PerformanceSummary
from app.core.security import get_current_user
from app.services.performance.calculator import PerformanceCalculator
from app.services.calibration.engine import CalibrationEngine

router = APIRouter(prefix="/performance", tags=["Performance Analytics"])


@router.get("/summary", response_model=PerformanceSummary)
def get_performance_summary(
    subject_id: Optional[int] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    calc = PerformanceCalculator(db)
    return calc.get_overall_summary(subject_id=subject_id)


@router.get("/questions/{id}")
def get_question_performance(
    id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    engine = CalibrationEngine(db)
    return engine.calculate_question_performance(id)
