"""Previous-Year Question (PYQ) API endpoints."""
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session

from app.database.session import get_db
from app.models import PYQPaper, PYQQuestion, User
from app.schemas.base import PYQPaperResponse, PYQQuestionResponse, PYQSummary, TopicFrequencyResponse
from app.core.security import get_current_user, require_role
from app.services.pyq.analyzer import PYQAnalyzer
from app.utils.activity import log_activity

router = APIRouter(prefix="/pyq", tags=["Previous-Year Questions"])


@router.post("/analyse", response_model=PYQPaperResponse, status_code=status.HTTP_201_CREATED)
def analyse_pyq_document(
    document_id: int,
    subject_id: int,
    exam_year: Optional[int] = None,
    exam_name: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role("teacher", "admin"))
):
    analyzer = PYQAnalyzer(db)
    try:
        paper = analyzer.extract_and_analyze_paper(
            document_id=document_id,
            subject_id=subject_id,
            exam_year=exam_year,
            exam_name=exam_name
        )
        log_activity(db, current_user.id, "analyse_pyq", "pyq_paper", paper.id)
        return paper
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"PYQ analysis failed: {str(e)}")


@router.get("/papers", response_model=List[PYQPaperResponse])
def list_pyq_papers(
    subject_id: Optional[int] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    q = db.query(PYQPaper)
    if subject_id:
        q = q.filter(PYQPaper.subject_id == subject_id)
    return q.order_by(PYQPaper.created_at.desc()).all()


@router.get("/summary")
def get_pyq_summary(
    subject_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    analyzer = PYQAnalyzer(db)
    return analyzer.get_subject_pyq_summary(subject_id)


@router.get("/repeated-questions", response_model=List[PYQQuestionResponse])
def get_repeated_questions(
    subject_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    papers = db.query(PYQPaper.id).filter(PYQPaper.subject_id == subject_id).all()
    paper_ids = [p[0] for p in papers]
    if not paper_ids:
        return []

    return (
        db.query(PYQQuestion)
        .filter(PYQQuestion.paper_id.in_(paper_ids))
        .filter(PYQQuestion.exact_repeat_count > 0)
        .all()
    )


@router.get("/topic-frequency")
def get_topic_frequency(
    subject_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    analyzer = PYQAnalyzer(db)
    summary = analyzer.get_subject_pyq_summary(subject_id)
    return summary.get("topic_frequencies", [])
