"""Dashboard statistics and real activity stream API endpoints."""
from typing import List, Optional
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from sqlalchemy import func

from app.database.session import get_db
from app.models import Subject, Document, Question, Examination, StudentResponse, ActivityLog, User
from app.schemas.base import DashboardStats, ActivityLogResponse
from app.core.security import get_current_user

router = APIRouter(prefix="/dashboard", tags=["Dashboard"])


@router.get("/stats", response_model=DashboardStats)
def get_dashboard_stats(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    """Aggregate actual database counts for the system dashboard."""
    subjects_count = db.query(func.count(Subject.id)).scalar() or 0
    docs_count = db.query(func.count(Document.id)).scalar() or 0
    total_q = db.query(func.count(Question.id)).scalar() or 0
    approved_q = db.query(func.count(Question.id)).filter(Question.approval_status == "approved").scalar() or 0
    pending_q = db.query(func.count(Question.id)).filter(Question.approval_status == "pending").scalar() or 0
    exams_count = db.query(func.count(Examination.id)).scalar() or 0
    responses_count = db.query(func.count(StudentResponse.id)).scalar() or 0

    with_evidence = (
        db.query(func.count(Question.id))
        .filter(Question.evidence_status.in_(["performance_calibrated", "low_confidence"]))
        .scalar() or 0
    )

    awaiting_review = (
        db.query(func.count(Question.id))
        .filter(Question.approval_status.in_(["pending", "needs_revision"]))
        .scalar() or 0
    )

    return {
        "total_subjects": subjects_count,
        "total_documents": docs_count,
        "total_questions": total_q,
        "approved_questions": approved_q,
        "pending_questions": pending_q,
        "total_examinations": exams_count,
        "total_responses": responses_count,
        "questions_with_evidence": with_evidence,
        "questions_awaiting_review": awaiting_review
    }


@router.get("/question-distribution")
def get_question_distribution(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    """Visually separate AI-estimated difficulty vs Performance-observed difficulty distributions."""
    # AI predicted distribution
    ai_easy = db.query(func.count(Question.id)).filter(Question.ai_difficulty_level == "easy").scalar() or 0
    ai_med = db.query(func.count(Question.id)).filter(Question.ai_difficulty_level == "medium").scalar() or 0
    ai_hard = db.query(func.count(Question.id)).filter(Question.ai_difficulty_level == "hard").scalar() or 0

    # Performance observed distribution
    obs_easy = db.query(func.count(Question.id)).filter(Question.observed_difficulty_level == "easy").scalar() or 0
    obs_med = db.query(func.count(Question.id)).filter(Question.observed_difficulty_level == "medium").scalar() or 0
    obs_hard = db.query(func.count(Question.id)).filter(Question.observed_difficulty_level == "hard").scalar() or 0

    unattempted = db.query(func.count(Question.id)).filter(Question.valid_attempt_count == 0).scalar() or 0

    return {
        "ai_predicted": {
            "easy": ai_easy,
            "medium": ai_med,
            "hard": ai_hard
        },
        "performance_observed": {
            "easy": obs_easy,
            "medium": obs_med,
            "hard": obs_hard
        },
        "unattempted_cold_start": unattempted
    }


@router.get("/activity", response_model=List[ActivityLogResponse])
def get_recent_activity(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    """Return real audit events from database activity log."""
    return db.query(ActivityLog).order_by(ActivityLog.created_at.desc()).limit(15).all()
