"""Student Assessment and Examination Taking API endpoints."""
from typing import List, Optional
from datetime import datetime, timezone
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session

from app.database.session import get_db
from app.models import (
    Examination, ExaminationAssignment, ExaminationAttempt, StudentResponse,
    ExaminationQuestion, Question, User
)
from app.schemas.base import (
    AssignmentResponse, SubmitExamRequest, SubmitAnswerRequest, AttemptResultResponse
)
from app.core.security import get_current_user, require_role
from app.services.assessments.evaluator import AssessmentEvaluator
from app.services.calibration.engine import CalibrationEngine
from app.utils.activity import log_activity

router = APIRouter(prefix="/student", tags=["Student Assessments"])


@router.get("/examinations")
def get_available_examinations(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """List published examinations accessible to the current student."""
    exams = (
        db.query(Examination)
        .filter(Examination.status == "published")
        .order_by(Examination.created_at.desc())
        .all()
    )

    results = []
    for ex in exams:
        # Check if student already attempted
        attempt = (
            db.query(ExaminationAttempt)
            .join(ExaminationAssignment, ExaminationAttempt.assignment_id == ExaminationAssignment.id)
            .filter(ExaminationAssignment.examination_id == ex.id, ExaminationAttempt.student_id == current_user.id)
            .first()
        )
        results.append({
            "id": ex.id,
            "name": ex.name,
            "subject_name": ex.subject.name if ex.subject else "",
            "exam_type": ex.exam_type,
            "total_marks": ex.total_marks,
            "duration_minutes": ex.duration_minutes,
            "instructions": ex.instructions,
            "has_attempted": attempt is not None,
            "attempt_status": attempt.status if attempt else None,
            "attempt_id": attempt.id if attempt else None
        })
    return results


@router.post("/examinations/{id}/start")
def start_examination(
    id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Start an exam session. Returns questions (WITHOUT correct answers/explanations)."""
    exam = db.query(Examination).filter(Examination.id == id, Examination.status == "published").first()
    if not exam:
        raise HTTPException(status_code=404, detail="Published examination not found")

    # Find or create assignment
    assignment = (
        db.query(ExaminationAssignment)
        .filter(ExaminationAssignment.examination_id == exam.id, ExaminationAssignment.student_id == current_user.id)
        .first()
    )
    if not assignment:
        assignment = ExaminationAssignment(
            examination_id=exam.id,
            student_id=current_user.id,
            status="published"
        )
        db.add(assignment)
        db.flush()

    # Create new attempt
    attempt = ExaminationAttempt(
        assignment_id=assignment.id,
        student_id=current_user.id,
        status="in_progress",
        started_at=datetime.now(timezone.utc),
        total_marks_possible=exam.total_marks
    )
    db.add(attempt)
    db.commit()
    db.refresh(attempt)

    # Fetch examination questions stripped of correct answers
    eqs = (
        db.query(ExaminationQuestion)
        .filter(ExaminationQuestion.examination_id == exam.id)
        .order_by(ExaminationQuestion.question_order.asc())
        .all()
    )

    questions_payload = []
    for eq in eqs:
        q = eq.question
        if q:
            questions_payload.append({
                "question_id": q.id,
                "order": eq.question_order,
                "section": eq.section_name,
                "question_text": q.question_text,
                "question_type": q.question_type,
                "marks": eq.marks_override or q.marks,
                "options": q.options  # options for MCQ
                # SECURITY: Do NOT include correct_answer or explanation here!
            })

    log_activity(db, current_user.id, "start_examination", "attempt", attempt.id)
    return {
        "attempt_id": attempt.id,
        "examination_id": exam.id,
        "examination_name": exam.name,
        "duration_minutes": exam.duration_minutes,
        "total_marks": exam.total_marks,
        "instructions": exam.instructions,
        "questions": questions_payload
    }


@router.post("/examinations/{id}/submit")
def submit_examination(
    id: int,
    submission: SubmitExamRequest,
    attempt_id: int = Query(...),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Submit all responses for an exam attempt, evaluate objective questions, and record scores."""
    attempt = db.query(ExaminationAttempt).filter(ExaminationAttempt.id == attempt_id, ExaminationAttempt.student_id == current_user.id).first()
    if not attempt:
        raise HTTPException(status_code=404, detail="Active attempt not found")

    exam = db.query(Examination).filter(Examination.id == id).first()
    if not exam:
        raise HTTPException(status_code=404, detail="Examination not found")

    total_marks_earned = 0.0
    responses_to_calibrate = []

    for item in submission.responses:
        q = db.query(Question).filter(Question.id == item.question_id).first()
        if not q:
            continue

        eval_res = AssessmentEvaluator.evaluate_response(q, item.answer)

        resp = StudentResponse(
            attempt_id=attempt.id,
            question_id=q.id,
            student_id=current_user.id,
            examination_id=exam.id,
            submitted_answer=item.answer,
            is_correct=eval_res["is_correct"],
            marks_earned=eval_res["marks_earned"],
            max_marks=q.marks,
            time_taken_seconds=item.time_taken_seconds,
            attempt_number=attempt.attempt_number,
            evaluation_status=eval_res["evaluation_status"],
            evaluator_notes=eval_res["notes"],
            data_origin="student_submitted"
        )
        db.add(resp)
        if eval_res["marks_earned"] is not None:
            total_marks_earned += eval_res["marks_earned"]

        responses_to_calibrate.append(q)

    attempt.status = "submitted"
    attempt.submitted_at = datetime.now(timezone.utc)
    attempt.total_marks_earned = round(total_marks_earned, 2)
    db.commit()

    # Automatically trigger single-question calibration for attempted questions
    calibrator = CalibrationEngine(db)
    for q in responses_to_calibrate:
        try:
            calibrator.calibrate_question(q)
        except Exception:
            pass

    log_activity(db, current_user.id, "submit_examination", "attempt", attempt.id, {"marks": total_marks_earned})

    return {
        "status": "success",
        "attempt_id": attempt.id,
        "total_marks_earned": attempt.total_marks_earned,
        "total_marks_possible": attempt.total_marks_possible,
        "percentage": round((total_marks_earned / max(1, attempt.total_marks_possible)) * 100.0, 1)
    }


@router.get("/results")
def list_student_results(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Retrieve submitted examination attempts for the authenticated student."""
    attempts = (
        db.query(ExaminationAttempt)
        .filter(ExaminationAttempt.student_id == current_user.id, ExaminationAttempt.status == "submitted")
        .order_by(ExaminationAttempt.submitted_at.desc())
        .all()
    )

    results = []
    for att in attempts:
        exam = att.assignment.examination if att.assignment else None
        pct = (att.total_marks_earned / att.total_marks_possible * 100.0) if att.total_marks_possible else 0.0
        results.append({
            "attempt_id": att.id,
            "examination_id": exam.id if exam else None,
            "examination_name": exam.name if exam else "Unknown Exam",
            "subject_name": exam.subject.name if exam and exam.subject else "",
            "total_marks_earned": att.total_marks_earned,
            "total_marks_possible": att.total_marks_possible,
            "percentage": round(pct, 1),
            "submitted_at": att.submitted_at
        })
    return results
