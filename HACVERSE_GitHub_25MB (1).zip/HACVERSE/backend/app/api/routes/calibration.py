"""Calibration Evaluation and Research Analytics API endpoints."""
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session

from app.database.session import get_db
from app.models import CalibrationRun, CalibrationEvaluation, Question, User
from app.schemas.base import CalibrationRunResponse, CalibrationEvaluationResponse
from app.core.security import get_current_user, require_role
from app.services.calibration.engine import CalibrationEngine
from app.utils.activity import log_activity

router = APIRouter(prefix="/calibration", tags=["Difficulty Calibration"])


@router.post("/run", response_model=CalibrationRunResponse)
def trigger_calibration_run(
    subject_id: Optional[int] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role("teacher", "admin"))
):
    engine = CalibrationEngine(db)
    run = engine.run_full_calibration(subject_id=subject_id, user_id=current_user.id)
    log_activity(db, current_user.id, "run_calibration", "calibration_run", run.id)
    return run


@router.get("/summary")
def get_calibration_summary(
    subject_id: Optional[int] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Retrieve the latest calibration run results and research metrics."""
    q = db.query(CalibrationRun)
    if subject_id:
        q = q.filter(CalibrationRun.subject_id == subject_id)

    latest_run = q.order_by(CalibrationRun.created_at.desc()).first()
    if not latest_run:
        return {
            "has_data": False,
            "message": "No calibration runs executed yet. Student performance data required."
        }

    return {
        "has_data": True,
        "run_id": latest_run.id,
        "subject_id": latest_run.subject_id,
        "total_questions": latest_run.total_questions,
        "eligible_questions": latest_run.eligible_questions,
        "correct_predictions": latest_run.correct_predictions,
        "overestimated": latest_run.overestimated,
        "underestimated": latest_run.underestimated,
        "overall_agreement": latest_run.overall_agreement,
        "balanced_accuracy": latest_run.balanced_accuracy,
        "macro_f1": latest_run.macro_f1,
        "weighted_kappa": latest_run.weighted_kappa,
        "confusion_matrix": latest_run.confusion_matrix,
        "per_class_metrics": latest_run.per_class_metrics,
        "created_at": latest_run.created_at
    }


@router.get("/comparison")
def get_calibration_comparison_table(
    subject_id: Optional[int] = None,
    agreement: Optional[str] = None,
    page: int = Query(1, ge=1),
    page_size: int = Query(25, ge=1, le=100),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Question-level prediction vs observed difficulty comparison rows."""
    q = db.query(CalibrationEvaluation).join(Question, CalibrationEvaluation.question_id == Question.id)

    if subject_id:
        q = q.filter(Question.subject_id == subject_id)
    if agreement:
        q = q.filter(CalibrationEvaluation.agreement == agreement)

    total = q.count()
    offset = (page - 1) * page_size
    evals = q.order_by(CalibrationEvaluation.created_at.desc()).offset(offset).limit(page_size).all()

    items = []
    for ev in evals:
        question = ev.question
        items.append({
            "evaluation_id": ev.id,
            "question_id": ev.question_id,
            "question_text": question.question_text if question else "",
            "ai_predicted_level": ev.ai_predicted_level,
            "observed_level": ev.observed_level,
            "attempt_count": ev.attempt_count,
            "performance_rate": ev.performance_rate,
            "agreement": ev.agreement,
            "confidence_info": ev.confidence_info,
            "created_at": ev.created_at
        })

    return {
        "items": items,
        "total": total,
        "page": page,
        "page_size": page_size
    }


@router.get("/evaluations", response_model=List[CalibrationEvaluationResponse])
def list_evaluations(
    run_id: Optional[int] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    q = db.query(CalibrationEvaluation)
    if run_id:
        q = q.filter(CalibrationEvaluation.run_id == run_id)
    return q.order_by(CalibrationEvaluation.created_at.desc()).limit(100).all()


@router.get("/questions/{id}")
def get_single_question_calibration(
    id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    q = db.query(Question).filter(Question.id == id).first()
    if not q:
        raise HTTPException(status_code=404, detail="Question not found")

    eval_record = (
        db.query(CalibrationEvaluation)
        .filter(CalibrationEvaluation.question_id == id)
        .order_by(CalibrationEvaluation.created_at.desc())
        .first()
    )

    return {
        "question_id": q.id,
        "question_text": q.question_text,
        "ai_predicted_level": q.ai_difficulty_level,
        "ai_difficulty_score": q.ai_difficulty_score,
        "observed_level": q.observed_difficulty_level,
        "observed_score": q.observed_difficulty_score,
        "current_displayed": q.current_difficulty or q.ai_difficulty_level,
        "evidence_status": q.evidence_status,
        "valid_attempts": q.valid_attempt_count,
        "confidence_lower": q.confidence_lower,
        "confidence_upper": q.confidence_upper,
        "agreement": eval_record.agreement if eval_record else None
    }
