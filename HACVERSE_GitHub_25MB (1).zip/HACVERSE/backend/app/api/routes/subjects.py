"""Subject and Syllabus Management API endpoints."""
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from sqlalchemy import func

from app.database.session import get_db
from app.models import Subject, Unit, Topic, Subtopic, Question, Document, User
from app.schemas.base import (
    SubjectCreate, SubjectUpdate, SubjectResponse,
    UnitCreate, UnitUpdate, UnitResponse,
    TopicCreate, TopicUpdate, TopicResponse,
    SubtopicCreate, SubtopicResponse
)
from app.core.security import get_current_user, require_role
from app.utils.activity import log_activity

router = APIRouter(prefix="/subjects", tags=["Subjects & Syllabus"])


@router.get("", response_model=List[SubjectResponse])
def list_subjects(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    subjects = db.query(Subject).all()
    results = []
    for s in subjects:
        u_cnt = db.query(func.count(Unit.id)).filter(Unit.subject_id == s.id).scalar() or 0
        t_cnt = (
            db.query(func.count(Topic.id))
            .join(Unit, Topic.unit_id == Unit.id)
            .filter(Unit.subject_id == s.id)
            .scalar() or 0
        )
        q_cnt = db.query(func.count(Question.id)).filter(Question.subject_id == s.id).scalar() or 0
        d_cnt = db.query(func.count(Document.id)).filter(Document.subject_id == s.id).scalar() or 0

        res = SubjectResponse.model_validate(s)
        res.unit_count = u_cnt
        res.topic_count = t_cnt
        res.question_count = q_cnt
        res.document_count = d_cnt
        results.append(res)
    return results


@router.post("", response_model=SubjectResponse, status_code=status.HTTP_201_CREATED)
def create_subject(
    subj_in: SubjectCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role("teacher", "admin"))
):
    existing = db.query(Subject).filter(Subject.name == subj_in.name, Subject.owner_id == current_user.id).first()
    if existing:
        raise HTTPException(status_code=400, detail="You already have a subject with this name.")

    subject = Subject(
        name=subj_in.name,
        code=subj_in.code,
        description=subj_in.description,
        owner_id=current_user.id
    )
    db.add(subject)
    db.commit()
    db.refresh(subject)
    log_activity(db, current_user.id, "create_subject", "subject", subject.id)
    return SubjectResponse.model_validate(subject)


@router.get("/{id}", response_model=SubjectResponse)
def get_subject(id: int, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    s = db.query(Subject).filter(Subject.id == id).first()
    if not s:
        raise HTTPException(status_code=404, detail="Subject not found")
    
    res = SubjectResponse.model_validate(s)
    res.unit_count = db.query(func.count(Unit.id)).filter(Unit.subject_id == s.id).scalar() or 0
    res.topic_count = db.query(func.count(Topic.id)).join(Unit, Topic.unit_id == Unit.id).filter(Unit.subject_id == s.id).scalar() or 0
    res.question_count = db.query(func.count(Question.id)).filter(Question.subject_id == s.id).scalar() or 0
    res.document_count = db.query(func.count(Document.id)).filter(Document.subject_id == s.id).scalar() or 0
    return res


@router.put("/{id}", response_model=SubjectResponse)
def update_subject(
    id: int,
    subj_in: SubjectUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role("teacher", "admin"))
):
    s = db.query(Subject).filter(Subject.id == id).first()
    if not s:
        raise HTTPException(status_code=404, detail="Subject not found")

    if subj_in.name is not None:
        s.name = subj_in.name
    if subj_in.code is not None:
        s.code = subj_in.code
    if subj_in.description is not None:
        s.description = subj_in.description

    db.commit()
    db.refresh(s)
    log_activity(db, current_user.id, "update_subject", "subject", s.id)
    return SubjectResponse.model_validate(s)


@router.delete("/{id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_subject(
    id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role("teacher", "admin"))
):
    s = db.query(Subject).filter(Subject.id == id).first()
    if not s:
        raise HTTPException(status_code=404, detail="Subject not found")
    db.delete(s)
    db.commit()
    log_activity(db, current_user.id, "delete_subject", "subject", id)
    return None


@router.get("/{id}/syllabus")
def get_full_syllabus_tree(id: int, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    s = db.query(Subject).filter(Subject.id == id).first()
    if not s:
        raise HTTPException(status_code=404, detail="Subject not found")

    units = db.query(Unit).filter(Unit.subject_id == s.id).order_by(Unit.unit_number.asc()).all()
    tree = []
    for u in units:
        topics = db.query(Topic).filter(Topic.unit_id == u.id).all()
        topics_data = []
        for t in topics:
            subtopics = db.query(Subtopic).filter(Subtopic.topic_id == t.id).all()
            topics_data.append({
                "id": t.id,
                "name": t.name,
                "description": t.description,
                "subtopics": [{"id": st.id, "name": st.name, "description": st.description} for st in subtopics]
            })
        tree.append({
            "id": u.id,
            "unit_number": u.unit_number,
            "name": u.name,
            "description": u.description,
            "topics": topics_data
        })
    return {"subject_id": s.id, "subject_name": s.name, "units": tree}


# ── Units & Topics CRUD ─────────────────────────────────────────────────

@router.post("/units", response_model=UnitResponse, status_code=status.HTTP_201_CREATED)
def create_unit(
    unit_in: UnitCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role("teacher", "admin"))
):
    existing = db.query(Unit).filter(Unit.subject_id == unit_in.subject_id, Unit.unit_number == unit_in.unit_number).first()
    if existing:
        return UnitResponse.model_validate(existing)

    unit = Unit(
        name=unit_in.name,
        unit_number=unit_in.unit_number,
        description=unit_in.description,
        subject_id=unit_in.subject_id
    )
    db.add(unit)
    db.commit()
    db.refresh(unit)
    return UnitResponse.model_validate(unit)


@router.post("/topics", response_model=TopicResponse, status_code=status.HTTP_201_CREATED)
def create_topic(
    topic_in: TopicCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role("teacher", "admin"))
):
    existing = db.query(Topic).filter(Topic.unit_id == topic_in.unit_id, Topic.name == topic_in.name).first()
    if existing:
        return TopicResponse.model_validate(existing)

    topic = Topic(
        name=topic_in.name,
        description=topic_in.description,
        unit_id=topic_in.unit_id
    )
    db.add(topic)
    db.commit()
    db.refresh(topic)
    return TopicResponse.model_validate(topic)


@router.post("/subtopics", response_model=SubtopicResponse, status_code=status.HTTP_201_CREATED)
def create_subtopic(
    sub_in: SubtopicCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role("teacher", "admin"))
):
    subtopic = Subtopic(
        name=sub_in.name,
        description=sub_in.description,
        topic_id=sub_in.topic_id
    )
    db.add(subtopic)
    db.commit()
    db.refresh(subtopic)
    return SubtopicResponse.model_validate(subtopic)
