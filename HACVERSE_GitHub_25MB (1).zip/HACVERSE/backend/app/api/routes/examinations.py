"""Examination Paper Generator and Validation API endpoints."""
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from sqlalchemy import func

from app.database.session import get_db
from app.models import Examination, ExaminationQuestion, User
from app.schemas.base import ExaminationCreate, ExaminationUpdate, ExaminationResponse
from app.core.security import get_current_user, require_role
from app.services.examinations.builder import ExaminationBuilder
from app.utils.activity import log_activity

router = APIRouter(prefix="/examinations", tags=["Examinations"])


@router.get("", response_model=List[ExaminationResponse])
def list_examinations(
    subject_id: Optional[int] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    q = db.query(Examination)
    if subject_id:
        q = q.filter(Examination.subject_id == subject_id)

    exams = q.order_by(Examination.created_at.desc()).all()
    results = []
    for ex in exams:
        cnt = db.query(func.count(ExaminationQuestion.id)).filter(ExaminationQuestion.examination_id == ex.id).scalar() or 0
        eqs = db.query(ExaminationQuestion).filter(ExaminationQuestion.examination_id == ex.id).all()
        actual_m = sum(eq.marks_override or (eq.question.marks if eq.question else 0) for eq in eqs)

        res = ExaminationResponse.model_validate(ex)
        res.question_count = cnt
        res.actual_marks = actual_m
        results.append(res)
    return results


@router.post("", response_model=ExaminationResponse, status_code=status.HTTP_201_CREATED)
def create_examination(
    exam_in: ExaminationCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role("teacher", "admin"))
):
    exam = Examination(
        name=exam_in.name,
        subject_id=exam_in.subject_id,
        exam_type=exam_in.exam_type,
        total_marks=exam_in.total_marks,
        duration_minutes=exam_in.duration_minutes,
        instructions=exam_in.instructions,
        easy_percent=exam_in.easy_percent,
        medium_percent=exam_in.medium_percent,
        hard_percent=exam_in.hard_percent,
        created_by=current_user.id,
        status="draft"
    )
    db.add(exam)
    db.commit()
    db.refresh(exam)

    # Automatically trigger question selection algorithm
    builder = ExaminationBuilder(db)
    builder.generate_paper(
        examination_id=exam.id,
        topic_ids=exam_in.topic_ids,
        unit_ids=exam_in.unit_ids,
        question_types=exam_in.question_types
    )

    db.refresh(exam)
    log_activity(db, current_user.id, "create_examination", "examination", exam.id)
    return ExaminationResponse.model_validate(exam)


@router.get("/{id}")
def get_examination_details(
    id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    exam = db.query(Examination).filter(Examination.id == id).first()
    if not exam:
        raise HTTPException(status_code=404, detail="Examination not found")

    eqs = (
        db.query(ExaminationQuestion)
        .filter(ExaminationQuestion.examination_id == exam.id)
        .order_by(ExaminationQuestion.question_order.asc())
        .all()
    )

    questions_data = []
    for eq in eqs:
        q = eq.question
        if q:
            questions_data.append({
                "examination_question_id": eq.id,
                "question_id": q.id,
                "question_order": eq.question_order,
                "section_name": eq.section_name,
                "question_text": q.question_text,
                "question_type": q.question_type,
                "marks": eq.marks_override or q.marks,
                "options": q.options,
                "correct_answer": q.correct_answer,
                "explanation": q.explanation,
                "difficulty_level": q.current_difficulty or q.ai_difficulty_level
            })

    builder = ExaminationBuilder(db)
    validation = builder.validate_paper(exam.id)

    return {
        "examination": ExaminationResponse.model_validate(exam),
        "questions": questions_data,
        "validation": validation
    }


@router.post("/{id}/generate-paper")
def auto_generate_paper(
    id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role("teacher", "admin"))
):
    builder = ExaminationBuilder(db)
    try:
        res = builder.generate_paper(examination_id=id)
        log_activity(db, current_user.id, "generate_paper", "examination", id, res)
        return res
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Paper generation failed: {str(e)}")


@router.post("/{id}/validate")
def validate_paper(
    id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    builder = ExaminationBuilder(db)
    return builder.validate_paper(id)


@router.post("/{id}/publish")
def publish_examination(
    id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role("teacher", "admin"))
):
    exam = db.query(Examination).filter(Examination.id == id).first()
    if not exam:
        raise HTTPException(status_code=404, detail="Examination not found")

    builder = ExaminationBuilder(db)
    val = builder.validate_paper(exam.id)
    if not val["valid"]:
        raise HTTPException(status_code=400, detail=f"Cannot publish invalid examination: {val['errors']}")

    exam.status = "published"
    db.commit()
    log_activity(db, current_user.id, "publish_examination", "examination", exam.id)
    return {"message": "Examination published successfully", "examination_id": exam.id}
