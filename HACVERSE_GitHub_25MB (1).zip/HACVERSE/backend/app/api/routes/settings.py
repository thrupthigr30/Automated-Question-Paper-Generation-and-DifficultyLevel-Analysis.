"""System and AI Provider Configuration API endpoints."""
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, Body
from sqlalchemy.orm import Session

from app.database.session import get_db
from app.models import User
from app.schemas.base import SystemSettings, AIProviderStatus
from app.core.security import get_current_user, require_role
from app.core.config import settings
from app.services.ai.factory import get_ai_provider
from app.utils.activity import log_activity

router = APIRouter(prefix="/settings", tags=["System Settings"])


@router.get("", response_model=SystemSettings)
def get_system_settings(current_user: User = Depends(get_current_user)):
    return {
        "ai_provider": settings.AI_PROVIDER,
        "ai_model": settings.active_ai_model,
        "min_calibration_attempts": settings.MIN_CALIBRATION_ATTEMPTS,
        "easy_threshold": settings.EASY_THRESHOLD_PERCENT,
        "hard_threshold": settings.HARD_THRESHOLD_PERCENT,
        "confidence_level": settings.CONFIDENCE_LEVEL,
        "max_upload_size_mb": settings.MAX_UPLOAD_SIZE_MB,
        "ocr_enabled": settings.OCR_ENABLED
    }


@router.put("", response_model=SystemSettings)
def update_system_settings(
    settings_in: SystemSettings,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role("admin"))
):
    settings.AI_PROVIDER = settings_in.ai_provider
    settings.MIN_CALIBRATION_ATTEMPTS = settings_in.min_calibration_attempts
    settings.EASY_THRESHOLD_PERCENT = settings_in.easy_threshold
    settings.HARD_THRESHOLD_PERCENT = settings_in.hard_threshold
    settings.CONFIDENCE_LEVEL = settings_in.confidence_level

    log_activity(db, current_user.id, "update_system_settings", "settings")
    return get_system_settings(current_user)


@router.get("/ai-status", response_model=AIProviderStatus)
async def get_ai_provider_status(current_user: User = Depends(get_current_user)):
    provider = get_ai_provider()
    status_obj = await provider.check_connection()
    return {
        "provider": settings.AI_PROVIDER,
        "model": provider.model,
        "connected": status_obj.connected,
        "error": status_obj.message if not status_obj.connected else None
    }


@router.post("/test-ai")
async def test_ai_connection(
    provider_name: Optional[str] = Body(None, embed=True),
    current_user: User = Depends(require_role("admin", "teacher"))
):
    provider = get_ai_provider(provider_name=provider_name)
    status_obj = await provider.check_connection()
    return {
        "provider": provider.__class__.__name__,
        "model": provider.model,
        "connected": status_obj.connected,
        "message": status_obj.message,
        "available_models": status_obj.available_models
    }
