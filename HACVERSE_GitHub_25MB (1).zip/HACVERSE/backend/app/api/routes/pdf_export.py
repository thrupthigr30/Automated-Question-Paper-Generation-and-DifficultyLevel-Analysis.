"""Academic PDF Export API endpoints for Question Papers, Answer Keys, and Analysis Reports."""
from fastapi import APIRouter, Depends, HTTPException, Response
from sqlalchemy.orm import Session

from app.database.session import get_db
from app.models import Examination, ExaminationQuestion, Question, User
from app.core.security import get_current_user
from app.services.pdf.generator import PDFGenerator
from app.services.calibration.engine import CalibrationEngine

router = APIRouter(prefix="/examinations", tags=["PDF Export"])


@router.get("/{id}/question-paper.pdf")
def export_question_paper_pdf(
    id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Download official examination question paper PDF without answers."""
    exam = db.query(Examination).filter(Examination.id == id).first()
    if not exam:
        raise HTTPException(status_code=404, detail="Examination not found")

    eqs = (
        db.query(ExaminationQuestion)
        .filter(ExaminationQuestion.examination_id == exam.id)
        .order_by(ExaminationQuestion.question_order.asc())
        .all()
    )

    # Group questions by section
    sections_map = {}
    for eq in eqs:
        q = eq.question
        if not q:
            continue
        sec_name = eq.section_name or "General Section"
        if sec_name not in sections_map:
            sections_map[sec_name] = []
        sections_map[sec_name].append({
            "text": q.question_text,
            "marks": eq.marks_override or q.marks,
            "options": q.options
        })

    sections_payload = [{"name": name, "questions": qs} for name, qs in sections_map.items()]

    pdf_bytes = PDFGenerator.generate_question_paper(
        exam_title=exam.name,
        subject_name=exam.subject.name if exam.subject else "General Examination",
        duration_minutes=exam.duration_minutes,
        total_marks=exam.total_marks,
        instructions=exam.instructions,
        sections=sections_payload
    )

    filename = f"{exam.name.replace(' ', '_')}_QuestionPaper.pdf"
    return Response(
        content=pdf_bytes,
        media_type="application/pdf",
        headers={"Content-Disposition": f'inline; filename="{filename}"'}
    )


@router.get("/{id}/answer-key.pdf")
def export_answer_key_pdf(
    id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Download separate Official Model Answer Key and Rubrics PDF."""
    exam = db.query(Examination).filter(Examination.id == id).first()
    if not exam:
        raise HTTPException(status_code=404, detail="Examination not found")

    eqs = (
        db.query(ExaminationQuestion)
        .filter(ExaminationQuestion.examination_id == exam.id)
        .order_by(ExaminationQuestion.question_order.asc())
        .all()
    )

    questions_data = []
    for eq in eqs:
        q = eq.question
        if q:
            questions_data.append({
                "text": q.question_text,
                "marks": eq.marks_override or q.marks,
                "correct_answer": q.correct_answer,
                "explanation": q.explanation,
                "answer_rubric": q.answer_rubric,
                "answer_status": q.answer_status
            })

    pdf_bytes = PDFGenerator.generate_answer_key(
        exam_title=exam.name,
        subject_name=exam.subject.name if exam.subject else "General Examination",
        questions=questions_data
    )

    filename = f"{exam.name.replace(' ', '_')}_AnswerKey.pdf"
    return Response(
        content=pdf_bytes,
        media_type="application/pdf",
        headers={"Content-Disposition": f'inline; filename="{filename}"'}
    )


@router.get("/{id}/analysis.pdf")
def export_analysis_pdf(
    id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Download psychometric calibration and difficulty distribution analysis PDF."""
    exam = db.query(Examination).filter(Examination.id == id).first()
    if not exam:
        raise HTTPException(status_code=404, detail="Examination not found")

    engine = CalibrationEngine(db)
    summary = engine.run_full_calibration(subject_id=exam.subject_id)

    pdf_bytes = PDFGenerator.generate_analysis_report(
        subject_name=exam.subject.name if exam.subject else "General Examination",
        total_questions=summary.total_questions,
        calibrated_count=summary.eligible_questions,
        stats={
            "overall_agreement": summary.overall_agreement,
            "balanced_accuracy": summary.balanced_accuracy,
            "macro_f1": summary.macro_f1,
            "weighted_kappa": summary.weighted_kappa
        },
        matrix=summary.confusion_matrix
    )

    filename = f"{exam.name.replace(' ', '_')}_AnalysisReport.pdf"
    return Response(
        content=pdf_bytes,
        media_type="application/pdf",
        headers={"Content-Disposition": f'inline; filename="{filename}"'}
    )
