"""Difficulty Estimation and Cold-Start Status API endpoints."""
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from sqlalchemy import func

from app.database.session import get_db
from app.models import Question, DifficultyAssessment, DifficultyHistory, User
from app.schemas.base import DifficultySummary, DifficultyAssessmentResponse, DifficultyHistoryResponse
from app.core.security import get_current_user, require_role
from app.services.calibration.engine import CalibrationEngine
from app.utils.activity import log_activity

router = APIRouter(prefix="/difficulty", tags=["Difficulty Estimation"])


@router.get("/summary", response_model=DifficultySummary)
def get_difficulty_summary(
    subject_id: Optional[int] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    q = db.query(Question)
    if subject_id:
        q = q.filter(Question.subject_id == subject_id)

    total = q.count()
    ai_only = q.filter(Question.evidence_status == "ai_estimated").count()
    insufficient = q.filter(Question.evidence_status == "insufficient_data").count()
    low_conf = q.filter(Question.evidence_status == "low_confidence").count()
    calibrated = q.filter(Question.evidence_status == "performance_calibrated").count()

    easy_ai = q.filter(Question.ai_difficulty_level == "easy").count()
    med_ai = q.filter(Question.ai_difficulty_level == "medium").count()
    hard_ai = q.filter(Question.ai_difficulty_level == "hard").count()

    easy_obs = q.filter(Question.observed_difficulty_level == "easy").count()
    med_obs = q.filter(Question.observed_difficulty_level == "medium").count()
    hard_obs = q.filter(Question.observed_difficulty_level == "hard").count()

    awaiting_attempts = q.filter(Question.valid_attempt_count == 0).count()

    return {
        "total_questions": total,
        "ai_estimated_only": ai_only,
        "insufficient_data": insufficient,
        "low_confidence": low_conf,
        "performance_calibrated": calibrated,
        "easy_ai": easy_ai,
        "medium_ai": med_ai,
        "hard_ai": hard_ai,
        "easy_observed": easy_obs,
        "medium_observed": med_obs,
        "hard_observed": hard_obs,
        "awaiting_first_attempt": awaiting_attempts
    }


@router.get("/questions/{id}")
def get_question_difficulty_details(
    id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    q = db.query(Question).filter(Question.id == id).first()
    if not q:
        raise HTTPException(status_code=404, detail="Question not found")

    assessments = db.query(DifficultyAssessment).filter(DifficultyAssessment.question_id == q.id).all()
    history = db.query(DifficultyHistory).filter(DifficultyHistory.question_id == q.id).order_by(DifficultyHistory.created_at.desc()).all()

    return {
        "question_id": q.id,
        "question_text": q.question_text,
        "ai_difficulty_level": q.ai_difficulty_level,
        "ai_difficulty_score": q.ai_difficulty_score,
        "difficulty_reason": q.difficulty_reason,
        "bloom_level": q.bloom_level,
        "cognitive_characteristics": q.cognitive_characteristics,
        "observed_difficulty_level": q.observed_difficulty_level,
        "observed_difficulty_score": q.observed_difficulty_score,
        "current_displayed_difficulty": q.current_difficulty or q.ai_difficulty_level,
        "evidence_status": q.evidence_status,
        "valid_attempts": q.valid_attempt_count,
        "confidence_lower": q.confidence_lower,
        "confidence_upper": q.confidence_upper,
        "assessments": assessments,
        "history": history
    }


@router.post("/recalculate")
def recalculate_question_difficulty(
    question_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role("teacher", "admin"))
):
    q = db.query(Question).filter(Question.id == question_id).first()
    if not q:
        raise HTTPException(status_code=404, detail="Question not found")

    engine = CalibrationEngine(db)
    result = engine.calibrate_question(q)
    log_activity(db, current_user.id, "recalculate_difficulty", "question", q.id)
    return result


@router.get("/history/{id}", response_model=List[DifficultyHistoryResponse])
def get_difficulty_history(
    id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    return (
        db.query(DifficultyHistory)
        .filter(DifficultyHistory.question_id == id)
        .order_by(DifficultyHistory.created_at.desc())
        .all()
    )
