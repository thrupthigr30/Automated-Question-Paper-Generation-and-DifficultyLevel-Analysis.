"""Pydantic schemas for all API request/response models."""
from datetime import datetime
from typing import Optional, List, Any, Dict
from pydantic import BaseModel, Field, EmailStr, field_validator
import re


# ── Auth ────────────────────────────────────────────────────────────────

class UserRegister(BaseModel):
    username: str = Field(..., min_length=3, max_length=100)
    email: str = Field(..., max_length=255)
    full_name: str = Field(..., min_length=1, max_length=255)
    password: str = Field(..., min_length=6, max_length=128)
    role: str = Field(default="student")

    @field_validator("email")
    @classmethod
    def validate_email(cls, v):
        pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        if not re.match(pattern, v):
            raise ValueError("Invalid email address")
        return v.lower()


class UserLogin(BaseModel):
    username: str
    password: str


class UserResponse(BaseModel):
    id: int
    username: str
    email: str
    full_name: str
    role: str
    is_active: bool
    created_at: datetime

    class Config:
        from_attributes = True


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserResponse


# ── Subjects ────────────────────────────────────────────────────────────

class SubjectCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=255)
    code: Optional[str] = Field(None, max_length=50)
    description: Optional[str] = None


class SubjectUpdate(BaseModel):
    name: Optional[str] = Field(None, max_length=255)
    code: Optional[str] = Field(None, max_length=50)
    description: Optional[str] = None


class SubjectResponse(BaseModel):
    id: int
    name: str
    code: Optional[str]
    description: Optional[str]
    owner_id: int
    created_at: datetime
    updated_at: datetime
    unit_count: int = 0
    topic_count: int = 0
    question_count: int = 0
    document_count: int = 0

    class Config:
        from_attributes = True


# ── Units ───────────────────────────────────────────────────────────────

class UnitCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=255)
    unit_number: int = Field(..., ge=1)
    description: Optional[str] = None
    subject_id: int


class UnitUpdate(BaseModel):
    name: Optional[str] = None
    unit_number: Optional[int] = None
    description: Optional[str] = None


class UnitResponse(BaseModel):
    id: int
    name: str
    unit_number: int
    description: Optional[str]
    subject_id: int
    created_at: datetime
    topic_count: int = 0

    class Config:
        from_attributes = True


# ── Topics ──────────────────────────────────────────────────────────────

class TopicCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=255)
    description: Optional[str] = None
    unit_id: int


class TopicUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None


class TopicResponse(BaseModel):
    id: int
    name: str
    description: Optional[str]
    unit_id: int
    created_at: datetime
    subtopic_count: int = 0

    class Config:
        from_attributes = True


class SubtopicCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=255)
    description: Optional[str] = None
    topic_id: int


class SubtopicResponse(BaseModel):
    id: int
    name: str
    description: Optional[str]
    topic_id: int
    created_at: datetime

    class Config:
        from_attributes = True


# ── Documents ───────────────────────────────────────────────────────────

class DocumentResponse(BaseModel):
    id: int
    filename: str
    original_filename: str
    file_size: int
    file_extension: str
    category: str
    subject_id: int
    page_count: Optional[int]
    processing_status: str
    extraction_status: Optional[str]
    processing_error: Optional[str]
    is_scanned: bool
    data_origin: str
    created_at: datetime

    class Config:
        from_attributes = True


class DocumentChunkResponse(BaseModel):
    id: int
    document_id: int
    chunk_index: int
    content: str
    page_number: Optional[int]
    heading: Optional[str]
    topic_id: Optional[int]
    char_count: Optional[int]
    created_at: datetime

    class Config:
        from_attributes = True


# ── Questions ───────────────────────────────────────────────────────────

class QuestionGenerateRequest(BaseModel):
    subject_id: int
    unit_id: Optional[int] = None
    topic_id: Optional[int] = None
    subtopic_id: Optional[int] = None
    document_ids: Optional[List[int]] = None
    count: int = Field(default=5, ge=1, le=50)
    question_types: List[str] = Field(default=["mcq"])
    marks: int = Field(default=1, ge=1, le=20)
    difficulty: Optional[str] = None
    bloom_level: Optional[str] = None
    generation_mode: str = Field(default="topic")
    additional_instructions: Optional[str] = None


class QuestionCreate(BaseModel):
    question_text: str = Field(..., min_length=10)
    subject_id: int
    unit_id: Optional[int] = None
    topic_id: Optional[int] = None
    subtopic_id: Optional[int] = None
    question_type: str
    marks: int = Field(default=1, ge=1)
    options: Optional[List[Dict[str, str]]] = None
    correct_answer: Optional[str] = None
    explanation: Optional[str] = None
    answer_rubric: Optional[str] = None


class QuestionUpdate(BaseModel):
    question_text: Optional[str] = None
    unit_id: Optional[int] = None
    topic_id: Optional[int] = None
    subtopic_id: Optional[int] = None
    question_type: Optional[str] = None
    marks: Optional[int] = None
    options: Optional[List[Dict[str, str]]] = None
    correct_answer: Optional[str] = None
    explanation: Optional[str] = None
    answer_rubric: Optional[str] = None
    ai_difficulty_level: Optional[str] = None
    bloom_level: Optional[str] = None
    change_reason: Optional[str] = None


class QuestionResponse(BaseModel):
    id: int
    question_text: str
    subject_id: int
    unit_id: Optional[int]
    topic_id: Optional[int]
    subtopic_id: Optional[int]
    question_type: str
    marks: int
    options: Optional[List[Dict[str, str]]]
    correct_answer: Optional[str]
    explanation: Optional[str]
    answer_rubric: Optional[str]
    answer_status: Optional[str]
    ai_difficulty_level: Optional[str]
    ai_difficulty_score: Optional[float]
    difficulty_reason: Optional[str]
    bloom_level: Optional[str]
    cognitive_characteristics: Optional[Dict]
    observed_difficulty_level: Optional[str]
    observed_difficulty_score: Optional[float]
    current_difficulty: Optional[str]
    evidence_status: str
    valid_attempt_count: int
    confidence_lower: Optional[float]
    confidence_upper: Optional[float]
    last_calibration_date: Optional[datetime]
    source_document_id: Optional[int]
    source_page: Optional[int]
    generation_model: Optional[str]
    approval_status: str
    data_origin: str
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


class QuestionListResponse(BaseModel):
    questions: List[QuestionResponse]
    total: int
    page: int
    page_size: int


# ── Generation Run ─────────────────────────────────────────────────────

class GenerationRunResponse(BaseModel):
    id: int
    subject_id: int
    requested_count: int
    generated_count: int
    accepted_count: int
    question_types: Optional[List[str]]
    status: str
    error_message: Optional[str]
    ai_provider: Optional[str]
    ai_model: Optional[str]
    created_at: datetime
    completed_at: Optional[datetime]
    questions: List[QuestionResponse] = []

    class Config:
        from_attributes = True


# ── Difficulty ──────────────────────────────────────────────────────────

class DifficultyFeatures(BaseModel):
    cognitive_demand: float = Field(..., ge=1, le=5)
    reasoning_complexity: float = Field(..., ge=1, le=5)
    procedural_complexity: float = Field(..., ge=1, le=5)
    prerequisite_breadth: float = Field(..., ge=1, le=5)
    application_complexity: float = Field(..., ge=1, le=5)
    solution_depth: float = Field(..., ge=1, le=5)


class DifficultyEstimation(BaseModel):
    difficulty_level: str
    difficulty_score: float
    reasoning: str
    bloom_level: str
    features: DifficultyFeatures
    evidence_status: str = "ai_estimated"
    confidence: Optional[str] = None


class DifficultyAssessmentResponse(BaseModel):
    id: int
    question_id: int
    assessment_type: str
    difficulty_level: str
    difficulty_score: Optional[float]
    cognitive_demand: Optional[float]
    reasoning_complexity: Optional[float]
    procedural_complexity: Optional[float]
    prerequisite_breadth: Optional[float]
    application_complexity: Optional[float]
    solution_depth: Optional[float]
    bloom_level: Optional[str]
    reasoning: Optional[str]
    confidence_lower: Optional[float]
    confidence_upper: Optional[float]
    attempt_count: Optional[int]
    correct_rate: Optional[float]
    created_at: datetime

    class Config:
        from_attributes = True


class DifficultyHistoryResponse(BaseModel):
    id: int
    question_id: int
    previous_ai_level: Optional[str]
    previous_observed_level: Optional[str]
    new_observed_level: Optional[str]
    previous_displayed: Optional[str]
    new_displayed: Optional[str]
    valid_attempts: Optional[int]
    correct_rate: Optional[float]
    confidence_lower: Optional[float]
    confidence_upper: Optional[float]
    calibration_method: Optional[str]
    created_at: datetime

    class Config:
        from_attributes = True


class DifficultySummary(BaseModel):
    total_questions: int
    ai_estimated_only: int
    insufficient_data: int
    low_confidence: int
    performance_calibrated: int
    easy_ai: int
    medium_ai: int
    hard_ai: int
    easy_observed: int
    medium_observed: int
    hard_observed: int
    awaiting_first_attempt: int


# ── Calibration ─────────────────────────────────────────────────────────

class CalibrationRunResponse(BaseModel):
    id: int
    subject_id: Optional[int]
    total_questions: int
    eligible_questions: int
    correct_predictions: int
    overestimated: int
    underestimated: int
    overall_agreement: Optional[float]
    balanced_accuracy: Optional[float]
    macro_f1: Optional[float]
    weighted_kappa: Optional[float]
    confusion_matrix: Optional[Dict]
    per_class_metrics: Optional[Dict]
    created_at: datetime

    class Config:
        from_attributes = True


class CalibrationEvaluationResponse(BaseModel):
    id: int
    run_id: int
    question_id: int
    ai_predicted_level: str
    observed_level: str
    attempt_count: int
    performance_rate: float
    agreement: str
    confidence_info: Optional[Dict]
    created_at: datetime

    class Config:
        from_attributes = True


# ── PYQ ─────────────────────────────────────────────────────────────────

class PYQPaperResponse(BaseModel):
    id: int
    document_id: Optional[int]
    subject_id: int
    exam_name: Optional[str]
    exam_year: Optional[int]
    exam_type: Optional[str]
    total_marks: Optional[int]
    total_questions: Optional[int]
    processing_status: str
    created_at: datetime

    class Config:
        from_attributes = True


class PYQQuestionResponse(BaseModel):
    id: int
    paper_id: int
    question_number: Optional[str]
    question_text: str
    question_type: Optional[str]
    marks: Optional[int]
    topic_id: Optional[int]
    source_page: Optional[int]
    exact_repeat_count: int
    created_at: datetime

    class Config:
        from_attributes = True


class TopicFrequencyResponse(BaseModel):
    topic_id: int
    topic_name: str
    unit_name: str
    paper_count: int
    total_papers: int
    frequency_percent: float
    question_count: int
    total_marks: int


class PYQSummary(BaseModel):
    total_papers: int
    total_questions: int
    years_covered: List[int]
    topic_frequencies: List[TopicFrequencyResponse]
    repeated_questions: int


# ── Examinations ────────────────────────────────────────────────────────

class ExaminationCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=255)
    subject_id: int
    exam_type: str = "practice"
    total_marks: int = Field(..., ge=1)
    duration_minutes: int = Field(..., ge=1)
    instructions: Optional[str] = None
    easy_percent: float = Field(default=30.0, ge=0, le=100)
    medium_percent: float = Field(default=40.0, ge=0, le=100)
    hard_percent: float = Field(default=30.0, ge=0, le=100)
    topic_ids: Optional[List[int]] = None
    unit_ids: Optional[List[int]] = None
    question_types: Optional[List[str]] = None

    @field_validator("hard_percent")
    @classmethod
    def validate_distribution(cls, v, info):
        easy = info.data.get("easy_percent", 30.0)
        medium = info.data.get("medium_percent", 40.0)
        total = easy + medium + v
        if abs(total - 100.0) > 0.01:
            raise ValueError(f"Difficulty percentages must sum to 100%, got {total}%")
        return v


class ExaminationUpdate(BaseModel):
    name: Optional[str] = None
    exam_type: Optional[str] = None
    total_marks: Optional[int] = None
    duration_minutes: Optional[int] = None
    instructions: Optional[str] = None
    easy_percent: Optional[float] = None
    medium_percent: Optional[float] = None
    hard_percent: Optional[float] = None
    status: Optional[str] = None


class ExaminationResponse(BaseModel):
    id: int
    name: str
    subject_id: int
    exam_type: str
    total_marks: int
    duration_minutes: int
    instructions: Optional[str]
    easy_percent: float
    medium_percent: float
    hard_percent: float
    sections: Optional[List[Dict]]
    status: str
    created_by: int
    created_at: datetime
    updated_at: datetime
    question_count: int = 0
    actual_marks: int = 0

    class Config:
        from_attributes = True


# ── Assessments ─────────────────────────────────────────────────────────

class AssignmentCreate(BaseModel):
    examination_id: int
    student_ids: Optional[List[int]] = None  # None = all students
    start_time: Optional[datetime] = None
    end_time: Optional[datetime] = None
    status: str = "published"


class AssignmentResponse(BaseModel):
    id: int
    examination_id: int
    student_id: Optional[int]
    status: str
    start_time: Optional[datetime]
    end_time: Optional[datetime]
    created_at: datetime
    examination: Optional[ExaminationResponse] = None

    class Config:
        from_attributes = True


class SubmitAnswerRequest(BaseModel):
    question_id: int
    answer: str
    time_taken_seconds: Optional[int] = None


class SubmitExamRequest(BaseModel):
    responses: List[SubmitAnswerRequest]


class StudentResponseResponse(BaseModel):
    id: int
    question_id: int
    submitted_answer: Optional[str]
    is_correct: Optional[bool]
    marks_earned: Optional[float]
    max_marks: Optional[int]
    time_taken_seconds: Optional[int]
    evaluation_status: str
    submitted_at: datetime

    class Config:
        from_attributes = True


class AttemptResultResponse(BaseModel):
    attempt_id: int
    examination_name: str
    total_marks_earned: Optional[float]
    total_marks_possible: Optional[int]
    percentage: Optional[float]
    status: str
    submitted_at: Optional[datetime]
    responses: List[StudentResponseResponse] = []


# ── Datasets ────────────────────────────────────────────────────────────

class DatasetSummary(BaseModel):
    academic_content: int
    questions: int
    historical_exam: int
    student_responses: int
    calibration_records: int
    valid_records: int
    incomplete_records: int
    last_updated: Optional[datetime]


class DatasetImportRequest(BaseModel):
    dataset_type: str
    data: List[Dict[str, Any]]


class DatasetImportResponse(BaseModel):
    id: int
    dataset_type: str
    filename: str
    total_rows: int
    imported_rows: int
    skipped_rows: int
    error_rows: int
    errors: Optional[List[Dict]]
    status: str
    created_at: datetime

    class Config:
        from_attributes = True


# ── Performance ─────────────────────────────────────────────────────────

class PerformanceSummary(BaseModel):
    total_attempts: int
    total_responses: int
    unique_students: int
    avg_score_percent: Optional[float]
    questions_with_data: int


# ── Dashboard ───────────────────────────────────────────────────────────

class DashboardStats(BaseModel):
    total_subjects: int
    total_documents: int
    total_questions: int
    approved_questions: int
    pending_questions: int
    total_examinations: int
    total_responses: int
    questions_with_evidence: int
    questions_awaiting_review: int


class ActivityLogResponse(BaseModel):
    id: int
    user_id: Optional[int]
    action: str
    entity_type: Optional[str]
    entity_id: Optional[int]
    details: Optional[Dict]
    created_at: datetime

    class Config:
        from_attributes = True


# ── Settings ────────────────────────────────────────────────────────────

class AIProviderStatus(BaseModel):
    provider: str
    model: str
    connected: bool
    last_success: Optional[datetime] = None
    error: Optional[str] = None


class SystemSettings(BaseModel):
    ai_provider: str
    ai_model: str
    min_calibration_attempts: int
    easy_threshold: float
    hard_threshold: float
    confidence_level: float
    max_upload_size_mb: int
    ocr_enabled: bool


# ── Paginated ───────────────────────────────────────────────────────────

class PaginatedResponse(BaseModel):
    items: List[Any]
    total: int
    page: int
    page_size: int
    total_pages: int
