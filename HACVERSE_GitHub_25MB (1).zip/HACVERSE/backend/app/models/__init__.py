"""All SQLAlchemy models for HACVERSE.

Tables:
1. users
2. subjects
3. units
4. topics
5. subtopics
6. documents
7. document_chunks
8. question_generation_runs
9. questions
10. question_versions
11. question_sources
12. pyq_papers
13. pyq_questions
14. pyq_topic_mappings
15. examinations
16. examination_questions
17. examination_assignments
18. examination_attempts
19. student_responses
20. difficulty_assessments
21. difficulty_history
22. calibration_runs
23. calibration_evaluations
24. dataset_imports
25. dataset_snapshots
26. activity_logs
"""
from datetime import datetime, timezone
from sqlalchemy import (
    Column, Integer, String, Text, Float, Boolean, DateTime,
    ForeignKey, JSON, Enum, Index, UniqueConstraint, CheckConstraint
)
from sqlalchemy.orm import relationship
from app.database.session import Base
import enum


def utcnow():
    return datetime.now(timezone.utc)


# ── Enums ───────────────────────────────────────────────────────────────

class UserRole(str, enum.Enum):
    ADMIN = "admin"
    TEACHER = "teacher"
    STUDENT = "student"


class DocumentCategory(str, enum.Enum):
    SYLLABUS = "syllabus"
    TEXTBOOK = "textbook"
    LECTURE_NOTES = "lecture_notes"
    REFERENCE = "reference"
    PYQ = "pyq"
    ANSWER_KEY = "answer_key"
    OTHER = "other"


class ProcessingStatus(str, enum.Enum):
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"
    PARTIAL = "partial"


class QuestionType(str, enum.Enum):
    MCQ = "mcq"
    SHORT_ANSWER = "short_answer"
    LONG_ANSWER = "long_answer"
    NUMERICAL = "numerical"
    APPLICATION = "application"
    CONCEPTUAL = "conceptual"
    CASE_STUDY = "case_study"
    ASSERTION_REASONING = "assertion_reasoning"
    FILL_BLANK = "fill_blank"
    TRUE_FALSE = "true_false"


class DifficultyLevel(str, enum.Enum):
    EASY = "easy"
    MEDIUM = "medium"
    HARD = "hard"


class BloomLevel(str, enum.Enum):
    REMEMBER = "remember"
    UNDERSTAND = "understand"
    APPLY = "apply"
    ANALYZE = "analyze"
    EVALUATE = "evaluate"
    CREATE = "create"


class EvidenceStatus(str, enum.Enum):
    AI_ESTIMATED = "ai_estimated"
    INSUFFICIENT_DATA = "insufficient_data"
    LOW_CONFIDENCE = "low_confidence"
    PERFORMANCE_CALIBRATED = "performance_calibrated"


class ApprovalStatus(str, enum.Enum):
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"
    NEEDS_REVISION = "needs_revision"


class DataOrigin(str, enum.Enum):
    REAL_UPLOADED = "real_uploaded"
    AI_GENERATED = "ai_generated"
    MANUALLY_CREATED = "manually_created"
    STUDENT_SUBMITTED = "student_submitted"
    SYNTHETIC_TEST_DATA = "synthetic_test_data"


class AnswerStatus(str, enum.Enum):
    TEACHER_VERIFIED = "teacher_verified"
    REFERENCE_SUPPORTED = "reference_supported"
    AI_GENERATED_REVIEW = "ai_generated_review"


class ExaminationType(str, enum.Enum):
    PRACTICE = "practice"
    MOCK = "mock"
    UNIT_TEST = "unit_test"
    REVISION = "revision"
    PREPARATORY = "preparatory"
    MAIN = "main"


class EvaluationStatus(str, enum.Enum):
    PENDING = "pending"
    AUTO_EVALUATED = "auto_evaluated"
    TEACHER_GRADED = "teacher_graded"
    AI_ASSISTED = "ai_assisted"


class PredictionAgreement(str, enum.Enum):
    CORRECT = "correct"
    OVERESTIMATED = "overestimated"
    UNDERESTIMATED = "underestimated"
    INSUFFICIENT_EVIDENCE = "insufficient_evidence"


class AttemptStatus(str, enum.Enum):
    IN_PROGRESS = "in_progress"
    SUBMITTED = "submitted"
    TIMED_OUT = "timed_out"


class AssignmentStatus(str, enum.Enum):
    DRAFT = "draft"
    PUBLISHED = "published"
    CLOSED = "closed"
    ARCHIVED = "archived"


# ── 1. Users ────────────────────────────────────────────────────────────

class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, autoincrement=True)
    username = Column(String(100), unique=True, nullable=False, index=True)
    email = Column(String(255), unique=True, nullable=False, index=True)
    full_name = Column(String(255), nullable=False)
    hashed_password = Column(String(255), nullable=False)
    role = Column(String(20), nullable=False, default=UserRole.STUDENT.value)
    is_active = Column(Boolean, default=True, nullable=False)
    created_at = Column(DateTime, default=utcnow, nullable=False)
    updated_at = Column(DateTime, default=utcnow, onupdate=utcnow, nullable=False)

    # Relationships
    subjects = relationship("Subject", back_populates="owner")
    documents = relationship("Document", back_populates="uploaded_by_user")


# ── 2. Subjects ─────────────────────────────────────────────────────────

class Subject(Base):
    __tablename__ = "subjects"

    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(255), nullable=False)
    code = Column(String(50), nullable=True)
    description = Column(Text, nullable=True)
    owner_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    created_at = Column(DateTime, default=utcnow, nullable=False)
    updated_at = Column(DateTime, default=utcnow, onupdate=utcnow, nullable=False)

    owner = relationship("User", back_populates="subjects")
    units = relationship("Unit", back_populates="subject", cascade="all, delete-orphan")
    documents = relationship("Document", back_populates="subject")

    __table_args__ = (
        UniqueConstraint("name", "owner_id", name="uq_subject_owner"),
    )


# ── 3. Units ────────────────────────────────────────────────────────────

class Unit(Base):
    __tablename__ = "units"

    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(255), nullable=False)
    unit_number = Column(Integer, nullable=False)
    description = Column(Text, nullable=True)
    subject_id = Column(Integer, ForeignKey("subjects.id", ondelete="CASCADE"), nullable=False)
    created_at = Column(DateTime, default=utcnow, nullable=False)
    updated_at = Column(DateTime, default=utcnow, onupdate=utcnow, nullable=False)

    subject = relationship("Subject", back_populates="units")
    topics = relationship("Topic", back_populates="unit", cascade="all, delete-orphan")

    __table_args__ = (
        UniqueConstraint("subject_id", "unit_number", name="uq_unit_subject"),
    )


# ── 4. Topics ───────────────────────────────────────────────────────────

class Topic(Base):
    __tablename__ = "topics"

    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    unit_id = Column(Integer, ForeignKey("units.id", ondelete="CASCADE"), nullable=False)
    created_at = Column(DateTime, default=utcnow, nullable=False)
    updated_at = Column(DateTime, default=utcnow, onupdate=utcnow, nullable=False)

    unit = relationship("Unit", back_populates="topics")
    subtopics = relationship("Subtopic", back_populates="topic", cascade="all, delete-orphan")


# ── 5. Subtopics ────────────────────────────────────────────────────────

class Subtopic(Base):
    __tablename__ = "subtopics"

    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    topic_id = Column(Integer, ForeignKey("topics.id", ondelete="CASCADE"), nullable=False)
    created_at = Column(DateTime, default=utcnow, nullable=False)

    topic = relationship("Topic", back_populates="subtopics")


# ── 6. Documents ────────────────────────────────────────────────────────

class Document(Base):
    __tablename__ = "documents"

    id = Column(Integer, primary_key=True, autoincrement=True)
    filename = Column(String(500), nullable=False)
    original_filename = Column(String(500), nullable=False)
    file_path = Column(String(1000), nullable=False)
    file_size = Column(Integer, nullable=False)  # bytes
    file_extension = Column(String(20), nullable=False)
    category = Column(String(30), nullable=False, default=DocumentCategory.OTHER.value)
    subject_id = Column(Integer, ForeignKey("subjects.id"), nullable=False)
    uploaded_by = Column(Integer, ForeignKey("users.id"), nullable=False)
    page_count = Column(Integer, nullable=True)
    processing_status = Column(String(20), default=ProcessingStatus.PENDING.value, nullable=False)
    extraction_status = Column(String(20), nullable=True)
    processing_error = Column(Text, nullable=True)
    metadata_json = Column(JSON, nullable=True)
    is_scanned = Column(Boolean, default=False)
    data_origin = Column(String(30), default=DataOrigin.REAL_UPLOADED.value, nullable=False)
    created_at = Column(DateTime, default=utcnow, nullable=False)
    updated_at = Column(DateTime, default=utcnow, onupdate=utcnow, nullable=False)

    subject = relationship("Subject", back_populates="documents")
    uploaded_by_user = relationship("User", back_populates="documents")
    chunks = relationship("DocumentChunk", back_populates="document", cascade="all, delete-orphan")


# ── 7. Document Chunks ─────────────────────────────────────────────────

class DocumentChunk(Base):
    __tablename__ = "document_chunks"

    id = Column(Integer, primary_key=True, autoincrement=True)
    document_id = Column(Integer, ForeignKey("documents.id", ondelete="CASCADE"), nullable=False)
    chunk_index = Column(Integer, nullable=False)
    content = Column(Text, nullable=False)
    page_number = Column(Integer, nullable=True)
    page_end = Column(Integer, nullable=True)
    heading = Column(String(500), nullable=True)
    topic_id = Column(Integer, ForeignKey("topics.id", ondelete="SET NULL"), nullable=True)
    char_count = Column(Integer, nullable=True)
    extraction_method = Column(String(30), nullable=True)
    data_origin = Column(String(30), default=DataOrigin.REAL_UPLOADED.value, nullable=False)
    created_at = Column(DateTime, default=utcnow, nullable=False)

    document = relationship("Document", back_populates="chunks")
    topic = relationship("Topic")

    __table_args__ = (
        Index("ix_chunk_document_topic", "document_id", "topic_id"),
    )


# ── 8. Question Generation Runs ────────────────────────────────────────

class QuestionGenerationRun(Base):
    __tablename__ = "question_generation_runs"

    id = Column(Integer, primary_key=True, autoincrement=True)
    subject_id = Column(Integer, ForeignKey("subjects.id"), nullable=False)
    unit_id = Column(Integer, ForeignKey("units.id"), nullable=True)
    topic_id = Column(Integer, ForeignKey("topics.id"), nullable=True)
    requested_count = Column(Integer, nullable=False)
    generated_count = Column(Integer, default=0)
    accepted_count = Column(Integer, default=0)
    rejected_count = Column(Integer, default=0)
    question_types = Column(JSON, nullable=True)
    difficulty_requested = Column(String(20), nullable=True)
    bloom_level_requested = Column(String(20), nullable=True)
    marks = Column(Integer, nullable=True)
    generation_mode = Column(String(50), nullable=True)
    ai_provider = Column(String(50), nullable=True)
    ai_model = Column(String(100), nullable=True)
    prompt_version = Column(String(50), nullable=True)
    status = Column(String(20), default=ProcessingStatus.PENDING.value, nullable=False)
    error_message = Column(Text, nullable=True)
    additional_instructions = Column(Text, nullable=True)
    created_by = Column(Integer, ForeignKey("users.id"), nullable=False)
    created_at = Column(DateTime, default=utcnow, nullable=False)
    completed_at = Column(DateTime, nullable=True)

    questions = relationship("Question", back_populates="generation_run")


# ── 9. Questions ────────────────────────────────────────────────────────

class Question(Base):
    __tablename__ = "questions"

    id = Column(Integer, primary_key=True, autoincrement=True)
    question_text = Column(Text, nullable=False)
    subject_id = Column(Integer, ForeignKey("subjects.id"), nullable=False)
    unit_id = Column(Integer, ForeignKey("units.id"), nullable=True)
    topic_id = Column(Integer, ForeignKey("topics.id"), nullable=True)
    subtopic_id = Column(Integer, ForeignKey("subtopics.id", ondelete="SET NULL"), nullable=True)
    question_type = Column(String(30), nullable=False)
    marks = Column(Integer, nullable=False, default=1)
    options = Column(JSON, nullable=True)  # For MCQ: [{"label":"A","text":"..."},...]
    correct_answer = Column(Text, nullable=True)
    explanation = Column(Text, nullable=True)
    answer_rubric = Column(Text, nullable=True)
    answer_status = Column(String(30), default=AnswerStatus.AI_GENERATED_REVIEW.value)

    # AI Difficulty
    ai_difficulty_level = Column(String(20), nullable=True)
    ai_difficulty_score = Column(Float, nullable=True)
    difficulty_reason = Column(Text, nullable=True)
    bloom_level = Column(String(20), nullable=True)
    cognitive_characteristics = Column(JSON, nullable=True)

    # Observed Difficulty
    observed_difficulty_level = Column(String(20), nullable=True)
    observed_difficulty_score = Column(Float, nullable=True)
    current_difficulty = Column(String(20), nullable=True)
    evidence_status = Column(String(30), default=EvidenceStatus.AI_ESTIMATED.value, nullable=False)
    valid_attempt_count = Column(Integer, default=0)
    confidence_lower = Column(Float, nullable=True)
    confidence_upper = Column(Float, nullable=True)
    last_calibration_date = Column(DateTime, nullable=True)
    calibration_method = Column(String(50), nullable=True)

    # Source
    source_document_id = Column(Integer, ForeignKey("documents.id", ondelete="SET NULL"), nullable=True)
    source_page = Column(Integer, nullable=True)
    generation_run_id = Column(Integer, ForeignKey("question_generation_runs.id", ondelete="SET NULL"), nullable=True)
    generation_model = Column(String(100), nullable=True)
    prompt_version = Column(String(50), nullable=True)

    # Meta
    approval_status = Column(String(20), default=ApprovalStatus.PENDING.value, nullable=False)
    data_origin = Column(String(30), default=DataOrigin.AI_GENERATED.value, nullable=False)
    duplicate_group_id = Column(Integer, nullable=True)
    created_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime, default=utcnow, nullable=False)
    updated_at = Column(DateTime, default=utcnow, onupdate=utcnow, nullable=False)

    subject = relationship("Subject")
    unit = relationship("Unit")
    topic = relationship("Topic")
    subtopic = relationship("Subtopic")
    source_document = relationship("Document")
    generation_run = relationship("QuestionGenerationRun", back_populates="questions")
    versions = relationship("QuestionVersion", back_populates="question", cascade="all, delete-orphan")
    sources = relationship("QuestionSource", back_populates="question", cascade="all, delete-orphan")
    student_responses = relationship("StudentResponse", back_populates="question")
    difficulty_assessments = relationship("DifficultyAssessment", back_populates="question")
    difficulty_history = relationship("DifficultyHistory", back_populates="question")

    __table_args__ = (
        Index("ix_question_subject_topic", "subject_id", "topic_id"),
        Index("ix_question_difficulty", "ai_difficulty_level", "observed_difficulty_level"),
        Index("ix_question_approval", "approval_status"),
    )


# ── 10. Question Versions ──────────────────────────────────────────────

class QuestionVersion(Base):
    __tablename__ = "question_versions"

    id = Column(Integer, primary_key=True, autoincrement=True)
    question_id = Column(Integer, ForeignKey("questions.id", ondelete="CASCADE"), nullable=False)
    version_number = Column(Integer, nullable=False)
    question_text = Column(Text, nullable=False)
    options = Column(JSON, nullable=True)
    correct_answer = Column(Text, nullable=True)
    explanation = Column(Text, nullable=True)
    marks = Column(Integer, nullable=True)
    change_reason = Column(String(500), nullable=True)
    changed_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime, default=utcnow, nullable=False)

    question = relationship("Question", back_populates="versions")


# ── 11. Question Sources ───────────────────────────────────────────────

class QuestionSource(Base):
    __tablename__ = "question_sources"

    id = Column(Integer, primary_key=True, autoincrement=True)
    question_id = Column(Integer, ForeignKey("questions.id", ondelete="CASCADE"), nullable=False)
    document_id = Column(Integer, ForeignKey("documents.id", ondelete="SET NULL"), nullable=True)
    page_number = Column(Integer, nullable=True)
    chunk_id = Column(Integer, ForeignKey("document_chunks.id", ondelete="SET NULL"), nullable=True)
    source_type = Column(String(50), nullable=True)  # e.g. "textbook", "syllabus", "pyq"
    relevance_score = Column(Float, nullable=True)
    created_at = Column(DateTime, default=utcnow, nullable=False)

    question = relationship("Question", back_populates="sources")


# ── 12. PYQ Papers ─────────────────────────────────────────────────────

class PYQPaper(Base):
    __tablename__ = "pyq_papers"

    id = Column(Integer, primary_key=True, autoincrement=True)
    document_id = Column(Integer, ForeignKey("documents.id", ondelete="SET NULL"), nullable=True)
    subject_id = Column(Integer, ForeignKey("subjects.id"), nullable=False)
    exam_name = Column(String(255), nullable=True)
    exam_year = Column(Integer, nullable=True)
    exam_type = Column(String(100), nullable=True)
    total_marks = Column(Integer, nullable=True)
    total_questions = Column(Integer, nullable=True)
    processing_status = Column(String(20), default=ProcessingStatus.PENDING.value)
    data_origin = Column(String(30), default=DataOrigin.REAL_UPLOADED.value)
    created_at = Column(DateTime, default=utcnow, nullable=False)
    updated_at = Column(DateTime, default=utcnow, onupdate=utcnow, nullable=False)

    questions = relationship("PYQQuestion", back_populates="paper", cascade="all, delete-orphan")
    topic_mappings = relationship("PYQTopicMapping", back_populates="paper", cascade="all, delete-orphan")


# ── 13. PYQ Questions ──────────────────────────────────────────────────

class PYQQuestion(Base):
    __tablename__ = "pyq_questions"

    id = Column(Integer, primary_key=True, autoincrement=True)
    paper_id = Column(Integer, ForeignKey("pyq_papers.id", ondelete="CASCADE"), nullable=False)
    question_number = Column(String(20), nullable=True)
    question_text = Column(Text, nullable=False)
    question_type = Column(String(30), nullable=True)
    marks = Column(Integer, nullable=True)
    topic_id = Column(Integer, ForeignKey("topics.id", ondelete="SET NULL"), nullable=True)
    source_page = Column(Integer, nullable=True)
    exact_repeat_count = Column(Integer, default=0)
    similar_question_ids = Column(JSON, nullable=True)
    data_origin = Column(String(30), default=DataOrigin.REAL_UPLOADED.value)
    created_at = Column(DateTime, default=utcnow, nullable=False)

    paper = relationship("PYQPaper", back_populates="questions")
    topic = relationship("Topic")


# ── 14. PYQ Topic Mappings ──────────────────────────────────────────────

class PYQTopicMapping(Base):
    __tablename__ = "pyq_topic_mappings"

    id = Column(Integer, primary_key=True, autoincrement=True)
    paper_id = Column(Integer, ForeignKey("pyq_papers.id", ondelete="CASCADE"), nullable=False)
    topic_id = Column(Integer, ForeignKey("topics.id", ondelete="CASCADE"), nullable=False)
    question_count = Column(Integer, default=0)
    total_marks = Column(Integer, default=0)
    frequency_percent = Column(Float, nullable=True)

    paper = relationship("PYQPaper", back_populates="topic_mappings")
    topic = relationship("Topic")


# ── 15. Examinations ───────────────────────────────────────────────────

class Examination(Base):
    __tablename__ = "examinations"

    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(255), nullable=False)
    subject_id = Column(Integer, ForeignKey("subjects.id"), nullable=False)
    exam_type = Column(String(30), default=ExaminationType.PRACTICE.value, nullable=False)
    total_marks = Column(Integer, nullable=False)
    duration_minutes = Column(Integer, nullable=False)
    instructions = Column(Text, nullable=True)
    easy_percent = Column(Float, default=30.0)
    medium_percent = Column(Float, default=40.0)
    hard_percent = Column(Float, default=30.0)
    sections = Column(JSON, nullable=True)  # [{name, instructions, question_ids}]
    status = Column(String(20), default="draft", nullable=False)
    created_by = Column(Integer, ForeignKey("users.id"), nullable=False)
    created_at = Column(DateTime, default=utcnow, nullable=False)
    updated_at = Column(DateTime, default=utcnow, onupdate=utcnow, nullable=False)

    subject = relationship("Subject")
    creator = relationship("User")
    exam_questions = relationship("ExaminationQuestion", back_populates="examination", cascade="all, delete-orphan")
    assignments = relationship("ExaminationAssignment", back_populates="examination", cascade="all, delete-orphan")


# ── 16. Examination Questions ──────────────────────────────────────────

class ExaminationQuestion(Base):
    __tablename__ = "examination_questions"

    id = Column(Integer, primary_key=True, autoincrement=True)
    examination_id = Column(Integer, ForeignKey("examinations.id", ondelete="CASCADE"), nullable=False)
    question_id = Column(Integer, ForeignKey("questions.id"), nullable=False)
    question_order = Column(Integer, nullable=False)
    section_name = Column(String(100), nullable=True)
    marks_override = Column(Integer, nullable=True)

    examination = relationship("Examination", back_populates="exam_questions")
    question = relationship("Question")

    __table_args__ = (
        UniqueConstraint("examination_id", "question_id", name="uq_exam_question"),
    )


# ── 17. Examination Assignments ────────────────────────────────────────

class ExaminationAssignment(Base):
    __tablename__ = "examination_assignments"

    id = Column(Integer, primary_key=True, autoincrement=True)
    examination_id = Column(Integer, ForeignKey("examinations.id", ondelete="CASCADE"), nullable=False)
    student_id = Column(Integer, ForeignKey("users.id"), nullable=True)  # null = all students
    status = Column(String(20), default=AssignmentStatus.DRAFT.value, nullable=False)
    start_time = Column(DateTime, nullable=True)
    end_time = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=utcnow, nullable=False)

    examination = relationship("Examination", back_populates="assignments")
    student = relationship("User")
    attempts = relationship("ExaminationAttempt", back_populates="assignment", cascade="all, delete-orphan")


# ── 18. Examination Attempts ───────────────────────────────────────────

class ExaminationAttempt(Base):
    __tablename__ = "examination_attempts"

    id = Column(Integer, primary_key=True, autoincrement=True)
    assignment_id = Column(Integer, ForeignKey("examination_assignments.id", ondelete="CASCADE"), nullable=False)
    student_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    attempt_number = Column(Integer, default=1, nullable=False)
    status = Column(String(20), default=AttemptStatus.IN_PROGRESS.value, nullable=False)
    started_at = Column(DateTime, default=utcnow, nullable=False)
    submitted_at = Column(DateTime, nullable=True)
    total_marks_earned = Column(Float, nullable=True)
    total_marks_possible = Column(Integer, nullable=True)
    time_taken_seconds = Column(Integer, nullable=True)

    assignment = relationship("ExaminationAssignment", back_populates="attempts")
    student = relationship("User")
    responses = relationship("StudentResponse", back_populates="attempt", cascade="all, delete-orphan")


# ── 19. Student Responses ──────────────────────────────────────────────

class StudentResponse(Base):
    __tablename__ = "student_responses"

    id = Column(Integer, primary_key=True, autoincrement=True)
    attempt_id = Column(Integer, ForeignKey("examination_attempts.id", ondelete="CASCADE"), nullable=False)
    question_id = Column(Integer, ForeignKey("questions.id"), nullable=False)
    student_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    examination_id = Column(Integer, ForeignKey("examinations.id"), nullable=True)
    submitted_answer = Column(Text, nullable=True)
    is_correct = Column(Boolean, nullable=True)
    marks_earned = Column(Float, nullable=True)
    max_marks = Column(Integer, nullable=True)
    time_taken_seconds = Column(Integer, nullable=True)
    attempt_number = Column(Integer, default=1)
    evaluation_status = Column(String(20), default=EvaluationStatus.PENDING.value, nullable=False)
    evaluator_notes = Column(Text, nullable=True)
    data_origin = Column(String(30), default=DataOrigin.STUDENT_SUBMITTED.value, nullable=False)
    submitted_at = Column(DateTime, default=utcnow, nullable=False)

    attempt = relationship("ExaminationAttempt", back_populates="responses")
    question = relationship("Question", back_populates="student_responses")

    __table_args__ = (
        Index("ix_response_question_student", "question_id", "student_id"),
    )


# ── 20. Difficulty Assessments ─────────────────────────────────────────

class DifficultyAssessment(Base):
    __tablename__ = "difficulty_assessments"

    id = Column(Integer, primary_key=True, autoincrement=True)
    question_id = Column(Integer, ForeignKey("questions.id", ondelete="CASCADE"), nullable=False)
    assessment_type = Column(String(30), nullable=False)  # "ai_initial", "performance", "hybrid"
    difficulty_level = Column(String(20), nullable=False)
    difficulty_score = Column(Float, nullable=True)
    cognitive_demand = Column(Float, nullable=True)
    reasoning_complexity = Column(Float, nullable=True)
    procedural_complexity = Column(Float, nullable=True)
    prerequisite_breadth = Column(Float, nullable=True)
    application_complexity = Column(Float, nullable=True)
    solution_depth = Column(Float, nullable=True)
    bloom_level = Column(String(20), nullable=True)
    reasoning = Column(Text, nullable=True)
    confidence_lower = Column(Float, nullable=True)
    confidence_upper = Column(Float, nullable=True)
    attempt_count = Column(Integer, nullable=True)
    correct_rate = Column(Float, nullable=True)
    model_id = Column(String(100), nullable=True)
    rubric_version = Column(String(50), nullable=True)
    created_at = Column(DateTime, default=utcnow, nullable=False)

    question = relationship("Question", back_populates="difficulty_assessments")


# ── 21. Difficulty History ──────────────────────────────────────────────

class DifficultyHistory(Base):
    __tablename__ = "difficulty_history"

    id = Column(Integer, primary_key=True, autoincrement=True)
    question_id = Column(Integer, ForeignKey("questions.id", ondelete="CASCADE"), nullable=False)
    previous_ai_level = Column(String(20), nullable=True)
    previous_observed_level = Column(String(20), nullable=True)
    new_observed_level = Column(String(20), nullable=True)
    previous_displayed = Column(String(20), nullable=True)
    new_displayed = Column(String(20), nullable=True)
    valid_attempts = Column(Integer, nullable=True)
    correct_rate = Column(Float, nullable=True)
    avg_score_percent = Column(Float, nullable=True)
    confidence_lower = Column(Float, nullable=True)
    confidence_upper = Column(Float, nullable=True)
    calibration_method = Column(String(50), nullable=True)
    rule_version = Column(String(50), nullable=True)
    created_at = Column(DateTime, default=utcnow, nullable=False)

    question = relationship("Question", back_populates="difficulty_history")


# ── 22. Calibration Runs ───────────────────────────────────────────────

class CalibrationRun(Base):
    __tablename__ = "calibration_runs"

    id = Column(Integer, primary_key=True, autoincrement=True)
    subject_id = Column(Integer, ForeignKey("subjects.id"), nullable=True)
    total_questions = Column(Integer, default=0)
    eligible_questions = Column(Integer, default=0)
    correct_predictions = Column(Integer, default=0)
    overestimated = Column(Integer, default=0)
    underestimated = Column(Integer, default=0)
    overall_agreement = Column(Float, nullable=True)
    balanced_accuracy = Column(Float, nullable=True)
    macro_f1 = Column(Float, nullable=True)
    weighted_kappa = Column(Float, nullable=True)
    confusion_matrix = Column(JSON, nullable=True)
    per_class_metrics = Column(JSON, nullable=True)
    rule_version = Column(String(50), nullable=True)
    min_attempts_used = Column(Integer, nullable=True)
    created_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime, default=utcnow, nullable=False)

    evaluations = relationship("CalibrationEvaluation", back_populates="run", cascade="all, delete-orphan")


# ── 23. Calibration Evaluations ────────────────────────────────────────

class CalibrationEvaluation(Base):
    __tablename__ = "calibration_evaluations"

    id = Column(Integer, primary_key=True, autoincrement=True)
    run_id = Column(Integer, ForeignKey("calibration_runs.id", ondelete="CASCADE"), nullable=False)
    question_id = Column(Integer, ForeignKey("questions.id"), nullable=False)
    ai_predicted_level = Column(String(20), nullable=False)
    observed_level = Column(String(20), nullable=False)
    attempt_count = Column(Integer, nullable=False)
    performance_rate = Column(Float, nullable=False)
    agreement = Column(String(30), nullable=False)  # PredictionAgreement value
    confidence_info = Column(JSON, nullable=True)
    created_at = Column(DateTime, default=utcnow, nullable=False)

    run = relationship("CalibrationRun", back_populates="evaluations")
    question = relationship("Question")


# ── 24. Dataset Imports ─────────────────────────────────────────────────

class DatasetImport(Base):
    __tablename__ = "dataset_imports"

    id = Column(Integer, primary_key=True, autoincrement=True)
    dataset_type = Column(String(50), nullable=False)  # "questions", "responses", etc.
    filename = Column(String(500), nullable=False)
    file_format = Column(String(20), nullable=False)
    total_rows = Column(Integer, default=0)
    imported_rows = Column(Integer, default=0)
    skipped_rows = Column(Integer, default=0)
    error_rows = Column(Integer, default=0)
    errors = Column(JSON, nullable=True)
    status = Column(String(20), default=ProcessingStatus.PENDING.value)
    imported_by = Column(Integer, ForeignKey("users.id"), nullable=False)
    created_at = Column(DateTime, default=utcnow, nullable=False)


# ── 25. Dataset Snapshots ──────────────────────────────────────────────

class DatasetSnapshot(Base):
    __tablename__ = "dataset_snapshots"

    id = Column(Integer, primary_key=True, autoincrement=True)
    dataset_type = Column(String(50), nullable=False)
    version_label = Column(String(100), nullable=True)
    record_count = Column(Integer, default=0)
    snapshot_metadata = Column(JSON, nullable=True)
    created_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime, default=utcnow, nullable=False)


# ── 26. Activity Logs ──────────────────────────────────────────────────

class ActivityLog(Base):
    __tablename__ = "activity_logs"

    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    action = Column(String(100), nullable=False)
    entity_type = Column(String(50), nullable=True)
    entity_id = Column(Integer, nullable=True)
    details = Column(JSON, nullable=True)
    ip_address = Column(String(50), nullable=True)
    created_at = Column(DateTime, default=utcnow, nullable=False)

    __table_args__ = (
        Index("ix_activity_user_action", "user_id", "action"),
        Index("ix_activity_entity", "entity_type", "entity_id"),
    )
