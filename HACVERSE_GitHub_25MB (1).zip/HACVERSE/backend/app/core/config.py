"""Core configuration loaded from environment variables."""
import os
from pathlib import Path
from pydantic_settings import BaseSettings
from typing import Optional


BASE_DIR = Path(__file__).resolve().parent.parent.parent.parent
DEFAULT_DB_PATH = (BASE_DIR / "app.db").as_posix()

class Settings(BaseSettings):
    # Application
    APP_NAME: str = "HACVERSE"
    APP_ENV: str = "development"
    SECRET_KEY: str = "change-this-to-a-random-secret-key-in-production"
    DEBUG: bool = True

    # Database
    DATABASE_URL: str = f"sqlite:///{DEFAULT_DB_PATH}"

    # AI Provider
    AI_PROVIDER: str = "gemini"
    AI_API_KEY: str = ""
    AI_BASE_URL: str = ""
    AI_MODEL: str = ""
    AI_TIMEOUT_SECONDS: int = 90
    AI_MAX_RETRIES: int = 2

    # Provider-specific
    GEMINI_API_KEY: str = ""
    GEMINI_MODEL: str = "gemini-2.0-flash"
    OPENAI_API_KEY: str = ""
    OPENAI_MODEL: str = "gpt-4o"
    ANTHROPIC_API_KEY: str = ""
    ANTHROPIC_MODEL: str = "claude-sonnet-4-20250514"
    GROQ_API_KEY: str = ""
    GROQ_MODEL: str = "llama-3.1-70b-versatile"
    OPENROUTER_API_KEY: str = ""
    OPENROUTER_BASE_URL: str = "https://openrouter.ai/api/v1"
    OPENROUTER_MODEL: str = ""
    OLLAMA_BASE_URL: str = "http://localhost:11434"
    OLLAMA_MODEL: str = "llama3.1"

    # File Storage
    UPLOAD_DIRECTORY: str = "./storage/uploads"
    EXTRACTED_DIRECTORY: str = "./storage/extracted"
    GENERATED_DIRECTORY: str = "./storage/generated"
    MAX_UPLOAD_SIZE_MB: int = 25

    # Document Processing
    OCR_ENABLED: bool = False
    TESSERACT_PATH: str = ""

    # Calibration
    MIN_CALIBRATION_ATTEMPTS: int = 10
    EASY_THRESHOLD_PERCENT: float = 75.0
    HARD_THRESHOLD_PERCENT: float = 40.0
    CONFIDENCE_LEVEL: float = 0.95

    # JWT
    JWT_ALGORITHM: str = "HS256"
    JWT_ACCESS_TOKEN_EXPIRE_MINUTES: int = 480

    @property
    def active_ai_key(self) -> str:
        if self.AI_API_KEY:
            return self.AI_API_KEY
        provider_keys = {
            "gemini": self.GEMINI_API_KEY,
            "openai": self.OPENAI_API_KEY,
            "anthropic": self.ANTHROPIC_API_KEY,
            "groq": self.GROQ_API_KEY,
            "openrouter": self.OPENROUTER_API_KEY,
        }
        return provider_keys.get(self.AI_PROVIDER, "")

    @property
    def active_ai_model(self) -> str:
        if self.AI_MODEL:
            return self.AI_MODEL
        provider_models = {
            "gemini": self.GEMINI_MODEL,
            "openai": self.OPENAI_MODEL,
            "anthropic": self.ANTHROPIC_MODEL,
            "groq": self.GROQ_MODEL,
            "openrouter": self.OPENROUTER_MODEL,
            "ollama": self.OLLAMA_MODEL,
        }
        return provider_models.get(self.AI_PROVIDER, "")

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        extra = "ignore"


settings = Settings()

# Ensure directories exist
for d in [settings.UPLOAD_DIRECTORY, settings.EXTRACTED_DIRECTORY,
          settings.GENERATED_DIRECTORY]:
    Path(d).mkdir(parents=True, exist_ok=True)
