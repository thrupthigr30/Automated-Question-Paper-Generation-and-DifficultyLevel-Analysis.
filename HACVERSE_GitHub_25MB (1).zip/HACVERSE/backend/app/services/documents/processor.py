"""Document extraction and chunking pipeline.
Supports PDF (via PyMuPDF / fitz), DOCX (via python-docx), and TXT files.
Detects image-based scanned PDFs, extracts page-level text, and produces chunks.
"""
import os
import re
import logging
from typing import List, Dict, Any, Tuple, Optional
from pathlib import Path
import pymupdf as fitz
import docx

logger = logging.getLogger(__name__)


class DocumentProcessor:
    """Processes uploaded academic files, extracts text per page/section, and creates chunks."""

    def __init__(self, chunk_size: int = 1500, chunk_overlap: int = 200):
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap

    def process_file(self, file_path: str, file_extension: str) -> Dict[str, Any]:
        """Extract text and metadata from file based on extension.
        Returns:
            dict with:
                - page_count: int
                - pages: list of {"page_number": int, "text": str}
                - is_scanned: bool
                - extraction_status: "success" | "partial" | "scanned_needs_ocr" | "failed"
                - error_message: str or None
        """
        ext = file_extension.lower().lstrip(".")
        if ext == "pdf":
            return self._extract_pdf(file_path)
        elif ext in ["docx", "doc"]:
            return self._extract_docx(file_path)
        elif ext in ["txt", "md"]:
            return self._extract_txt(file_path)
        else:
            return {
                "page_count": 0,
                "pages": [],
                "is_scanned": False,
                "extraction_status": "failed",
                "error_message": f"Unsupported file extension: .{ext}"
            }

    def _extract_pdf(self, file_path: str) -> Dict[str, Any]:
        try:
            doc = fitz.open(file_path)
            page_count = len(doc)
            pages = []
            total_chars = 0
            empty_pages = 0

            for page_idx in range(page_count):
                page = doc.load_page(page_idx)
                text = page.get_text("text").strip()
                char_count = len(text)
                total_chars += char_count

                if char_count < 20:
                    # Check if page has images
                    image_list = page.get_images(full=True)
                    if image_list:
                        empty_pages += 1

                pages.append({
                    "page_number": page_idx + 1,
                    "text": text
                })

            doc.close()

            # Determine if document appears scanned
            is_scanned = (empty_pages > 0 and (empty_pages / max(1, page_count)) > 0.5) or (page_count > 0 and total_chars < 50)
            status = "scanned_needs_ocr" if is_scanned else "success"

            return {
                "page_count": page_count,
                "pages": pages,
                "is_scanned": is_scanned,
                "extraction_status": status,
                "error_message": "Scanned document detected. OCR is recommended for full text." if is_scanned else None
            }
        except Exception as e:
            logger.error(f"PDF extraction error for {file_path}: {e}")
            return {
                "page_count": 0,
                "pages": [],
                "is_scanned": False,
                "extraction_status": "failed",
                "error_message": f"Failed to extract PDF: {str(e)}"
            }

    def _extract_docx(self, file_path: str) -> Dict[str, Any]:
        try:
            doc = docx.Document(file_path)
            paragraphs = [p.text for p in doc.paragraphs if p.text.strip()]
            full_text = "\n\n".join(paragraphs)
            
            # Simulate pages roughly by char count (~2500 chars/page)
            char_count = len(full_text)
            simulated_pages = max(1, (char_count // 2500) + 1)
            pages = [{"page_number": 1, "text": full_text}]

            return {
                "page_count": simulated_pages,
                "pages": pages,
                "is_scanned": False,
                "extraction_status": "success",
                "error_message": None
            }
        except Exception as e:
            logger.error(f"DOCX extraction error for {file_path}: {e}")
            return {
                "page_count": 0,
                "pages": [],
                "is_scanned": False,
                "extraction_status": "failed",
                "error_message": f"Failed to extract DOCX: {str(e)}"
            }

    def _extract_txt(self, file_path: str) -> Dict[str, Any]:
        try:
            with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
                content = f.read()

            return {
                "page_count": 1,
                "pages": [{"page_number": 1, "text": content.strip()}],
                "is_scanned": False,
                "extraction_status": "success",
                "error_message": None
            }
        except Exception as e:
            logger.error(f"TXT extraction error for {file_path}: {e}")
            return {
                "page_count": 0,
                "pages": [],
                "is_scanned": False,
                "extraction_status": "failed",
                "error_message": f"Failed to read TXT file: {str(e)}"
            }

    def create_chunks(self, pages: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Split page texts into manageable chunks while preserving page and heading references."""
        chunks = []
        chunk_idx = 0

        for p in pages:
            page_num = p["page_number"]
            text = p["text"]
            if not text:
                continue

            # Split text by paragraphs or double newlines
            paragraphs = [para.strip() for para in re.split(r'\n\s*\n', text) if para.strip()]
            current_chunk = []
            current_len = 0
            current_heading = None

            for para in paragraphs:
                # Detect heading candidate: short line without ending period
                if len(para) < 100 and not para.endswith(('.', ':', ';', '?')):
                    current_heading = para

                if current_len + len(para) > self.chunk_size and current_chunk:
                    chunk_text = "\n\n".join(current_chunk)
                    chunks.append({
                        "chunk_index": chunk_idx,
                        "content": chunk_text,
                        "page_number": page_num,
                        "heading": current_heading,
                        "char_count": len(chunk_text),
                        "extraction_method": "text_extracted"
                    })
                    chunk_idx += 1
                    current_chunk = [para]
                    current_len = len(para)
                else:
                    current_chunk.append(para)
                    current_len += len(para)

            if current_chunk:
                chunk_text = "\n\n".join(current_chunk)
                chunks.append({
                    "chunk_index": chunk_idx,
                    "content": chunk_text,
                    "page_number": page_num,
                    "heading": current_heading,
                    "char_count": len(chunk_text),
                    "extraction_method": "text_extracted"
                })
                chunk_idx += 1

        return chunks
