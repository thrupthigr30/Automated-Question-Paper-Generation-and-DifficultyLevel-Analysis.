"""Examination Paper Builder and Assembly Engine.
Selects approved questions to satisfy requested marks, duration, topic coverage,
and difficulty distribution (e.g., 30% Easy, 40% Medium, 30% Hard).
Validates paper constraints and structures sections.
"""
import math
import logging
from typing import List, Dict, Any, Optional, Tuple
from sqlalchemy.orm import Session
from app.models import Examination, ExaminationQuestion, Question, Subject, Topic

logger = logging.getLogger(__name__)


class ExaminationBuilder:
    """Assembles and validates balanced examination question papers."""

    def __init__(self, db: Session):
        self.db = db

    def generate_paper(
        self,
        examination_id: int,
        topic_ids: Optional[List[int]] = None,
        unit_ids: Optional[List[int]] = None,
        question_types: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        """Automatically select questions from Question Bank to meet the exam criteria."""
        exam = self.db.query(Examination).filter(Examination.id == examination_id).first()
        if not exam:
            raise ValueError(f"Examination {examination_id} not found.")

        target_marks = exam.total_marks
        easy_pct = exam.easy_percent / 100.0
        med_pct = exam.medium_percent / 100.0
        hard_pct = exam.hard_percent / 100.0

        target_easy_marks = round(target_marks * easy_pct)
        target_med_marks = round(target_marks * med_pct)
        target_hard_marks = target_marks - target_easy_marks - target_med_marks

        # Query pool of candidate approved questions
        query = (
            self.db.query(Question)
            .filter(Question.subject_id == exam.subject_id)
            .filter(Question.approval_status.in_(["approved", "pending"]))
        )

        if topic_ids:
            query = query.filter(Question.topic_id.in_(topic_ids))
        if unit_ids:
            query = query.filter(Question.unit_id.in_(unit_ids))
        if question_types:
            query = query.filter(Question.question_type.in_(question_types))

        all_candidates = query.all()

        easy_pool = [q for q in all_candidates if (q.current_difficulty or q.ai_difficulty_level) == "easy"]
        med_pool = [q for q in all_candidates if (q.current_difficulty or q.ai_difficulty_level) == "medium"]
        hard_pool = [q for q in all_candidates if (q.current_difficulty or q.ai_difficulty_level) == "hard"]

        selected_questions = []
        accumulated_marks = 0

        # Helper to select questions up to target mark quota
        def select_from_pool(pool: List[Question], quota_marks: int) -> List[Question]:
            chosen = []
            cur_marks = 0
            for q in pool:
                if q in selected_questions:
                    continue
                if cur_marks + q.marks <= quota_marks or not chosen:
                    chosen.append(q)
                    cur_marks += q.marks
                if cur_marks >= quota_marks:
                    break
            return chosen

        easy_selected = select_from_pool(easy_pool, target_easy_marks)
        selected_questions.extend(easy_selected)
        accumulated_marks += sum(q.marks for q in easy_selected)

        med_selected = select_from_pool(med_pool, target_med_marks)
        selected_questions.extend(med_selected)
        accumulated_marks += sum(q.marks for q in med_selected)

        hard_selected = select_from_pool(hard_pool, target_hard_marks)
        selected_questions.extend(hard_selected)
        accumulated_marks += sum(q.marks for q in hard_selected)

        # If short on total marks, fill from any remaining candidates
        if accumulated_marks < target_marks:
            for q in all_candidates:
                if q not in selected_questions:
                    selected_questions.append(q)
                    accumulated_marks += q.marks
                    if accumulated_marks >= target_marks:
                        break

        # Remove existing examination questions and re-insert
        self.db.query(ExaminationQuestion).filter(ExaminationQuestion.examination_id == exam.id).delete()

        # Organize into standard sections:
        # Section A: Objective (1-2 marks), Section B: Short (3-5 marks), Section C: Long (6+ marks)
        order = 1
        sections_data = [
            {"name": "Section A — Objective Questions", "instructions": "Answer all questions in this section."},
            {"name": "Section B — Short Answer Questions", "instructions": "Answer with concise explanations."},
            {"name": "Section C — Long / Numerical Problems", "instructions": "Show all derivations and steps clearly."}
        ]

        for q in selected_questions:
            if q.marks <= 2:
                sec = "Section A — Objective Questions"
            elif q.marks <= 5:
                sec = "Section B — Short Answer Questions"
            else:
                sec = "Section C — Long / Numerical Problems"

            eq = ExaminationQuestion(
                examination_id=exam.id,
                question_id=q.id,
                question_order=order,
                section_name=sec,
                marks_override=q.marks
            )
            self.db.add(eq)
            order += 1

        exam.sections = sections_data
        self.db.commit()

        validation = self.validate_paper(exam.id)
        return {
            "examination_id": exam.id,
            "selected_count": len(selected_questions),
            "actual_marks": accumulated_marks,
            "target_marks": target_marks,
            "validation": validation
        }

    def validate_paper(self, examination_id: int) -> Dict[str, Any]:
        """Perform completeness and pedagogical balance checks on assembled paper."""
        exam = self.db.query(Examination).filter(Examination.id == examination_id).first()
        if not exam:
            return {"valid": False, "errors": ["Examination not found."]}

        eqs = (
            self.db.query(ExaminationQuestion)
            .filter(ExaminationQuestion.examination_id == exam.id)
            .order_by(ExaminationQuestion.question_order.asc())
            .all()
        )

        total_actual_marks = sum(eq.marks_override or eq.question.marks for eq in eqs)
        q_count = len(eqs)

        errors = []
        warnings = []

        if q_count == 0:
            errors.append("No questions currently assigned to this examination.")

        if total_actual_marks != exam.total_marks:
            warnings.append(f"Current total marks ({total_actual_marks}) differs from target ({exam.total_marks}).")

        # Calculate actual difficulty distribution
        easy_marks = sum(eq.marks_override or eq.question.marks for eq in eqs if (eq.question.current_difficulty or eq.question.ai_difficulty_level) == "easy")
        med_marks = sum(eq.marks_override or eq.question.marks for eq in eqs if (eq.question.current_difficulty or eq.question.ai_difficulty_level) == "medium")
        hard_marks = sum(eq.marks_override or eq.question.marks for eq in eqs if (eq.question.current_difficulty or eq.question.ai_difficulty_level) == "hard")

        total = max(1, total_actual_marks)
        actual_dist = {
            "easy_percent": round((easy_marks / total) * 100.0, 1),
            "medium_percent": round((med_marks / total) * 100.0, 1),
            "hard_percent": round((hard_marks / total) * 100.0, 1)
        }

        # Check answers availability
        missing_answers = sum(1 for eq in eqs if not eq.question.correct_answer)
        if missing_answers > 0:
            warnings.append(f"{missing_answers} question(s) lack official model answers.")

        is_valid = len(errors) == 0
        return {
            "valid": is_valid,
            "question_count": q_count,
            "total_marks": total_actual_marks,
            "target_marks": exam.total_marks,
            "actual_difficulty_distribution": actual_dist,
            "target_difficulty_distribution": {
                "easy_percent": exam.easy_percent,
                "medium_percent": exam.medium_percent,
                "hard_percent": exam.hard_percent
            },
            "errors": errors,
            "warnings": warnings
        }
