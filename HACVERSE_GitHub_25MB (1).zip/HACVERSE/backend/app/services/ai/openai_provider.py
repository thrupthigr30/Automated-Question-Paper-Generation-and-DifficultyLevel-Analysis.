"""OpenAI provider implementation (also serves as base for OpenAI-compatible providers: Groq, OpenRouter)."""
import json
import logging
from typing import List, Dict, Any, Optional
from app.services.ai.base import BaseAIProvider, AIGeneratedQuestion, AIProviderConnectionStatus
from app.services.ai.prompts import (
    QUESTION_GENERATION_SYSTEM_PROMPT,
    QUESTION_GENERATION_USER_PROMPT,
    DIFFICULTY_ESTIMATION_PROMPT,
    ANSWER_RUBRIC_PROMPT,
)

logger = logging.getLogger(__name__)


class OpenAICompatibleProvider(BaseAIProvider):
    """Generic OpenAI-compatible provider (OpenAI, Groq, OpenRouter)."""

    def __init__(
        self,
        provider_name: str = "openai",
        api_key: str = "",
        model: str = "gpt-4o",
        base_url: Optional[str] = None,
        timeout: int = 90
    ):
        super().__init__(api_key=api_key, model=model, base_url=base_url or "", timeout=timeout)
        self.provider_name = provider_name
        self._client = None

    def _get_client(self):
        if not self._client:
            from openai import AsyncOpenAI
            kwargs = {"api_key": self.api_key or "no-key", "timeout": float(self.timeout)}
            if self.base_url:
                kwargs["base_url"] = self.base_url
            self._client = AsyncOpenAI(**kwargs)
        return self._client

    async def check_connection(self) -> AIProviderConnectionStatus:
        if not self.api_key:
            return AIProviderConnectionStatus(
                provider=self.provider_name,
                model=self.model,
                connected=False,
                message=f"{self.provider_name.capitalize()} API key is missing."
            )
        try:
            client = self._get_client()
            resp = await client.chat.completions.create(
                model=self.model,
                messages=[{"role": "user", "content": "Ping. Respond with OK."}],
                max_tokens=10
            )
            msg = resp.choices[0].message.content or ""
            return AIProviderConnectionStatus(
                provider=self.provider_name,
                model=self.model,
                connected=True,
                message=f"Connected to {self.provider_name} ({self.model}). Response: {msg.strip()}"
            )
        except Exception as e:
            return AIProviderConnectionStatus(
                provider=self.provider_name,
                model=self.model,
                connected=False,
                message=f"{self.provider_name} connection failed: {str(e)}"
            )

    async def generate_questions(
        self,
        subject: str,
        unit: Optional[str],
        topic: Optional[str],
        subtopic: Optional[str],
        content_context: str,
        count: int,
        question_types: List[str],
        marks: int,
        target_difficulty: Optional[str],
        bloom_level: Optional[str],
        instructions: Optional[str] = None,
        existing_questions: Optional[List[str]] = None,
    ) -> List[AIGeneratedQuestion]:
        if not self.api_key:
            raise ValueError(f"{self.provider_name.capitalize()} API key is not configured.")

        client = self._get_client()
        existing_str = "\n".join(f"- {q}" for q in (existing_questions or [])) or "None provided."
        user_prompt = QUESTION_GENERATION_USER_PROMPT.format(
            count=count,
            question_types_str=", ".join(question_types),
            subject=subject,
            unit=unit or "N/A",
            topic=topic or "N/A",
            subtopic=subtopic or "N/A",
            target_difficulty=target_difficulty or "balanced",
            bloom_level=bloom_level or "varied",
            marks=marks,
            instructions=instructions or "Ensure syllabus alignment and clarity.",
            content_context=content_context[:12000] if content_context else "Use standard curriculum knowledge.",
            existing_questions_str=existing_str,
        )

        resp = await client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": QUESTION_GENERATION_SYSTEM_PROMPT},
                {"role": "user", "content": user_prompt}
            ],
            response_format={"type": "json_object"} if "gpt-4" in self.model or "gpt-3.5" in self.model else None,
            temperature=0.3
        )

        raw = resp.choices[0].message.content or "[]"
        clean = raw.strip().removeprefix("```json").removeprefix("```").removesuffix("```").strip()
        data = json.loads(clean)
        if isinstance(data, dict):
            for k in ["questions", "data", "results", "items"]:
                if k in data and isinstance(data[k], list):
                    data = data[k]
                    break
            else:
                data = [data]

        result = []
        for item in data:
            try:
                result.append(AIGeneratedQuestion(**item))
            except Exception as e:
                logger.warning(f"Failed to parse item: {e}")
        return result

    async def estimate_question_difficulty(
        self,
        question_text: str,
        question_type: str,
        marks: int,
        options: Optional[List[Dict[str, str]]] = None,
        correct_answer: Optional[str] = None,
    ) -> Dict[str, Any]:
        if not self.api_key:
            raise ValueError(f"{self.provider_name.capitalize()} API key is not configured.")

        client = self._get_client()
        opt_str = json.dumps(options) if options else "N/A"
        prompt = DIFFICULTY_ESTIMATION_PROMPT.format(
            question_text=question_text,
            question_type=question_type,
            marks=marks,
            options_str=opt_str,
            correct_answer=correct_answer or "N/A"
        )

        resp = await client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": "You are a difficulty calibration expert. Output valid JSON only."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.1
        )
        raw = resp.choices[0].message.content or "{}"
        clean = raw.strip().removeprefix("```json").removeprefix("```").removesuffix("```").strip()
        return json.loads(clean)

    async def generate_answer_and_rubric(
        self,
        question_text: str,
        question_type: str,
        marks: int,
        context: Optional[str] = None,
    ) -> Dict[str, str]:
        if not self.api_key:
            raise ValueError(f"{self.provider_name.capitalize()} API key is not configured.")

        client = self._get_client()
        prompt = ANSWER_RUBRIC_PROMPT.format(
            question_text=question_text,
            question_type=question_type,
            marks=marks,
            context=context or "Standard educational curriculum standards."
        )

        resp = await client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": "Output valid JSON only."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.2
        )
        raw = resp.choices[0].message.content or "{}"
        clean = raw.strip().removeprefix("```json").removeprefix("```").removesuffix("```").strip()
        return json.loads(clean)


class OpenAIProvider(OpenAICompatibleProvider):
    def __init__(self, api_key: str = "", model: str = "gpt-4o", base_url: str = "", timeout: int = 90):
        super().__init__(provider_name="openai", api_key=api_key, model=model or "gpt-4o", base_url=base_url or None, timeout=timeout)


class GroqProvider(OpenAICompatibleProvider):
    def __init__(self, api_key: str = "", model: str = "llama-3.1-70b-versatile", base_url: str = "", timeout: int = 90):
        super().__init__(provider_name="groq", api_key=api_key, model=model or "llama-3.1-70b-versatile", base_url=base_url or "https://api.groq.com/openai/v1", timeout=timeout)


class OpenRouterProvider(OpenAICompatibleProvider):
    def __init__(self, api_key: str = "", model: str = "google/gemini-2.0-flash-001", base_url: str = "", timeout: int = 90):
        super().__init__(provider_name="openrouter", api_key=api_key, model=model or "google/gemini-2.0-flash-001", base_url=base_url or "https://openrouter.ai/api/v1", timeout=timeout)
