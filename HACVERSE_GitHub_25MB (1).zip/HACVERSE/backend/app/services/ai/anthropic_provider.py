"""Anthropic Claude AI Provider implementation."""
import json
import logging
from typing import List, Dict, Any, Optional
from app.services.ai.base import BaseAIProvider, AIGeneratedQuestion, AIProviderConnectionStatus
from app.services.ai.prompts import (
    QUESTION_GENERATION_SYSTEM_PROMPT,
    QUESTION_GENERATION_USER_PROMPT,
    DIFFICULTY_ESTIMATION_PROMPT,
    ANSWER_RUBRIC_PROMPT,
)

logger = logging.getLogger(__name__)


class AnthropicProvider(BaseAIProvider):
    """Anthropic Claude API provider."""

    def __init__(self, api_key: str = "", model: str = "claude-3-5-sonnet-20241022", base_url: str = "", timeout: int = 90):
        super().__init__(api_key=api_key, model=model or "claude-3-5-sonnet-20241022", base_url=base_url, timeout=timeout)
        self._client = None

    def _get_client(self):
        if not self._client:
            from anthropic import AsyncAnthropic
            self._client = AsyncAnthropic(api_key=self.api_key or "no-key", timeout=float(self.timeout))
        return self._client

    async def check_connection(self) -> AIProviderConnectionStatus:
        if not self.api_key:
            return AIProviderConnectionStatus(
                provider="anthropic",
                model=self.model,
                connected=False,
                message="Anthropic API key is missing."
            )
        try:
            client = self._get_client()
            resp = await client.messages.create(
                model=self.model,
                max_tokens=10,
                messages=[{"role": "user", "content": "Ping. Respond with OK."}]
            )
            text = resp.content[0].text if resp.content else ""
            return AIProviderConnectionStatus(
                provider="anthropic",
                model=self.model,
                connected=True,
                message=f"Connected to Anthropic ({self.model}). Response: {text.strip()}"
            )
        except Exception as e:
            return AIProviderConnectionStatus(
                provider="anthropic",
                model=self.model,
                connected=False,
                message=f"Anthropic connection failed: {str(e)}"
            )

    async def generate_questions(
        self,
        subject: str,
        unit: Optional[str],
        topic: Optional[str],
        subtopic: Optional[str],
        content_context: str,
        count: int,
        question_types: List[str],
        marks: int,
        target_difficulty: Optional[str],
        bloom_level: Optional[str],
        instructions: Optional[str] = None,
        existing_questions: Optional[List[str]] = None,
    ) -> List[AIGeneratedQuestion]:
        if not self.api_key:
            raise ValueError("Anthropic API key is not configured.")

        client = self._get_client()
        existing_str = "\n".join(f"- {q}" for q in (existing_questions or [])) or "None provided."
        user_prompt = QUESTION_GENERATION_USER_PROMPT.format(
            count=count,
            question_types_str=", ".join(question_types),
            subject=subject,
            unit=unit or "N/A",
            topic=topic or "N/A",
            subtopic=subtopic or "N/A",
            target_difficulty=target_difficulty or "balanced",
            bloom_level=bloom_level or "varied",
            marks=marks,
            instructions=instructions or "Ensure syllabus alignment and clarity.",
            content_context=content_context[:12000] if content_context else "Use standard curriculum knowledge.",
            existing_questions_str=existing_str,
        )

        resp = await client.messages.create(
            model=self.model,
            max_tokens=4096,
            system=QUESTION_GENERATION_SYSTEM_PROMPT,
            messages=[{"role": "user", "content": user_prompt}]
        )

        raw = resp.content[0].text if resp.content else "[]"
        clean = raw.strip().removeprefix("```json").removeprefix("```").removesuffix("```").strip()
        data = json.loads(clean)
        if isinstance(data, dict):
            for k in ["questions", "data", "results", "items"]:
                if k in data and isinstance(data[k], list):
                    data = data[k]
                    break
            else:
                data = [data]

        result = []
        for item in data:
            try:
                result.append(AIGeneratedQuestion(**item))
            except Exception as e:
                logger.warning(f"Error parsing Anthropic question: {e}")
        return result

    async def estimate_question_difficulty(
        self,
        question_text: str,
        question_type: str,
        marks: int,
        options: Optional[List[Dict[str, str]]] = None,
        correct_answer: Optional[str] = None,
    ) -> Dict[str, Any]:
        if not self.api_key:
            raise ValueError("Anthropic API key is not configured.")

        client = self._get_client()
        opt_str = json.dumps(options) if options else "N/A"
        prompt = DIFFICULTY_ESTIMATION_PROMPT.format(
            question_text=question_text,
            question_type=question_type,
            marks=marks,
            options_str=opt_str,
            correct_answer=correct_answer or "N/A"
        )

        resp = await client.messages.create(
            model=self.model,
            max_tokens=1024,
            messages=[{"role": "user", "content": prompt}]
        )
        raw = resp.content[0].text if resp.content else "{}"
        clean = raw.strip().removeprefix("```json").removeprefix("```").removesuffix("```").strip()
        return json.loads(clean)

    async def generate_answer_and_rubric(
        self,
        question_text: str,
        question_type: str,
        marks: int,
        context: Optional[str] = None,
    ) -> Dict[str, str]:
        if not self.api_key:
            raise ValueError("Anthropic API key is not configured.")

        client = self._get_client()
        prompt = ANSWER_RUBRIC_PROMPT.format(
            question_text=question_text,
            question_type=question_type,
            marks=marks,
            context=context or "Standard educational curriculum standards."
        )

        resp = await client.messages.create(
            model=self.model,
            max_tokens=2048,
            messages=[{"role": "user", "content": prompt}]
        )
        raw = resp.content[0].text if resp.content else "{}"
        clean = raw.strip().removeprefix("```json").removeprefix("```").removesuffix("```").strip()
        return json.loads(clean)
