"""Google Gemini AI Provider implementation using the official `google-genai` SDK."""
import json
import logging
from typing import List, Dict, Any, Optional
from app.services.ai.base import BaseAIProvider, AIGeneratedQuestion, AIProviderConnectionStatus
from app.services.ai.prompts import (
    QUESTION_GENERATION_SYSTEM_PROMPT,
    QUESTION_GENERATION_USER_PROMPT,
    DIFFICULTY_ESTIMATION_PROMPT,
    ANSWER_RUBRIC_PROMPT,
)

logger = logging.getLogger(__name__)


class GeminiAIProvider(BaseAIProvider):
    """Google Gemini AI provider supporting Gemini 2.0 / 1.5 models."""

    def __init__(self, api_key: str = "", model: str = "gemini-2.0-flash", base_url: str = "", timeout: int = 90):
        super().__init__(api_key=api_key, model=model or "gemini-2.0-flash", base_url=base_url, timeout=timeout)
        self._client = None
        if self.api_key:
            try:
                from google import genai
                self._client = genai.Client(api_key=self.api_key)
            except Exception as e:
                logger.error(f"Failed to initialize Gemini Client: {e}")

    async def check_connection(self) -> AIProviderConnectionStatus:
        if not self.api_key:
            return AIProviderConnectionStatus(
                provider="gemini",
                model=self.model,
                connected=False,
                message="Google Gemini API key is missing. Set GEMINI_API_KEY in environment or settings."
            )
        try:
            from google import genai
            client = genai.Client(api_key=self.api_key)
            response = client.models.generate_content(
                model=self.model,
                contents="Ping. Respond with OK."
            )
            text = response.text or ""
            return AIProviderConnectionStatus(
                provider="gemini",
                model=self.model,
                connected=True,
                message=f"Successfully connected to Gemini API ({self.model}). Response: {text[:20].strip()}"
            )
        except Exception as e:
            return AIProviderConnectionStatus(
                provider="gemini",
                model=self.model,
                connected=False,
                message=f"Gemini connection failed: {str(e)}"
            )

    async def generate_questions(
        self,
        subject: str,
        unit: Optional[str],
        topic: Optional[str],
        subtopic: Optional[str],
        content_context: str,
        count: int,
        question_types: List[str],
        marks: int,
        target_difficulty: Optional[str],
        bloom_level: Optional[str],
        instructions: Optional[str] = None,
        existing_questions: Optional[List[str]] = None,
    ) -> List[AIGeneratedQuestion]:
        if not self.api_key:
            raise ValueError("GEMINI_API_KEY is not configured.")

        from google import genai
        client = genai.Client(api_key=self.api_key)

        existing_str = "\n".join(f"- {q}" for q in (existing_questions or [])) or "None provided."
        user_prompt = QUESTION_GENERATION_USER_PROMPT.format(
            count=count,
            question_types_str=", ".join(question_types),
            subject=subject,
            unit=unit or "N/A",
            topic=topic or "N/A",
            subtopic=subtopic or "N/A",
            target_difficulty=target_difficulty or "balanced (easy, medium, hard)",
            bloom_level=bloom_level or "varied",
            marks=marks,
            instructions=instructions or "Ensure syllabus alignment and clarity.",
            content_context=content_context[:12000] if content_context else "Use standard curriculum knowledge for this subject and topic.",
            existing_questions_str=existing_str,
        )

        response = client.models.generate_content(
            model=self.model,
            contents=[
                {"role": "user", "parts": [{"text": QUESTION_GENERATION_SYSTEM_PROMPT + "\n\n" + user_prompt}]}
            ],
            config={
                "response_mime_type": "application/json",
            }
        )

        raw_text = response.text or "[]"
        clean_json = raw_text.strip()
        if clean_json.startswith("```json"):
            clean_json = clean_json[7:]
        if clean_json.startswith("```"):
            clean_json = clean_json[3:]
        if clean_json.endswith("```"):
            clean_json = clean_json[:-3]
        clean_json = clean_json.strip()

        data = json.loads(clean_json)
        if isinstance(data, dict):
            # Sometimes wrapped in {"questions": [...]}
            data = data.get("questions", [data])

        result = []
        for item in data:
            try:
                q = AIGeneratedQuestion(**item)
                result.append(q)
            except Exception as ex:
                logger.warning(f"Error parsing generated question item: {ex}, item: {item}")
        return result

    async def estimate_question_difficulty(
        self,
        question_text: str,
        question_type: str,
        marks: int,
        options: Optional[List[Dict[str, str]]] = None,
        correct_answer: Optional[str] = None,
    ) -> Dict[str, Any]:
        if not self.api_key:
            raise ValueError("GEMINI_API_KEY is not configured.")

        from google import genai
        client = genai.Client(api_key=self.api_key)

        opt_str = json.dumps(options) if options else "N/A"
        prompt = DIFFICULTY_ESTIMATION_PROMPT.format(
            question_text=question_text,
            question_type=question_type,
            marks=marks,
            options_str=opt_str,
            correct_answer=correct_answer or "N/A"
        )

        response = client.models.generate_content(
            model=self.model,
            contents=prompt,
            config={"response_mime_type": "application/json"}
        )

        raw = response.text or "{}"
        return json.loads(raw.strip().removeprefix("```json").removesuffix("```").strip())

    async def generate_answer_and_rubric(
        self,
        question_text: str,
        question_type: str,
        marks: int,
        context: Optional[str] = None,
    ) -> Dict[str, str]:
        if not self.api_key:
            raise ValueError("GEMINI_API_KEY is not configured.")

        from google import genai
        client = genai.Client(api_key=self.api_key)

        prompt = ANSWER_RUBRIC_PROMPT.format(
            question_text=question_text,
            question_type=question_type,
            marks=marks,
            context=context or "General curriculum standards."
        )

        response = client.models.generate_content(
            model=self.model,
            contents=prompt,
            config={"response_mime_type": "application/json"}
        )

        raw = response.text or "{}"
        return json.loads(raw.strip().removeprefix("```json").removesuffix("```").strip())
