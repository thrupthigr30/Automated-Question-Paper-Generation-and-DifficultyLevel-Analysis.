"""Standardized prompt templates for academic question generation, difficulty estimation,
Bloom's Taxonomy classification, and solution/rubric generation.
"""

QUESTION_GENERATION_SYSTEM_PROMPT = """You are an expert academic curriculum and assessment specialist.
Your task is to generate high-quality, syllabus-aligned examination questions based on the provided academic content.

Follow these strict pedagogical rules:
1. Ground the questions strictly in the provided content context whenever available.
2. Formulate clear, unambiguous, and pedagogically sound questions.
3. Every question must be classified along 6 cognitive difficulty dimensions (rated 1.0 to 5.0):
   - cognitive_demand: Mental workload and abstract thinking required.
   - reasoning_complexity: Multi-step inference, deduction, or problem solving.
   - procedural_complexity: Calculations, algorithms, or sequence of operational steps.
   - prerequisite_breadth: Foundational knowledge across domains needed.
   - application_complexity: Translating concepts to novel or realistic scenarios.
   - solution_depth: Extent and granularity of explanation/derivation needed.
4. Calculate a composite difficulty score (0 to 100) and difficulty level:
   - score >= 70: hard
   - score >= 40 and < 70: medium
   - score < 40: easy
5. Assign appropriate Bloom's Taxonomy level: remember, understand, apply, analyze, evaluate, create.
6. Provide complete solutions, correct answers, step-by-step explanations, and clear marking rubrics.
7. Return strictly valid JSON adhering to the specified schema without Markdown fences or conversational text.
"""

QUESTION_GENERATION_USER_PROMPT = """Generate {count} {question_types_str} question(s) for the following academic context:

Subject: {subject}
Unit: {unit}
Topic: {topic}
Subtopic: {subtopic}
Target Difficulty: {target_difficulty}
Target Bloom Level: {bloom_level}
Marks per question: {marks}
Additional Instructions: {instructions}

Source Content Context:
\"\"\"
{content_context}
\"\"\"

Existing Questions to Avoid Duplicating:
{existing_questions_str}

Return a JSON array of objects with the following schema:
[
  {{
    "question_text": "Detailed question prompt",
    "question_type": "mcq | short_answer | long_answer | numerical | application | conceptual | case_study | assertion_reasoning | fill_blank | true_false",
    "marks": {marks},
    "options": [ {{"label": "A", "text": "..."}}, {{"label": "B", "text": "..."}}, {{"label": "C", "text": "..."}}, {{"label": "D", "text": "..."}} ], // only for MCQ
    "correct_answer": "Option letter for MCQ or model answer text",
    "explanation": "Comprehensive solution or rationale",
    "answer_rubric": "Step-by-step marking breakdown and point allocation",
    "bloom_level": "remember | understand | apply | analyze | evaluate | create",
    "cognitive_demand": 1.0 to 5.0,
    "reasoning_complexity": 1.0 to 5.0,
    "procedural_complexity": 1.0 to 5.0,
    "prerequisite_breadth": 1.0 to 5.0,
    "application_complexity": 1.0 to 5.0,
    "solution_depth": 1.0 to 5.0,
    "ai_difficulty_score": 0.0 to 100.0,
    "ai_difficulty_level": "easy | medium | hard",
    "difficulty_reason": "Justification detailing which features make this question easy, medium, or hard",
    "source_reference": "Citation or excerpt from source context"
  }}
]
"""

DIFFICULTY_ESTIMATION_PROMPT = """Analyze the educational difficulty of the following examination question.

Question: {question_text}
Question Type: {question_type}
Marks: {marks}
Options: {options_str}
Correct Answer: {correct_answer}

Rate each of the 6 dimensions from 1.0 (very low) to 5.0 (very high):
1. cognitive_demand (1.0 - 5.0)
2. reasoning_complexity (1.0 - 5.0)
3. procedural_complexity (1.0 - 5.0)
4. prerequisite_breadth (1.0 - 5.0)
5. application_complexity (1.0 - 5.0)
6. solution_depth (1.0 - 5.0)

Compute composite difficulty score (0-100) and difficulty level (easy: <40, medium: 40-69, hard: >=70).
Determine Bloom's Taxonomy level: remember, understand, apply, analyze, evaluate, create.

Return strictly valid JSON:
{{
  "cognitive_demand": 3.0,
  "reasoning_complexity": 3.5,
  "procedural_complexity": 2.0,
  "prerequisite_breadth": 2.5,
  "application_complexity": 3.0,
  "solution_depth": 3.0,
  "ai_difficulty_score": 58.0,
  "ai_difficulty_level": "medium",
  "bloom_level": "apply",
  "difficulty_reason": "Detailed educational rationale for this calibration"
}}
"""

ANSWER_RUBRIC_PROMPT = """Generate an official model answer, detailed step-by-step explanation, and structured marking rubric for the following question.

Question: {question_text}
Question Type: {question_type}
Marks: {marks}
Academic Context:
\"\"\"
{context}
\"\"\"

Return strictly valid JSON:
{{
  "correct_answer": "Complete, precise model answer",
  "explanation": "Detailed pedagogical explanation and step-by-step breakdown",
  "answer_rubric": "Point allocation rubric (e.g., 1 mark for formula, 2 marks for substitution, 1 mark for correct unit)",
  "verification_status": "ai_generated_review"
}}
"""
