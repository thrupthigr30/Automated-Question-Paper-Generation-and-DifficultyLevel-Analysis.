"""Factory for instantiating the active AI Provider based on settings or explicit parameters."""
import logging
from typing import Optional
from app.core.config import settings
from app.services.ai.base import BaseAIProvider
from app.services.ai.gemini_provider import GeminiAIProvider
from app.services.ai.openai_provider import OpenAIProvider, GroqProvider, OpenRouterProvider
from app.services.ai.anthropic_provider import AnthropicProvider
from app.services.ai.ollama_provider import OllamaProvider

logger = logging.getLogger(__name__)


def get_ai_provider(
    provider_name: Optional[str] = None,
    api_key: Optional[str] = None,
    model: Optional[str] = None,
    base_url: Optional[str] = None,
    timeout: Optional[int] = None
) -> BaseAIProvider:
    """Return a configured instance of the requested AI Provider."""
    name = (provider_name or settings.AI_PROVIDER).lower().strip()
    timeout = timeout or settings.AI_TIMEOUT_SECONDS

    if name == "gemini":
        key = api_key or settings.GEMINI_API_KEY or settings.AI_API_KEY
        m = model or settings.GEMINI_MODEL or settings.AI_MODEL or "gemini-2.0-flash"
        return GeminiAIProvider(api_key=key, model=m, timeout=timeout)

    elif name == "openai":
        key = api_key or settings.OPENAI_API_KEY or settings.AI_API_KEY
        m = model or settings.OPENAI_MODEL or settings.AI_MODEL or "gpt-4o"
        url = base_url or settings.AI_BASE_URL
        return OpenAIProvider(api_key=key, model=m, base_url=url, timeout=timeout)

    elif name == "anthropic":
        key = api_key or settings.ANTHROPIC_API_KEY or settings.AI_API_KEY
        m = model or settings.ANTHROPIC_MODEL or settings.AI_MODEL or "claude-3-5-sonnet-20241022"
        return AnthropicProvider(api_key=key, model=m, timeout=timeout)

    elif name == "groq":
        key = api_key or settings.GROQ_API_KEY or settings.AI_API_KEY
        m = model or settings.GROQ_MODEL or settings.AI_MODEL or "llama-3.1-70b-versatile"
        url = base_url or "https://api.groq.com/openai/v1"
        return GroqProvider(api_key=key, model=m, base_url=url, timeout=timeout)

    elif name == "openrouter":
        key = api_key or settings.OPENROUTER_API_KEY or settings.AI_API_KEY
        m = model or settings.OPENROUTER_MODEL or settings.AI_MODEL or "google/gemini-2.0-flash-001"
        url = base_url or settings.OPENROUTER_BASE_URL or "https://openrouter.ai/api/v1"
        return OpenRouterProvider(api_key=key, model=m, base_url=url, timeout=timeout)

    elif name == "ollama":
        m = model or settings.OLLAMA_MODEL or settings.AI_MODEL or "llama3.1"
        url = base_url or settings.OLLAMA_BASE_URL or "http://localhost:11434"
        return OllamaProvider(model=m, base_url=url, timeout=timeout)

    else:
        logger.warning(f"Unknown AI Provider '{name}', defaulting to Gemini")
        key = api_key or settings.GEMINI_API_KEY or settings.AI_API_KEY
        m = model or settings.GEMINI_MODEL or "gemini-2.0-flash"
        return GeminiAIProvider(api_key=key, model=m, timeout=timeout)
