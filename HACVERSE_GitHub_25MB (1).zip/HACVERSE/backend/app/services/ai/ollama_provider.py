"""Ollama Local AI Provider implementation using HTTP client."""
import json
import logging
from typing import List, Dict, Any, Optional
import httpx
from app.services.ai.base import BaseAIProvider, AIGeneratedQuestion, AIProviderConnectionStatus
from app.services.ai.prompts import (
    QUESTION_GENERATION_SYSTEM_PROMPT,
    QUESTION_GENERATION_USER_PROMPT,
    DIFFICULTY_ESTIMATION_PROMPT,
    ANSWER_RUBRIC_PROMPT,
)

logger = logging.getLogger(__name__)


class OllamaProvider(BaseAIProvider):
    """Local Ollama instance integration."""

    def __init__(self, api_key: str = "", model: str = "llama3.1", base_url: str = "http://localhost:11434", timeout: int = 90):
        super().__init__(api_key=api_key, model=model or "llama3.1", base_url=base_url or "http://localhost:11434", timeout=timeout)

    async def check_connection(self) -> AIProviderConnectionStatus:
        try:
            async with httpx.AsyncClient(timeout=5.0) as client:
                res = await client.get(f"{self.base_url.rstrip('/')}/api/tags")
                if res.status_code == 200:
                    models_data = res.json().get("models", [])
                    model_names = [m.get("name") for m in models_data]
                    return AIProviderConnectionStatus(
                        provider="ollama",
                        model=self.model,
                        connected=True,
                        message=f"Connected to local Ollama at {self.base_url}. Found {len(model_names)} model(s).",
                        available_models=model_names
                    )
                else:
                    return AIProviderConnectionStatus(
                        provider="ollama",
                        model=self.model,
                        connected=False,
                        message=f"Ollama returned HTTP {res.status_code}"
                    )
        except Exception as e:
            return AIProviderConnectionStatus(
                provider="ollama",
                model=self.model,
                connected=False,
                message=f"Cannot reach Ollama at {self.base_url}: {str(e)}"
            )

    async def _generate(self, prompt: str, system: Optional[str] = None) -> str:
        url = f"{self.base_url.rstrip('/')}/api/generate"
        payload = {
            "model": self.model,
            "prompt": prompt,
            "system": system or "",
            "stream": False,
            "format": "json"
        }
        async with httpx.AsyncClient(timeout=float(self.timeout)) as client:
            resp = await client.post(url, json=payload)
            resp.raise_for_status()
            data = resp.json()
            return data.get("response", "{}")

    async def generate_questions(
        self,
        subject: str,
        unit: Optional[str],
        topic: Optional[str],
        subtopic: Optional[str],
        content_context: str,
        count: int,
        question_types: List[str],
        marks: int,
        target_difficulty: Optional[str],
        bloom_level: Optional[str],
        instructions: Optional[str] = None,
        existing_questions: Optional[List[str]] = None,
    ) -> List[AIGeneratedQuestion]:
        existing_str = "\n".join(f"- {q}" for q in (existing_questions or [])) or "None provided."
        user_prompt = QUESTION_GENERATION_USER_PROMPT.format(
            count=count,
            question_types_str=", ".join(question_types),
            subject=subject,
            unit=unit or "N/A",
            topic=topic or "N/A",
            subtopic=subtopic or "N/A",
            target_difficulty=target_difficulty or "balanced",
            bloom_level=bloom_level or "varied",
            marks=marks,
            instructions=instructions or "Ensure syllabus alignment and clarity.",
            content_context=content_context[:10000] if content_context else "Use standard curriculum knowledge.",
            existing_questions_str=existing_str,
        )

        raw = await self._generate(prompt=user_prompt, system=QUESTION_GENERATION_SYSTEM_PROMPT)
        clean = raw.strip().removeprefix("```json").removeprefix("```").removesuffix("```").strip()
        data = json.loads(clean)
        if isinstance(data, dict):
            for k in ["questions", "data", "results", "items"]:
                if k in data and isinstance(data[k], list):
                    data = data[k]
                    break
            else:
                data = [data]

        result = []
        for item in data:
            try:
                result.append(AIGeneratedQuestion(**item))
            except Exception as e:
                logger.warning(f"Error parsing Ollama question: {e}")
        return result

    async def estimate_question_difficulty(
        self,
        question_text: str,
        question_type: str,
        marks: int,
        options: Optional[List[Dict[str, str]]] = None,
        correct_answer: Optional[str] = None,
    ) -> Dict[str, Any]:
        opt_str = json.dumps(options) if options else "N/A"
        prompt = DIFFICULTY_ESTIMATION_PROMPT.format(
            question_text=question_text,
            question_type=question_type,
            marks=marks,
            options_str=opt_str,
            correct_answer=correct_answer or "N/A"
        )
        raw = await self._generate(prompt=prompt, system="Output valid JSON only.")
        clean = raw.strip().removeprefix("```json").removeprefix("```").removesuffix("```").strip()
        return json.loads(clean)

    async def generate_answer_and_rubric(
        self,
        question_text: str,
        question_type: str,
        marks: int,
        context: Optional[str] = None,
    ) -> Dict[str, str]:
        prompt = ANSWER_RUBRIC_PROMPT.format(
            question_text=question_text,
            question_type=question_type,
            marks=marks,
            context=context or "Standard educational curriculum standards."
        )
        raw = await self._generate(prompt=prompt, system="Output valid JSON only.")
        clean = raw.strip().removeprefix("```json").removeprefix("```").removesuffix("```").strip()
        return json.loads(clean)
