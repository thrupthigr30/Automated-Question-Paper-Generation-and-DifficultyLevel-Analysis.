"""Abstract base class and schemas for AI Provider integration.
Supports: Gemini, OpenAI, Claude, Groq, OpenRouter, and Ollama.
"""
from abc import ABC, abstractmethod
from typing import List, Dict, Any, Optional
from pydantic import BaseModel, Field


class AIGeneratedQuestion(BaseModel):
    question_text: str = Field(..., description="The full, unambiguous question text")
    question_type: str = Field(..., description="mcq, short_answer, long_answer, numerical, application, conceptual, case_study, assertion_reasoning, fill_blank, true_false")
    marks: int = Field(default=1, ge=1)
    options: Optional[List[Dict[str, str]]] = Field(None, description="For MCQs: [{'label': 'A', 'text': '...'}, ...]")
    correct_answer: Optional[str] = Field(None, description="Official or model answer")
    explanation: Optional[str] = Field(None, description="Detailed explanation or step-by-step reasoning")
    answer_rubric: Optional[str] = Field(None, description="Marking rubric for descriptive/numerical evaluation")
    bloom_level: str = Field(default="understand", description="remember, understand, apply, analyze, evaluate, create")
    
    # Cognitive / Difficulty features (1.0 to 5.0)
    cognitive_demand: float = Field(default=2.5, ge=1.0, le=5.0)
    reasoning_complexity: float = Field(default=2.5, ge=1.0, le=5.0)
    procedural_complexity: float = Field(default=2.5, ge=1.0, le=5.0)
    prerequisite_breadth: float = Field(default=2.5, ge=1.0, le=5.0)
    application_complexity: float = Field(default=2.5, ge=1.0, le=5.0)
    solution_depth: float = Field(default=2.5, ge=1.0, le=5.0)
    
    ai_difficulty_level: str = Field(default="medium", description="easy, medium, hard")
    ai_difficulty_score: float = Field(default=50.0, ge=0.0, le=100.0)
    difficulty_reason: str = Field(default="", description="Justification for estimated difficulty")
    source_reference: Optional[str] = Field(None, description="Citations to provided source material")


class AIProviderConnectionStatus(BaseModel):
    provider: str
    model: str
    connected: bool
    message: str
    available_models: Optional[List[str]] = None


class BaseAIProvider(ABC):
    """Unified interface for all AI LLM providers."""

    def __init__(self, api_key: str = "", model: str = "", base_url: str = "", timeout: int = 90):
        self.api_key = api_key
        self.model = model
        self.base_url = base_url
        self.timeout = timeout

    @abstractmethod
    async def check_connection(self) -> AIProviderConnectionStatus:
        """Verify API connectivity and model accessibility."""
        pass

    @abstractmethod
    async def generate_questions(
        self,
        subject: str,
        unit: Optional[str],
        topic: Optional[str],
        subtopic: Optional[str],
        content_context: str,
        count: int,
        question_types: List[str],
        marks: int,
        target_difficulty: Optional[str],
        bloom_level: Optional[str],
        instructions: Optional[str] = None,
        existing_questions: Optional[List[str]] = None,
    ) -> List[AIGeneratedQuestion]:
        """Generate structured questions grounded in academic content context."""
        pass

    @abstractmethod
    async def estimate_question_difficulty(
        self,
        question_text: str,
        question_type: str,
        marks: int,
        options: Optional[List[Dict[str, str]]] = None,
        correct_answer: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Estimate 6 difficulty dimensions, overall score, level, and reasoning."""
        pass

    @abstractmethod
    async def generate_answer_and_rubric(
        self,
        question_text: str,
        question_type: str,
        marks: int,
        context: Optional[str] = None,
    ) -> Dict[str, str]:
        """Generate accurate answer, step-by-step solution, and marking rubric."""
        pass
