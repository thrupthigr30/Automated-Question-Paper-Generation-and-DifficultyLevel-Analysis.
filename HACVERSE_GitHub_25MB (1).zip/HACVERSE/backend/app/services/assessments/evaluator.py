"""Student Assessment and Response Auto-Evaluation Engine.
Automatically evaluates objective questions (MCQ, True/False, Fill in Blank, Numerical with tolerance).
Preserves descriptive responses for manual teacher grading with rubrics.
"""
import re
import math
import logging
from typing import Dict, Any, Optional
from app.models import Question, StudentResponse

logger = logging.getLogger(__name__)


class AssessmentEvaluator:
    """Evaluates student responses against official question keys and rubrics."""

    @classmethod
    def evaluate_response(cls, question: Question, submitted_answer: str) -> Dict[str, Any]:
        """Evaluate a single question response.
        Returns dict with:
            - is_correct: bool or None
            - marks_earned: float or None
            - evaluation_status: "auto_evaluated" | "pending"
            - notes: str
        """
        if not submitted_answer or not submitted_answer.strip():
            return {
                "is_correct": False,
                "marks_earned": 0.0,
                "evaluation_status": "auto_evaluated",
                "notes": "Unanswered"
            }

        q_type = (question.question_type or "").lower()
        max_marks = float(question.marks or 1)
        clean_sub = submitted_answer.strip()
        correct_key = (question.correct_answer or "").strip()

        # 1. Multiple Choice Questions
        if q_type in ["mcq", "assertion_reasoning"]:
            is_correct = cls._check_mcq(clean_sub, correct_key, question.options)
            return {
                "is_correct": is_correct,
                "marks_earned": max_marks if is_correct else 0.0,
                "evaluation_status": "auto_evaluated",
                "notes": "Automated MCQ key match"
            }

        # 2. True / False
        elif q_type == "true_false":
            is_correct = cls._check_boolean(clean_sub, correct_key)
            return {
                "is_correct": is_correct,
                "marks_earned": max_marks if is_correct else 0.0,
                "evaluation_status": "auto_evaluated",
                "notes": "Automated True/False match"
            }

        # 3. Fill in the Blank
        elif q_type == "fill_blank":
            is_correct = cls._check_text_match(clean_sub, correct_key)
            return {
                "is_correct": is_correct,
                "marks_earned": max_marks if is_correct else 0.0,
                "evaluation_status": "auto_evaluated",
                "notes": "Exact/normalized text match"
            }

        # 4. Numerical with tolerance (2% default)
        elif q_type == "numerical":
            is_correct, notes = cls._check_numerical(clean_sub, correct_key, tolerance_percent=2.5)
            return {
                "is_correct": is_correct,
                "marks_earned": max_marks if is_correct else 0.0,
                "evaluation_status": "auto_evaluated",
                "notes": notes
            }

        # 5. Descriptive / Subjective (Short/Long Answer, Case Study, Conceptual)
        else:
            return {
                "is_correct": None,
                "marks_earned": None,
                "evaluation_status": "pending",
                "notes": "Awaiting teacher manual grading against rubric"
            }

    @classmethod
    def _check_mcq(cls, submitted: str, correct: str, options: Any) -> bool:
        # Match option label directly, e.g. "A" == "A"
        if submitted.lower() == correct.lower():
            return True
        # If student submitted option text instead of letter, or vice versa
        if isinstance(options, list):
            for opt in options:
                if isinstance(opt, dict):
                    lbl = opt.get("label", "").lower()
                    txt = opt.get("text", "").lower()
                    if (submitted.lower() == lbl and correct.lower() == txt) or (submitted.lower() == txt and correct.lower() == lbl):
                        return True
        return False

    @classmethod
    def _check_boolean(cls, submitted: str, correct: str) -> bool:
        norm_s = submitted.lower().strip()
        norm_c = correct.lower().strip()
        true_vals = {"true", "t", "yes", "y", "1"}
        false_vals = {"false", "f", "no", "n", "0"}
        if norm_s in true_vals and norm_c in true_vals:
            return True
        if norm_s in false_vals and norm_c in false_vals:
            return True
        return False

    @classmethod
    def _check_text_match(cls, submitted: str, correct: str) -> bool:
        def norm(t):
            return re.sub(r'[^\w\s]', '', t.lower()).strip()
        return norm(submitted) == norm(correct)

    @classmethod
    def _check_numerical(cls, submitted: str, correct: str, tolerance_percent: float = 2.5) -> tuple[bool, str]:
        try:
            # Extract first float number found
            s_num = float(re.findall(r"[-+]?\d*\.?\d+", submitted)[0])
            c_num = float(re.findall(r"[-+]?\d*\.?\d+", correct)[0])

            diff = abs(s_num - c_num)
            allowed_diff = max(0.01, abs(c_num) * (tolerance_percent / 100.0))

            if diff <= allowed_diff:
                return True, f"Numerical value within {tolerance_percent}% tolerance."
            else:
                return False, f"Expected {c_num}, submitted {s_num}."
        except Exception:
            # Fallback to direct string comparison
            match = submitted.strip().lower() == correct.strip().lower()
            return match, "Text match fallback for numerical."
