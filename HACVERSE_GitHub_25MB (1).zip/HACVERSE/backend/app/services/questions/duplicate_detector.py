"""Question duplicate detection engine.
Supports exact matching, normalized text matching, and fuzzy matching (via RapidFuzz).
Distinguishes exact duplicates from conceptually related questions.
"""
import re
from typing import List, Dict, Any, Optional, Tuple
from rapidfuzz import fuzz


class DuplicateDetector:
    """Detects near-duplicate or semantically similar questions."""

    def __init__(self, exact_threshold: float = 98.0, near_threshold: float = 85.0, concept_threshold: float = 70.0):
        self.exact_threshold = exact_threshold
        self.near_threshold = near_threshold
        self.concept_threshold = concept_threshold

    def normalize(self, text: str) -> str:
        """Strip punctuation, excessive whitespaces, and convert to lower case."""
        t = re.sub(r'[^\w\s]', '', text.lower())
        return " ".join(t.split())

    def check_duplicate(
        self,
        candidate_text: str,
        existing_questions: List[Tuple[int, str]]  # list of (question_id, question_text)
    ) -> List[Dict[str, Any]]:
        """Compare candidate question text against existing question list.
        Returns list of matching flags.
        """
        norm_cand = self.normalize(candidate_text)
        matches = []

        for q_id, q_text in existing_questions:
            if not q_text:
                continue

            # 1. Exact match
            if candidate_text.strip().lower() == q_text.strip().lower():
                matches.append({
                    "existing_question_id": q_id,
                    "existing_text": q_text,
                    "similarity_score": 100.0,
                    "category": "exact_duplicate",
                    "reason": "Exact identical text"
                })
                continue

            norm_existing = self.normalize(q_text)
            if norm_cand == norm_existing:
                matches.append({
                    "existing_question_id": q_id,
                    "existing_text": q_text,
                    "similarity_score": 99.0,
                    "category": "exact_duplicate",
                    "reason": "Normalized identical text ignoring punctuation and case"
                })
                continue

            # 2. Fuzzy token sort ratio
            ratio = fuzz.token_sort_ratio(norm_cand, norm_existing)
            if ratio >= self.near_threshold:
                matches.append({
                    "existing_question_id": q_id,
                    "existing_text": q_text,
                    "similarity_score": round(float(ratio), 2),
                    "category": "near_identical",
                    "reason": f"High fuzzy similarity ({ratio:.1f}%)"
                })
            elif ratio >= self.concept_threshold:
                matches.append({
                    "existing_question_id": q_id,
                    "existing_text": q_text,
                    "similarity_score": round(float(ratio), 2),
                    "category": "conceptually_related",
                    "reason": f"Shared concept vocabulary ({ratio:.1f}%)"
                })

        return sorted(matches, key=lambda x: x["similarity_score"], reverse=True)
