"""Orchestrator for AI-powered question generation grounded in academic content.
Handles context retrieval, AI invocation, schema validation, duplicate checking,
initial difficulty estimation, and database persistence.
"""
import logging
from typing import List, Dict, Any, Optional
from datetime import datetime, timezone
from sqlalchemy.orm import Session
from sqlalchemy import func

from app.models import (
    Question, QuestionGenerationRun, QuestionSource, DifficultyAssessment,
    Subject, Unit, Topic, Subtopic, DocumentChunk
)
from app.services.ai.factory import get_ai_provider
from app.services.retrieval.engine import RetrievalEngine
from app.services.questions.duplicate_detector import DuplicateDetector
from app.services.difficulty.estimator import DifficultyEstimator

logger = logging.getLogger(__name__)


class QuestionGenerator:
    """Coordinates the full question generation workflow."""

    def __init__(self, db: Session):
        self.db = db
        self.retrieval = RetrievalEngine(db)
        self.detector = DuplicateDetector()

    async def generate_and_save(
        self,
        subject_id: int,
        unit_id: Optional[int],
        topic_id: Optional[int],
        subtopic_id: Optional[int],
        document_ids: Optional[List[int]],
        count: int,
        question_types: List[str],
        marks: int,
        target_difficulty: Optional[str],
        bloom_level: Optional[str],
        generation_mode: str,
        additional_instructions: Optional[str],
        user_id: int,
        ai_provider_name: Optional[str] = None
    ) -> QuestionGenerationRun:
        """Execute question generation request and save resulting questions to database."""
        # Retrieve subject and metadata
        subject = self.db.query(Subject).filter(Subject.id == subject_id).first()
        if not subject:
            raise ValueError(f"Subject with ID {subject_id} not found.")

        unit_name = None
        if unit_id:
            u = self.db.query(Unit).filter(Unit.id == unit_id).first()
            unit_name = u.name if u else None

        topic_name = None
        if topic_id:
            t = self.db.query(Topic).filter(Topic.id == topic_id).first()
            topic_name = t.name if t else None

        subtopic_name = None
        if subtopic_id:
            st = self.db.query(Subtopic).filter(Subtopic.id == subtopic_id).first()
            subtopic_name = st.name if st else None

        # 1. Retrieve academic content context
        chunks = self.retrieval.retrieve_context(
            subject_id=subject_id,
            topic_id=topic_id,
            document_ids=document_ids,
            query=topic_name or subject.name,
            top_k=6
        )
        context_text = "\n\n---\n\n".join(
            f"[Source: {c['document_name']}, Page: {c['page_number'] or 'N/A'}]\n{c['content']}"
            for c in chunks
        )

        # 2. Fetch existing question texts to avoid duplicate generation
        existing_qs = (
            self.db.query(Question.id, Question.question_text)
            .filter(Question.subject_id == subject_id)
            .limit(100)
            .all()
        )
        existing_texts = [q[1] for q in existing_qs]

        # 3. Create Generation Run record
        provider = get_ai_provider(provider_name=ai_provider_name)
        run = QuestionGenerationRun(
            subject_id=subject_id,
            unit_id=unit_id,
            topic_id=topic_id,
            requested_count=count,
            question_types=question_types,
            difficulty_requested=target_difficulty,
            bloom_level_requested=bloom_level,
            marks=marks,
            generation_mode=generation_mode,
            ai_provider=provider.__class__.__name__,
            ai_model=provider.model,
            prompt_version="v1.0",
            status="processing",
            additional_instructions=additional_instructions,
            created_by=user_id
        )
        self.db.add(run)
        self.db.flush()

        try:
            # 4. Invoke AI Provider
            generated_list = await provider.generate_questions(
                subject=subject.name,
                unit=unit_name,
                topic=topic_name,
                subtopic=subtopic_name,
                content_context=context_text,
                count=count,
                question_types=question_types,
                marks=marks,
                target_difficulty=target_difficulty,
                bloom_level=bloom_level,
                instructions=additional_instructions,
                existing_questions=existing_texts[:20]
            )

            saved_questions = []
            duplicate_tuples = [(q.id, q.question_text) for q in existing_qs]

            for item in generated_list:
                # 5. Duplicate Check
                dup_matches = self.detector.check_duplicate(item.question_text, duplicate_tuples)
                is_exact_dup = any(m["category"] == "exact_duplicate" for m in dup_matches)
                if is_exact_dup:
                    logger.info(f"Skipping exact duplicate question: {item.question_text[:50]}...")
                    continue

                # 6. Calculate initial difficulty features & composite score
                features = {
                    "cognitive_demand": item.cognitive_demand,
                    "reasoning_complexity": item.reasoning_complexity,
                    "procedural_complexity": item.procedural_complexity,
                    "prerequisite_breadth": item.prerequisite_breadth,
                    "application_complexity": item.application_complexity,
                    "solution_depth": item.solution_depth,
                }
                composite_score = DifficultyEstimator.calculate_composite_score(features)
                difficulty_level = DifficultyEstimator.classify_difficulty(composite_score)

                # Determine primary source reference from chunks if available
                first_chunk = chunks[0] if chunks else None

                q = Question(
                    question_text=item.question_text,
                    subject_id=subject_id,
                    unit_id=unit_id,
                    topic_id=topic_id,
                    subtopic_id=subtopic_id,
                    question_type=item.question_type,
                    marks=item.marks or marks,
                    options=item.options,
                    correct_answer=item.correct_answer,
                    explanation=item.explanation,
                    answer_rubric=item.answer_rubric,
                    answer_status="ai_generated_review",
                    ai_difficulty_level=difficulty_level,
                    ai_difficulty_score=composite_score,
                    difficulty_reason=item.difficulty_reason or f"AI-estimated difficulty with composite score {composite_score}/100.",
                    bloom_level=item.bloom_level or bloom_level or "understand",
                    cognitive_characteristics=features,
                    current_difficulty=difficulty_level,
                    evidence_status="ai_estimated",
                    valid_attempt_count=0,
                    source_document_id=first_chunk["document_id"] if first_chunk else None,
                    source_page=first_chunk["page_number"] if first_chunk else None,
                    generation_run_id=run.id,
                    generation_model=provider.model,
                    prompt_version="v1.0",
                    approval_status="pending",
                    data_origin="ai_generated",
                    created_by=user_id
                )
                self.db.add(q)
                self.db.flush()

                # Add Source linkage
                if first_chunk:
                    src = QuestionSource(
                        question_id=q.id,
                        document_id=first_chunk["document_id"],
                        page_number=first_chunk["page_number"],
                        chunk_id=first_chunk["chunk_id"],
                        source_type="academic_text",
                        relevance_score=1.0
                    )
                    self.db.add(src)

                # Add initial DifficultyAssessment record
                assess = DifficultyAssessment(
                    question_id=q.id,
                    assessment_type="ai_initial",
                    difficulty_level=difficulty_level,
                    difficulty_score=composite_score,
                    cognitive_demand=features["cognitive_demand"],
                    reasoning_complexity=features["reasoning_complexity"],
                    procedural_complexity=features["procedural_complexity"],
                    prerequisite_breadth=features["prerequisite_breadth"],
                    application_complexity=features["application_complexity"],
                    solution_depth=features["solution_depth"],
                    bloom_level=q.bloom_level,
                    reasoning=q.difficulty_reason,
                    model_id=provider.model,
                    rubric_version="v1.0"
                )
                self.db.add(assess)

                saved_questions.append(q)
                duplicate_tuples.append((q.id, q.question_text))

            run.generated_count = len(generated_list)
            run.accepted_count = len(saved_questions)
            run.rejected_count = run.generated_count - run.accepted_count
            run.status = "completed"
            run.completed_at = datetime.now(timezone.utc)
            self.db.commit()
            return run

        except Exception as e:
            logger.error(f"Question generation failed: {e}")
            run.status = "failed"
            run.error_message = str(e)
            run.completed_at = datetime.now(timezone.utc)
            self.db.commit()
            raise e
