"""Previous-Year Question (PYQ) Analysis Engine.
Extracts questions from historical exam documents, detects exact and near repetitions,
computes topic frequency distribution, and maps questions to syllabus units/topics.
Fully optional: System operates normally even if no PYQ documents are present.
"""
import re
import logging
from typing import List, Dict, Any, Optional
from sqlalchemy.orm import Session
from rapidfuzz import fuzz

from app.models import PYQPaper, PYQQuestion, PYQTopicMapping, Document, Topic

logger = logging.getLogger(__name__)


class PYQAnalyzer:
    """Extracts, maps, and analyzes historical examination papers."""

    def __init__(self, db: Session):
        self.db = db

    def extract_and_analyze_paper(self, document_id: int, subject_id: int, exam_year: Optional[int] = None, exam_name: Optional[str] = None) -> PYQPaper:
        """Parse questions from a PYQ document and compute repetition and topic mappings."""
        doc = self.db.query(Document).filter(Document.id == document_id).first()
        if not doc:
            raise ValueError(f"Document {document_id} not found.")

        # Read document text from chunks or file
        chunks = doc.chunks
        full_text = "\n\n".join(c.content for c in chunks) if chunks else ""

        # Parse question blocks using regex patterns common in exam papers
        # e.g., "Q1.", "1.", "Question 1:", "(a)", etc.
        raw_blocks = self._parse_question_blocks(full_text)

        paper = PYQPaper(
            document_id=doc.id,
            subject_id=subject_id,
            exam_name=exam_name or doc.filename,
            exam_year=exam_year or self._detect_year(doc.filename + " " + full_text[:1000]),
            total_questions=len(raw_blocks),
            processing_status="completed"
        )
        self.db.add(paper)
        self.db.flush()

        topics = self.db.query(Topic).all()
        topic_lookup = {t.name.lower(): t.id for t in topics}

        existing_pyq_qs = self.db.query(PYQQuestion).filter(PYQQuestion.paper_id != paper.id).all()

        total_marks = 0
        topic_counts = {}

        for b in raw_blocks:
            q_text = b["text"]
            marks = b.get("marks", 5)
            total_marks += marks

            # Attempt mapping to topic
            mapped_topic_id = self._match_topic(q_text, topic_lookup)
            if mapped_topic_id:
                topic_counts[mapped_topic_id] = topic_counts.get(mapped_topic_id, 0) + 1

            # Check repetition against older PYQs
            exact_repeats = 0
            similar_ids = []
            for eq in existing_pyq_qs:
                ratio = fuzz.token_sort_ratio(q_text.lower(), eq.question_text.lower())
                if ratio >= 98:
                    exact_repeats += 1
                    similar_ids.append(eq.id)
                elif ratio >= 80:
                    similar_ids.append(eq.id)

            pyq_q = PYQQuestion(
                paper_id=paper.id,
                question_number=b.get("number"),
                question_text=q_text,
                question_type="subjective" if marks > 2 else "objective",
                marks=marks,
                topic_id=mapped_topic_id,
                source_page=b.get("page", 1),
                exact_repeat_count=exact_repeats,
                similar_question_ids=similar_ids if similar_ids else None
            )
            self.db.add(pyq_q)

        paper.total_marks = total_marks

        # Update topic mappings for this paper
        for t_id, count in topic_counts.items():
            tm = PYQTopicMapping(
                paper_id=paper.id,
                topic_id=t_id,
                question_count=count,
                total_marks=count * 5,
                frequency_percent=round((count / max(1, len(raw_blocks))) * 100.0, 2)
            )
            self.db.add(tm)

        self.db.commit()
        return paper

    def get_subject_pyq_summary(self, subject_id: int) -> Dict[str, Any]:
        """Aggregate topic frequencies, repetitions, and yearly trends for a subject.
        Returns clean empty statistics if no PYQs have been uploaded.
        """
        papers = self.db.query(PYQPaper).filter(PYQPaper.subject_id == subject_id).all()
        if not papers:
            return {
                "total_papers": 0,
                "total_questions": 0,
                "years_covered": [],
                "topic_frequencies": [],
                "repeated_questions": 0,
                "has_pyq_data": False,
                "message": "No Previous-Year Question papers uploaded yet for this subject."
            }

        paper_ids = [p.id for p in papers]
        questions = self.db.query(PYQQuestion).filter(PYQQuestion.paper_id.in_(paper_ids)).all()
        years = sorted(list(set(p.exam_year for p in papers if p.exam_year)))

        # Calculate topic frequencies across valid uploaded papers
        total_valid_papers = len(papers)
        mappings = self.db.query(PYQTopicMapping).filter(PYQTopicMapping.paper_id.in_(paper_ids)).all()

        topic_paper_map = {}
        for m in mappings:
            if m.topic_id not in topic_paper_map:
                topic_paper_map[m.topic_id] = {
                    "papers": set(),
                    "total_questions": 0,
                    "total_marks": 0
                }
            topic_paper_map[m.topic_id]["papers"].add(m.paper_id)
            topic_paper_map[m.topic_id]["total_questions"] += m.question_count
            topic_paper_map[m.topic_id]["total_marks"] += m.total_marks

        topic_freq_list = []
        for t_id, data in topic_paper_map.items():
            topic = self.db.query(Topic).filter(Topic.id == t_id).first()
            if topic:
                paper_cnt = len(data["papers"])
                freq_pct = round((paper_cnt / total_valid_papers) * 100.0, 2)
                topic_freq_list.append({
                    "topic_id": t_id,
                    "topic_name": topic.name,
                    "unit_name": topic.unit.name if topic.unit else "General",
                    "paper_count": paper_cnt,
                    "total_papers": total_valid_papers,
                    "frequency_percent": freq_pct,
                    "question_count": data["total_questions"],
                    "total_marks": data["total_marks"]
                })

        topic_freq_list.sort(key=lambda x: x["frequency_percent"], reverse=True)

        repeated_count = sum(1 for q in questions if q.exact_repeat_count > 0 or (q.similar_question_ids and len(q.similar_question_ids) > 0))

        return {
            "total_papers": len(papers),
            "total_questions": len(questions),
            "years_covered": years,
            "topic_frequencies": topic_freq_list,
            "repeated_questions": repeated_count,
            "has_pyq_data": True,
            "message": f"Analyzed {len(papers)} historical papers."
        }

    def _parse_question_blocks(self, text: str) -> List[Dict[str, Any]]:
        """Identify question segments using standard numbered formats."""
        pattern = r'(?:\n|^)(?:Q\.?\s*(\d+[a-z]?)|(\d+)\.|\((\d+)\))\s+(.*?)(?=(?:\n(?:Q\.?\s*\d+|\d+\.|\(\d+\))|\Z))'
        matches = list(re.finditer(pattern, text, re.DOTALL | re.IGNORECASE))
        blocks = []

        for m in matches:
            q_num = m.group(1) or m.group(2) or m.group(3) or str(len(blocks) + 1)
            q_body = m.group(4).strip()
            if len(q_body) < 15:
                continue

            # Extract marks if indicated, e.g., "[5 marks]" or "(10M)"
            marks_match = re.search(r'\[(\d+)\s*(?:marks?|m)\]|\((\d+)\s*(?:marks?|m)\)', q_body, re.IGNORECASE)
            marks = 5
            if marks_match:
                marks = int(marks_match.group(1) or marks_match.group(2))

            blocks.append({
                "number": q_num,
                "text": q_body,
                "marks": marks,
                "page": 1
            })

        if not blocks and text.strip():
            # Fallback: split by lines/paragraphs
            paragraphs = [p.strip() for p in text.split("\n\n") if len(p.strip()) > 30]
            for idx, p in enumerate(paragraphs[:30]):
                blocks.append({
                    "number": str(idx + 1),
                    "text": p,
                    "marks": 5,
                    "page": 1
                })

        return blocks

    def _detect_year(self, text: str) -> Optional[int]:
        years = re.findall(r'\b(20[12]\d)\b', text)
        if years:
            return int(years[0])
        return None

    def _match_topic(self, question_text: str, topic_lookup: Dict[str, int]) -> Optional[int]:
        q_lower = question_text.lower()
        for topic_name, t_id in topic_lookup.items():
            if topic_name in q_lower or fuzz.partial_ratio(topic_name, q_lower) > 85:
                return t_id
        return None
