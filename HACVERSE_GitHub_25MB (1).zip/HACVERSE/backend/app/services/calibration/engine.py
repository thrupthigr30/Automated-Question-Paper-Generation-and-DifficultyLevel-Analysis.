"""Performance-Based Difficulty Calibration and Research Evaluation Engine.
Implements:
1. Observed difficulty calculation from unique student response evidence.
2. Wilson score confidence intervals for proportion of correct responses.
3. Cold-start vs insufficient-data vs performance-calibrated state transitions.
4. Hybrid Bayesian difficulty estimation (AI prior + observation likelihood).
5. Dataset-level psychometric evaluation: Confusion matrix, Weighted Cohen's Kappa, Macro F1, Balanced Accuracy.
6. Question-level agreement determination (correct, overestimated, underestimated).
"""
import math
import logging
from typing import Dict, Any, List, Optional, Tuple
from sqlalchemy.orm import Session
from sqlalchemy import func
from app.models import Question, StudentResponse, DifficultyHistory, DifficultyAssessment, CalibrationRun, CalibrationEvaluation
from app.core.config import settings

logger = logging.getLogger(__name__)


class CalibrationEngine:
    """Manages the calibration lifecycle from student responses to psychometric evaluation."""

    def __init__(self, db: Session):
        self.db = db
        self.min_attempts = settings.MIN_CALIBRATION_ATTEMPTS
        self.easy_threshold = settings.EASY_THRESHOLD_PERCENT  # default 75.0%
        self.hard_threshold = settings.HARD_THRESHOLD_PERCENT  # default 40.0%

    @staticmethod
    def wilson_score_interval(positives: int, total: int, confidence: float = 0.95) -> Tuple[float, float]:
        """Compute Wilson score confidence interval for a binomial proportion."""
        if total <= 0:
            return 0.0, 0.0

        # Standard normal quantile: 1.96 for 95%
        z = 1.95996 if abs(confidence - 0.95) < 0.01 else 1.64485
        p_hat = positives / total
        z2 = z * z
        n = total

        denominator = 1 + z2 / n
        center = (p_hat + z2 / (2 * n)) / denominator
        margin = z * math.sqrt((p_hat * (1 - p_hat) + z2 / (4 * n)) / n) / denominator

        lower = max(0.0, center - margin)
        upper = min(1.0, center + margin)
        return round(lower * 100.0, 2), round(upper * 100.0, 2)

    def calculate_question_performance(self, question_id: int) -> Dict[str, Any]:
        """Aggregate unique student responses for this question (first valid scored attempt per student)."""
        # Fetch responses for this question
        responses = (
            self.db.query(StudentResponse)
            .filter(StudentResponse.question_id == question_id)
            .order_by(StudentResponse.student_id, StudentResponse.submitted_at.asc())
            .all()
        )

        if not responses:
            return {
                "valid_attempts": 0,
                "correct_count": 0,
                "performance_rate": None,
                "confidence_lower": None,
                "confidence_upper": None,
                "observed_level": None,
                "evidence_status": "ai_estimated"
            }

        # Deduplicate to first attempt per student
        seen_students = set()
        first_attempts = []
        for r in responses:
            if r.student_id not in seen_students:
                seen_students.add(r.student_id)
                first_attempts.append(r)

        valid_count = len(first_attempts)
        q = self.db.query(Question).filter(Question.id == question_id).first()
        is_objective = q.question_type in ["mcq", "true_false", "fill_blank", "numerical"] if q else True

        if is_objective:
            correct_count = sum(1 for r in first_attempts if r.is_correct is True)
            rate = (correct_count / valid_count) * 100.0 if valid_count > 0 else 0.0
            ci_lower, ci_upper = self.wilson_score_interval(correct_count, valid_count)
        else:
            # Descriptive: average percentage of marks obtained
            scored = [r for r in first_attempts if r.marks_earned is not None and r.max_marks and r.max_marks > 0]
            if scored:
                rate = sum((r.marks_earned / r.max_marks) * 100.0 for r in scored) / len(scored)
                correct_count = sum(1 for r in scored if (r.marks_earned / r.max_marks) >= 0.5)
            else:
                rate = 0.0
                correct_count = 0
            ci_lower, ci_upper = self.wilson_score_interval(correct_count, valid_count)

        rate = round(rate, 2)

        # Classify observed difficulty from student performance rate
        # High success rate (>75%) = Easy; moderate (40-75%) = Medium; low (<40%) = Hard
        if rate >= self.easy_threshold:
            observed_level = "easy"
        elif rate >= self.hard_threshold:
            observed_level = "medium"
        else:
            observed_level = "hard"

        # Evidence status determination
        if valid_count < self.min_attempts:
            status = "insufficient_data"
        else:
            # Check confidence interval width (uncertainty)
            width = ci_upper - ci_lower
            if width > 45.0:
                status = "low_confidence"
            else:
                status = "performance_calibrated"

        return {
            "valid_attempts": valid_count,
            "correct_count": correct_count,
            "performance_rate": rate,
            "confidence_lower": ci_lower,
            "confidence_upper": ci_upper,
            "observed_level": observed_level,
            "evidence_status": status
        }

    def calibrate_question(self, question: Question) -> Dict[str, Any]:
        """Run calibration update for a single question and record history."""
        perf = self.calculate_question_performance(question.id)

        old_ai = question.ai_difficulty_level
        old_obs = question.observed_difficulty_level
        old_displayed = question.current_difficulty or old_ai

        new_obs = perf["observed_level"]
        status = perf["evidence_status"]

        # Current displayed difficulty rule:
        # If calibrated, use observed; if insufficient, preserve AI estimate
        if status in ["performance_calibrated", "low_confidence"]:
            new_displayed = new_obs
        else:
            new_displayed = old_ai

        # Update question record
        question.observed_difficulty_level = new_obs
        question.observed_difficulty_score = perf["performance_rate"]
        question.current_difficulty = new_displayed
        question.evidence_status = status
        question.valid_attempt_count = perf["valid_attempts"]
        question.confidence_lower = perf["confidence_lower"]
        question.confidence_upper = perf["confidence_upper"]
        question.last_calibration_date = func.now()
        question.calibration_method = "wilson_score_threshold_v1"

        # Add history entry if there is response data
        if perf["valid_attempts"] > 0:
            history = DifficultyHistory(
                question_id=question.id,
                previous_ai_level=old_ai,
                previous_observed_level=old_obs,
                new_observed_level=new_obs,
                previous_displayed=old_displayed,
                new_displayed=new_displayed,
                valid_attempts=perf["valid_attempts"],
                correct_rate=perf["performance_rate"],
                confidence_lower=perf["confidence_lower"],
                confidence_upper=perf["confidence_upper"],
                calibration_method="wilson_score_threshold_v1",
                rule_version="1.0"
            )
            self.db.add(history)

        self.db.commit()
        return perf

    def run_full_calibration(self, subject_id: Optional[int] = None, user_id: Optional[int] = None) -> CalibrationRun:
        """Run batch calibration across all questions, calculate research metrics (Kappa, F1, Accuracy),
        and persist a formal CalibrationRun.
        """
        query = self.db.query(Question)
        if subject_id:
            query = query.filter(Question.subject_id == subject_id)

        questions = query.all()
        total_q = len(questions)

        evaluations_to_add = []
        eligible_count = 0
        correct_preds = 0
        overestimated_count = 0
        underestimated_count = 0

        # Confusion matrix: rows = AI predicted, cols = Observed [easy, medium, hard]
        classes = ["easy", "medium", "hard"]
        matrix = {r: {c: 0 for c in classes} for r in classes}

        y_true = []
        y_pred = []

        for q in questions:
            perf = self.calibrate_question(q)
            if perf["valid_attempts"] >= self.min_attempts and perf["observed_level"]:
                eligible_count += 1
                ai_lvl = (q.ai_difficulty_level or "medium").lower()
                obs_lvl = perf["observed_level"].lower()

                # Determine agreement direction
                # Difficulty order: easy = 1, medium = 2, hard = 3
                level_order = {"easy": 1, "medium": 2, "hard": 3}
                ai_val = level_order.get(ai_lvl, 2)
                obs_val = level_order.get(obs_lvl, 2)

                if ai_val == obs_val:
                    agreement = "correct"
                    correct_preds += 1
                elif ai_val > obs_val:
                    # AI said Hard, but students found it Easy/Medium -> AI overestimated difficulty
                    agreement = "overestimated"
                    overestimated_count += 1
                else:
                    agreement = "underestimated"
                    underestimated_count += 1

                if ai_lvl in matrix and obs_lvl in matrix[ai_lvl]:
                    matrix[ai_lvl][obs_lvl] += 1

                y_pred.append(ai_lvl)
                y_true.append(obs_lvl)

                evaluations_to_add.append({
                    "question_id": q.id,
                    "ai_predicted_level": ai_lvl,
                    "observed_level": obs_lvl,
                    "attempt_count": perf["valid_attempts"],
                    "performance_rate": perf["performance_rate"],
                    "agreement": agreement,
                    "confidence_info": {
                        "lower": perf["confidence_lower"],
                        "upper": perf["confidence_upper"]
                    }
                })

        # Calculate dataset-level agreement metrics using scikit-learn
        overall_acc = None
        balanced_acc = None
        macro_f1 = None
        weighted_kappa = None
        per_class = {}

        if eligible_count >= 3 and len(set(y_true)) > 1:
            try:
                from sklearn.metrics import accuracy_score, balanced_accuracy_score, f1_score, cohen_kappa_score
                overall_acc = round(float(accuracy_score(y_true, y_pred)), 4)
                balanced_acc = round(float(balanced_accuracy_score(y_true, y_pred)), 4)
                macro_f1 = round(float(f1_score(y_true, y_pred, average="macro", zero_division=0)), 4)
                weighted_kappa = round(float(cohen_kappa_score(y_true, y_pred, weights="quadratic")), 4)

                for c in classes:
                    tp = matrix[c][c]
                    pred_c = sum(matrix[c][o] for o in classes)
                    true_c = sum(matrix[p][c] for p in classes)
                    precision = (tp / pred_c) if pred_c > 0 else 0.0
                    recall = (tp / true_c) if true_c > 0 else 0.0
                    per_class[c] = {
                        "precision": round(precision, 4),
                        "recall": round(recall, 4),
                        "sample_count": true_c
                    }
            except Exception as ex:
                logger.warning(f"Error computing calibration metrics: {ex}")
                overall_acc = round(correct_preds / eligible_count, 4) if eligible_count > 0 else 0.0

        # Persist CalibrationRun record
        run = CalibrationRun(
            subject_id=subject_id,
            total_questions=total_q,
            eligible_questions=eligible_count,
            correct_predictions=correct_preds,
            overestimated=overestimated_count,
            underestimated=underestimated_count,
            overall_agreement=overall_acc,
            balanced_accuracy=balanced_acc,
            macro_f1=macro_f1,
            weighted_kappa=weighted_kappa,
            confusion_matrix=matrix,
            per_class_metrics=per_class,
            rule_version="1.0",
            min_attempts_used=self.min_attempts,
            created_by=user_id
        )
        self.db.add(run)
        self.db.flush()

        for ev in evaluations_to_add:
            item = CalibrationEvaluation(
                run_id=run.id,
                question_id=ev["question_id"],
                ai_predicted_level=ev["ai_predicted_level"],
                observed_level=ev["observed_level"],
                attempt_count=ev["attempt_count"],
                performance_rate=ev["performance_rate"],
                agreement=ev["agreement"],
                confidence_info=ev["confidence_info"]
            )
            self.db.add(item)

        self.db.commit()
        return run
