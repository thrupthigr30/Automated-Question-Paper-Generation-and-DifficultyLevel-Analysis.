"""Structured Dataset Management, Import/Export, Quality Auditing, and Synthetic Data Engine.
Manages the 5 core academic datasets:
Dataset A — Academic Content Dataset
Dataset B — Question Dataset
Dataset C — Historical Examination Dataset
Dataset D — Student Performance Dataset (pseudonymized)
Dataset E — Difficulty and Calibration Dataset
"""
import io
import csv
import json
import logging
from typing import List, Dict, Any, Optional, Tuple
from datetime import datetime, timezone
import pandas as pd
from sqlalchemy.orm import Session
from sqlalchemy import func

from app.models import (
    DocumentChunk, Question, PYQQuestion, StudentResponse,
    CalibrationEvaluation, DifficultyHistory, Subject, Unit, Topic, User,
    DatasetImport, DatasetSnapshot
)

logger = logging.getLogger(__name__)


class DatasetManager:
    """Handles structured query, import, export, quality auditing, and test data generation."""

    def __init__(self, db: Session):
        self.db = db

    def get_datasets_summary(self) -> Dict[str, Any]:
        """Return total record counts across all 5 datasets."""
        academic_cnt = self.db.query(func.count(DocumentChunk.id)).scalar() or 0
        questions_cnt = self.db.query(func.count(Question.id)).scalar() or 0
        pyq_cnt = self.db.query(func.count(PYQQuestion.id)).scalar() or 0
        responses_cnt = self.db.query(func.count(StudentResponse.id)).scalar() or 0
        calibration_cnt = self.db.query(func.count(CalibrationEvaluation.id)).scalar() or 0

        # Calculate incomplete question records (missing explanation or answers)
        incomplete_q = (
            self.db.query(func.count(Question.id))
            .filter((Question.correct_answer == None) | (Question.explanation == None))
            .scalar() or 0
        )

        return {
            "academic_content": academic_cnt,
            "questions": questions_cnt,
            "historical_exam": pyq_cnt,
            "student_responses": responses_cnt,
            "calibration_records": calibration_cnt,
            "valid_records": questions_cnt - incomplete_q,
            "incomplete_records": incomplete_q,
            "last_updated": datetime.now(timezone.utc)
        }

    def export_dataset_dataframe(self, dataset_type: str) -> pd.DataFrame:
        """Export dataset as a clean pandas DataFrame with academic headers."""
        d_type = dataset_type.lower().strip()

        # Dataset A — Academic Content
        if d_type in ["academic_content", "academic", "content"]:
            chunks = self.db.query(DocumentChunk).all()
            data = []
            for c in chunks:
                doc = c.document
                data.append({
                    "chunk_id": c.id,
                    "document_id": c.document_id,
                    "document_name": doc.filename if doc else None,
                    "subject_name": doc.subject.name if doc and doc.subject else None,
                    "page_number": c.page_number,
                    "heading": c.heading,
                    "content_text": c.content,
                    "char_count": c.char_count,
                    "extraction_method": c.extraction_method,
                    "data_origin": c.data_origin,
                    "created_at": c.created_at
                })
            return pd.DataFrame(data)

        # Dataset B — Question Dataset
        elif d_type in ["questions", "question", "question_bank"]:
            questions = self.db.query(Question).all()
            data = []
            for q in questions:
                data.append({
                    "question_id": q.id,
                    "subject": q.subject.name if q.subject else None,
                    "unit": q.unit.name if q.unit else None,
                    "topic": q.topic.name if q.topic else None,
                    "question_text": q.question_text,
                    "question_type": q.question_type,
                    "marks": q.marks,
                    "options": json.dumps(q.options) if q.options else None,
                    "correct_answer": q.correct_answer,
                    "explanation": q.explanation,
                    "bloom_level": q.bloom_level,
                    "ai_difficulty_level": q.ai_difficulty_level,
                    "ai_difficulty_score": q.ai_difficulty_score,
                    "observed_difficulty_level": q.observed_difficulty_level,
                    "current_difficulty": q.current_difficulty,
                    "evidence_status": q.evidence_status,
                    "valid_attempts": q.valid_attempt_count,
                    "source_document_id": q.source_document_id,
                    "source_page": q.source_page,
                    "approval_status": q.approval_status,
                    "data_origin": q.data_origin,
                    "created_at": q.created_at
                })
            return pd.DataFrame(data)

        # Dataset C — Historical Examination (PYQ)
        elif d_type in ["pyq", "historical_exam", "pyq_questions"]:
            pyqs = self.db.query(PYQQuestion).all()
            data = []
            for pq in pyqs:
                p = pq.paper
                data.append({
                    "pyq_question_id": pq.id,
                    "paper_name": p.exam_name if p else None,
                    "exam_year": p.exam_year if p else None,
                    "subject": p.subject.name if p and p.subject else None,
                    "question_number": pq.question_number,
                    "question_text": pq.question_text,
                    "marks": pq.marks,
                    "topic": pq.topic.name if pq.topic else None,
                    "source_page": pq.source_page,
                    "exact_repeat_count": pq.exact_repeat_count,
                    "data_origin": pq.data_origin,
                    "created_at": pq.created_at
                })
            return pd.DataFrame(data)

        # Dataset D — Student Performance (Pseudonymized)
        elif d_type in ["student_responses", "performance", "responses"]:
            responses = self.db.query(StudentResponse).all()
            data = []
            for r in responses:
                # Use pseudonymous hash for student ID
                pseudonym = f"STUDENT_{hash(r.student_id) % 10000:04d}"
                data.append({
                    "response_id": r.id,
                    "pseudonymous_student_id": pseudonym,
                    "question_id": r.question_id,
                    "examination_id": r.examination_id,
                    "submitted_answer": r.submitted_answer,
                    "is_correct": r.is_correct,
                    "marks_earned": r.marks_earned,
                    "max_marks": r.max_marks,
                    "time_taken_seconds": r.time_taken_seconds,
                    "attempt_number": r.attempt_number,
                    "evaluation_status": r.evaluation_status,
                    "data_origin": r.data_origin,
                    "submitted_at": r.submitted_at
                })
            return pd.DataFrame(data)

        # Dataset E — Difficulty and Calibration
        elif d_type in ["calibration", "difficulty", "calibration_evaluations"]:
            evals = self.db.query(CalibrationEvaluation).all()
            data = []
            for ev in evals:
                data.append({
                    "evaluation_id": ev.id,
                    "run_id": ev.run_id,
                    "question_id": ev.question_id,
                    "ai_predicted_level": ev.ai_predicted_level,
                    "observed_level": ev.observed_level,
                    "attempt_count": ev.attempt_count,
                    "performance_rate": ev.performance_rate,
                    "agreement": ev.agreement,
                    "confidence_lower": ev.confidence_info.get("lower") if ev.confidence_info else None,
                    "confidence_upper": ev.confidence_info.get("upper") if ev.confidence_info else None,
                    "created_at": ev.created_at
                })
            return pd.DataFrame(data)

        else:
            raise ValueError(f"Unknown dataset type: {dataset_type}")

    def export_as_bytes(self, dataset_type: str, file_format: str = "csv") -> Tuple[bytes, str]:
        """Return exported file content and proper MIME type."""
        df = self.export_dataset_dataframe(dataset_type)
        fmt = file_format.lower().strip()

        if fmt == "csv":
            content = df.to_csv(index=False).encode("utf-8")
            return content, "text/csv"
        elif fmt == "json":
            content = df.to_json(orient="records", date_format="iso", indent=2).encode("utf-8")
            return content, "application/json"
        elif fmt in ["xlsx", "excel"]:
            buf = io.BytesIO()
            df.to_excel(buf, index=False, engine="openpyxl")
            return buf.getvalue(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        else:
            raise ValueError(f"Unsupported export format: {file_format}")

    def generate_synthetic_test_data(self, subject_id: int, user_id: int) -> Dict[str, int]:
        """Generate labeled SYNTHETIC_TEST_DATA for end-to-end testing of calibration lifecycle.
        All generated records are tagged with DataOrigin.SYNTHETIC_TEST_DATA.
        """
        import random

        subject = self.db.query(Subject).filter(Subject.id == subject_id).first()
        if not subject:
            raise ValueError(f"Subject {subject_id} not found.")

        # Create 10 synthetic questions across Easy, Medium, Hard
        question_templates = [
            ("Explain the concept of ACID properties in Database Systems.", "short_answer", 5, "medium", 52.0),
            ("What is the primary key in a relational database?", "mcq", 1, "easy", 25.0),
            ("Differentiate between B-Tree and B+ Tree indexing with complexity diagrams.", "long_answer", 10, "hard", 78.0),
            ("Given relation R(A,B,C,D) with FDs, determine the highest normal form.", "numerical", 5, "hard", 82.0),
            ("State whether SQL is a declarative or procedural query language.", "true_false", 1, "easy", 18.0),
            ("Construct an ER Diagram for an online bookstore management system.", "application", 8, "medium", 60.0),
            ("What does normalization eliminate in database relations?", "mcq", 1, "easy", 28.0),
            ("Analyze the deadlock prevention algorithms in concurrent transactions.", "conceptual", 6, "hard", 75.0),
            ("Write an SQL query using GROUP BY and HAVING clauses to filter sales.", "short_answer", 4, "medium", 48.0),
            ("Define referential integrity constraint with a foreign key example.", "short_answer", 3, "easy", 32.0),
        ]

        created_questions = []
        for text, q_type, marks, diff_lvl, diff_score in question_templates:
            q = Question(
                question_text=f"[SYNTHETIC] {text}",
                subject_id=subject.id,
                question_type=q_type,
                marks=marks,
                correct_answer="Synthetic Model Answer",
                explanation="Detailed synthetic explanation for test scenario.",
                ai_difficulty_level=diff_lvl,
                ai_difficulty_score=diff_score,
                current_difficulty=diff_lvl,
                evidence_status="ai_estimated",
                valid_attempt_count=0,
                approval_status="approved",
                data_origin="synthetic_test_data",
                created_by=user_id
            )
            self.db.add(q)
            self.db.flush()
            created_questions.append(q)

        from app.models import Examination, ExaminationAssignment, ExaminationAttempt

        # Ensure 15 synthetic student accounts exist
        student_ids = []
        for i in range(1, 16):
            s_name = f"synth_student_{i:02d}"
            u = self.db.query(User).filter(User.username == s_name).first()
            if not u:
                u = User(
                    username=s_name,
                    email=f"{s_name}@test.hacverse.edu",
                    full_name=f"Synthetic Student {i}",
                    hashed_password="$2b$12$dummyhashforunauthenticatedsynthuser",
                    role="student"
                )
                self.db.add(u)
                self.db.flush()
            student_ids.append(u.id)

        # Create synthetic examination, assignment, and student attempts
        exam = Examination(
            name="[SYNTHETIC] Diagnostic Benchmark",
            subject_id=subject.id,
            exam_type="practice",
            total_marks=50,
            duration_minutes=60,
            created_by=user_id,
            status="published"
        )
        self.db.add(exam)
        self.db.flush()

        assignment = ExaminationAssignment(
            examination_id=exam.id,
            status="published"
        )
        self.db.add(assignment)
        self.db.flush()

        student_attempts = {}
        for s_id in student_ids:
            att = ExaminationAttempt(
                assignment_id=assignment.id,
                student_id=s_id,
                status="submitted",
                total_marks_possible=50
            )
            self.db.add(att)
            self.db.flush()
            student_attempts[s_id] = att.id

        created_responses_count = 0
        for q in created_questions:
            prob = 0.85 if q.ai_difficulty_level == "easy" else (0.55 if q.ai_difficulty_level == "medium" else 0.30)
            for s_id in student_ids:
                is_correct = random.random() < prob
                resp = StudentResponse(
                    attempt_id=student_attempts[s_id],
                    question_id=q.id,
                    student_id=s_id,
                    examination_id=exam.id,
                    submitted_answer="Option A" if q.question_type == "mcq" else "Synthetic response",
                    is_correct=is_correct,
                    marks_earned=float(q.marks) if is_correct else 0.0,
                    max_marks=q.marks,
                    time_taken_seconds=random.randint(20, 120),
                    attempt_number=1,
                    evaluation_status="auto_evaluated",
                    data_origin="synthetic_test_data"
                )
                self.db.add(resp)
                created_responses_count += 1

        self.db.commit()
        return {
            "questions_created": len(created_questions),
            "responses_created": created_responses_count
        }

    def delete_synthetic_test_data(self) -> Dict[str, int]:
        """Safely remove all records tagged as SYNTHETIC_TEST_DATA."""
        from app.models import (
            Examination, ExaminationAssignment, ExaminationAttempt, ExaminationQuestion,
            CalibrationEvaluation, DifficultyHistory, DifficultyAssessment
        )

        synth_q_ids = [q[0] for q in self.db.query(Question.id).filter(Question.data_origin == "synthetic_test_data").all()]
        if synth_q_ids:
            self.db.query(ExaminationQuestion).filter(ExaminationQuestion.question_id.in_(synth_q_ids)).delete(synchronize_session=False)
            self.db.query(CalibrationEvaluation).filter(CalibrationEvaluation.question_id.in_(synth_q_ids)).delete(synchronize_session=False)
            self.db.query(DifficultyHistory).filter(DifficultyHistory.question_id.in_(synth_q_ids)).delete(synchronize_session=False)
            self.db.query(DifficultyAssessment).filter(DifficultyAssessment.question_id.in_(synth_q_ids)).delete(synchronize_session=False)
            self.db.query(StudentResponse).filter(StudentResponse.question_id.in_(synth_q_ids)).delete(synchronize_session=False)

        deleted_resp = self.db.query(StudentResponse).filter(StudentResponse.data_origin == "synthetic_test_data").delete(synchronize_session=False)
        deleted_q = self.db.query(Question).filter(Question.data_origin == "synthetic_test_data").delete(synchronize_session=False)

        # Delete synthetic exams and assignments
        synth_exams = self.db.query(Examination).filter(Examination.name.like("[SYNTHETIC]%")).all()
        for e in synth_exams:
            self.db.delete(e)

        # Delete synthetic student users and any associated attempts
        synth_user_ids = [u[0] for u in self.db.query(User.id).filter(User.username.like("synth_student_%")).all()]
        if synth_user_ids:
            self.db.query(StudentResponse).filter(StudentResponse.student_id.in_(synth_user_ids)).delete(synchronize_session=False)
            self.db.query(ExaminationAttempt).filter(ExaminationAttempt.student_id.in_(synth_user_ids)).delete(synchronize_session=False)
            self.db.query(ExaminationAssignment).filter(ExaminationAssignment.student_id.in_(synth_user_ids)).delete(synchronize_session=False)
            self.db.query(User).filter(User.id.in_(synth_user_ids)).delete(synchronize_session=False)

        self.db.commit()
        return {
            "deleted_responses": deleted_resp,
            "deleted_questions": deleted_q
        }
