"""Performance Analytics Calculator.
Computes class-level and topic-level score distributions, accuracy rates,
and student engagement metrics.
"""
from typing import Dict, Any, List, Optional
from sqlalchemy.orm import Session
from sqlalchemy import func
from app.models import StudentResponse, ExaminationAttempt, Question, Topic


class PerformanceCalculator:
    """Computes academic performance summaries and drill-down metrics."""

    def __init__(self, db: Session):
        self.db = db

    def get_overall_summary(self, subject_id: Optional[int] = None) -> Dict[str, Any]:
        """Aggregate student attempt counts, overall average score percentage, and response counts."""
        q_filter = self.db.query(StudentResponse)
        if subject_id:
            q_filter = q_filter.join(Question, StudentResponse.question_id == Question.id).filter(Question.subject_id == subject_id)

        total_resp = q_filter.count()
        unique_students = self.db.query(func.count(func.distinct(StudentResponse.student_id))).scalar() or 0
        total_attempts = self.db.query(func.count(ExaminationAttempt.id)).scalar() or 0

        # Average marks percentage
        scored = q_filter.filter(StudentResponse.marks_earned != None, StudentResponse.max_marks > 0).all()
        if scored:
            avg_pct = sum((r.marks_earned / r.max_marks) * 100.0 for r in scored) / len(scored)
        else:
            avg_pct = None

        # Count questions that have response data
        q_with_data = self.db.query(func.count(func.distinct(StudentResponse.question_id))).scalar() or 0

        return {
            "total_attempts": total_attempts,
            "total_responses": total_resp,
            "unique_students": unique_students,
            "avg_score_percent": round(avg_pct, 2) if avg_pct is not None else None,
            "questions_with_data": q_with_data
        }
