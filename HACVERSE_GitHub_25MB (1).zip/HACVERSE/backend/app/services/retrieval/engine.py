"""Academic Content Retrieval Engine.
Retrieves relevant text chunks from uploaded textbooks, syllabi, and reference materials.
Uses lexical BM25/TF-IDF and keyword matching over document chunks.
Grounded citation tracking ensures questions have verifiable source page references.
"""
import re
import math
from typing import List, Dict, Any, Optional
from collections import Counter
from sqlalchemy.orm import Session
from app.models import DocumentChunk, Document


class RetrievalEngine:
    """Retrieves relevant academic chunks for question generation context."""

    def __init__(self, db: Session):
        self.db = db

    def retrieve_context(
        self,
        subject_id: int,
        topic_id: Optional[int] = None,
        document_ids: Optional[List[int]] = None,
        query: Optional[str] = None,
        top_k: int = 5
    ) -> List[Dict[str, Any]]:
        """Retrieve most relevant chunks for the given subject, topic, and optional query."""
        base_query = self.db.query(DocumentChunk).join(Document, DocumentChunk.document_id == Document.id)
        base_query = base_query.filter(Document.subject_id == subject_id)

        if document_ids:
            base_query = base_query.filter(Document.id.in_(document_ids))

        if topic_id:
            # Prefer topic-linked chunks, but fall back to subject-level if few exist
            topic_chunks = base_query.filter(DocumentChunk.topic_id == topic_id).all()
            if len(topic_chunks) >= 3:
                candidates = topic_chunks
            else:
                candidates = base_query.all()
        else:
            candidates = base_query.all()

        if not candidates:
            return []

        if not query:
            # Return first top_k chunks
            selected = candidates[:top_k]
        else:
            # Rank candidates by lexical term overlap (BM25-style scoring)
            scored = []
            tokens = self._tokenize(query)
            for chunk in candidates:
                score = self._score_chunk(chunk.content, tokens)
                scored.append((score, chunk))
            scored.sort(key=lambda x: x[0], reverse=True)
            selected = [chunk for score, chunk in scored[:top_k]]

        results = []
        for c in selected:
            results.append({
                "chunk_id": c.id,
                "document_id": c.document_id,
                "document_name": c.document.filename if c.document else "Unknown",
                "page_number": c.page_number,
                "heading": c.heading,
                "content": c.content,
                "char_count": c.char_count
            })
        return results

    def _tokenize(self, text: str) -> List[str]:
        words = re.findall(r'\b[a-zA-Z0-9_]{3,}\b', text.lower())
        stopwords = {"the", "and", "for", "with", "that", "this", "from", "are", "was", "were", "been", "have"}
        return [w for w in words if w not in stopwords]

    def _score_chunk(self, content: str, query_tokens: List[str]) -> float:
        content_tokens = self._tokenize(content)
        if not content_tokens:
            return 0.0
        counts = Counter(content_tokens)
        score = 0.0
        for token in query_tokens:
            if token in counts:
                tf = counts[token] / len(content_tokens)
                score += (tf * 10.0) + 1.0
        return score
