"""Professional Academic PDF Generation using ReportLab.
Generates:
1. Student Question Paper PDF (formal academic formatting, instructions, numbered questions, mark allocations).
2. Official Answer Key & Solution PDF (separate document, step-by-step explanations, rubrics).
3. Psychometric & Difficulty Calibration Report PDF (agreement metrics, topic coverage, distributions).
"""
import io
import os
from typing import Dict, Any, List, Optional
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.lib.units import inch
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, KeepTogether, HRFlowable
)
from reportlab.pdfgen import canvas


class NumberedCanvas(canvas.Canvas):
    """Adds 'Page X of Y' and confidential headers/footers to all pages."""
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._saved_page_states = []

    def showPage(self):
        self._saved_page_states.append(dict(self.__dict__))
        self._startPage()

    def save(self):
        num_pages = len(self._saved_page_states)
        for state in self._saved_page_states:
            self.__dict__.update(state)
            self.draw_page_number(num_pages)
            super().showPage()
        super().save()

    def draw_page_number(self, page_count):
        self.saveState()
        self.setFont("Helvetica", 9)
        self.setFillColor(colors.HexColor("#64748B"))
        
        # Bottom footer
        page_str = f"Page {self._pageNumber} of {page_count}"
        self.drawRightString(letter[0] - 54, 36, page_str)
        self.drawString(54, 36, "HACVERSE — Evidence-Aware Assessment Platform")
        
        # Header rule
        self.setStrokeColor(colors.HexColor("#CBD5E1"))
        self.setLineWidth(0.5)
        self.line(54, letter[1] - 45, letter[0] - 54, letter[1] - 45)
        self.restoreState()


class PDFGenerator:
    """Produces styled, publication-ready academic assessment PDFs."""

    @classmethod
    def generate_question_paper(
        cls,
        exam_title: str,
        subject_name: str,
        duration_minutes: int,
        total_marks: int,
        instructions: Optional[str],
        sections: List[Dict[str, Any]]
    ) -> bytes:
        """Generate official examination question paper PDF."""
        buffer = io.BytesIO()
        doc = SimpleDocTemplate(
            buffer,
            pagesize=letter,
            leftMargin=54,
            rightMargin=54,
            topMargin=54,
            bottomMargin=54
        )

        styles = getSampleStyleSheet()
        title_style = ParagraphStyle(
            "ExamTitle",
            parent=styles["Normal"],
            fontName="Helvetica-Bold",
            fontSize=16,
            leading=20,
            alignment=1,
            textColor=colors.HexColor("#0F172A")
        )
        sub_style = ParagraphStyle(
            "ExamSub",
            parent=styles["Normal"],
            fontName="Helvetica",
            fontSize=11,
            leading=15,
            alignment=1,
            textColor=colors.HexColor("#334155")
        )
        sec_style = ParagraphStyle(
            "ExamSec",
            parent=styles["Normal"],
            fontName="Helvetica-Bold",
            fontSize=12,
            leading=16,
            textColor=colors.HexColor("#1E293B"),
            spaceBefore=14,
            spaceAfter=6
        )
        q_style = ParagraphStyle(
            "ExamQ",
            parent=styles["Normal"],
            fontName="Helvetica",
            fontSize=10,
            leading=14,
            textColor=colors.HexColor("#0F172A")
        )
        opt_style = ParagraphStyle(
            "ExamOpt",
            parent=styles["Normal"],
            fontName="Helvetica",
            fontSize=9.5,
            leading=13,
            textColor=colors.HexColor("#334155"),
            leftIndent=15
        )

        elements = []

        # Header
        elements.append(Paragraph(exam_title.upper(), title_style))
        elements.append(Paragraph(f"Subject: {subject_name}", sub_style))
        elements.append(Spacer(1, 8))

        # Meta block: Duration & Marks
        meta_data = [
            [
                Paragraph(f"<b>Time Allowed:</b> {duration_minutes} Minutes", styles["Normal"]),
                Paragraph(f"<b>Maximum Marks:</b> {total_marks}", styles["Normal"])
            ]
        ]
        meta_table = Table(meta_data, colWidths=[250, 250])
        meta_table.setStyle(TableStyle([
            ('ALIGN', (0, 0), (0, 0), 'LEFT'),
            ('ALIGN', (1, 0), (1, 0), 'RIGHT'),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 4),
        ]))
        elements.append(meta_table)
        elements.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor("#0F172A"), spaceBefore=4, spaceAfter=8))

        # Instructions
        inst_text = instructions or "1. All questions are compulsory unless specified.\n2. Figures in brackets indicate maximum marks."
        elements.append(Paragraph(f"<b>INSTRUCTIONS:</b><br/>{inst_text.replace(chr(10), '<br/>')}", styles["Normal"]))
        elements.append(Spacer(1, 10))

        # Sections and Questions
        q_num = 1
        for sec in sections:
            sec_name = sec.get("name", "SECTION")
            sec_inst = sec.get("instructions", "")
            elements.append(Paragraph(sec_name.upper(), sec_style))
            if sec_inst:
                elements.append(Paragraph(f"<i>{sec_inst}</i>", styles["Normal"]))
                elements.append(Spacer(1, 4))

            for q in sec.get("questions", []):
                q_text = q.get("text", "")
                marks = q.get("marks", 1)
                options = q.get("options", [])

                # Question row with Marks on the right
                q_cell = Paragraph(f"<b>Q{q_num}.</b> {q_text}", q_style)
                m_cell = Paragraph(f"<b>[{marks}]</b>", ParagraphStyle("Right", parent=q_style, alignment=2))
                q_table = Table([[q_cell, m_cell]], colWidths=[440, 60])
                q_table.setStyle(TableStyle([
                    ('VALIGN', (0, 0), (-1, -1), 'TOP'),
                    ('TOPPADDING', (0, 0), (-1, -1), 4),
                    ('BOTTOMPADDING', (0, 0), (-1, -1), 2),
                ]))

                q_elements = [q_table]

                # Options if MCQ
                if options and isinstance(options, list):
                    for opt in options:
                        if isinstance(opt, dict):
                            opt_line = f"({opt.get('label', '•')}) {opt.get('text', '')}"
                            q_elements.append(Paragraph(opt_line, opt_style))

                q_elements.append(Spacer(1, 8))
                elements.append(KeepTogether(q_elements))
                q_num += 1

        doc.build(elements, canvasmaker=NumberedCanvas)
        return buffer.getvalue()

    @classmethod
    def generate_answer_key(
        cls,
        exam_title: str,
        subject_name: str,
        questions: List[Dict[str, Any]]
    ) -> bytes:
        """Generate official Answer Key and Marking Scheme PDF."""
        buffer = io.BytesIO()
        doc = SimpleDocTemplate(
            buffer,
            pagesize=letter,
            leftMargin=54,
            rightMargin=54,
            topMargin=54,
            bottomMargin=54
        )

        styles = getSampleStyleSheet()
        title_style = ParagraphStyle(
            "KeyTitle",
            parent=styles["Normal"],
            fontName="Helvetica-Bold",
            fontSize=15,
            leading=19,
            alignment=1,
            textColor=colors.HexColor("#0F172A")
        )
        q_header_style = ParagraphStyle(
            "KeyQHeader",
            parent=styles["Normal"],
            fontName="Helvetica-Bold",
            fontSize=11,
            leading=15,
            textColor=colors.HexColor("#1E293B")
        )
        sol_style = ParagraphStyle(
            "KeySol",
            parent=styles["Normal"],
            fontName="Helvetica",
            fontSize=9.5,
            leading=13,
            textColor=colors.HexColor("#0F172A"),
            leftIndent=10
        )

        elements = []
        elements.append(Paragraph(f"OFFICIAL ANSWER KEY & MODEL SOLUTIONS", title_style))
        elements.append(Paragraph(f"Examination: {exam_title} | Subject: {subject_name}", styles["Normal"]))
        elements.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor("#0F172A"), spaceBefore=6, spaceAfter=12))

        for idx, q in enumerate(questions, 1):
            q_text = q.get("text", "")
            ans = q.get("correct_answer", "N/A")
            expl = q.get("explanation", "No detailed explanation provided.")
            rubric = q.get("answer_rubric", "")
            status = q.get("answer_status", "Review Required")
            marks = q.get("marks", 1)

            q_box = [
                Paragraph(f"<b>Question {idx} [{marks} Marks]:</b> {q_text}", q_header_style),
                Spacer(1, 3),
                Paragraph(f"<b>Model Answer / Correct Key:</b> <font color='#16A34A'>{ans}</font>", sol_style),
                Spacer(1, 3),
                Paragraph(f"<b>Detailed Explanation:</b><br/>{expl}", sol_style)
            ]
            if rubric:
                q_box.append(Spacer(1, 3))
                q_box.append(Paragraph(f"<b>Marking Rubric:</b><br/><i>{rubric}</i>", sol_style))

            q_box.append(Paragraph(f"<font size=8 color='#64748B'>Verification Status: {status.upper()}</font>", sol_style))
            q_box.append(HRFlowable(width="100%", thickness=0.5, color=colors.HexColor("#E2E8F0"), spaceBefore=6, spaceAfter=8))
            elements.append(KeepTogether(q_box))

        doc.build(elements, canvasmaker=NumberedCanvas)
        return buffer.getvalue()

    @classmethod
    def generate_analysis_report(
        cls,
        subject_name: str,
        total_questions: int,
        calibrated_count: int,
        stats: Dict[str, Any],
        matrix: Optional[Dict[str, Any]] = None
    ) -> bytes:
        """Generate PDF report summarizing difficulty calibration and predictive validity."""
        buffer = io.BytesIO()
        doc = SimpleDocTemplate(
            buffer,
            pagesize=letter,
            leftMargin=54,
            rightMargin=54,
            topMargin=54,
            bottomMargin=54
        )

        styles = getSampleStyleSheet()
        title_style = ParagraphStyle(
            "ReportTitle",
            parent=styles["Normal"],
            fontName="Helvetica-Bold",
            fontSize=16,
            leading=20,
            alignment=1,
            textColor=colors.HexColor("#0F172A")
        )

        elements = []
        elements.append(Paragraph(f"DIFFICULTY CALIBRATION & PSYCHOMETRIC REPORT", title_style))
        elements.append(Paragraph(f"Subject: {subject_name} | Generated by HACVERSE", styles["Normal"]))
        elements.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor("#0F172A"), spaceBefore=6, spaceAfter=14))

        # Metrics summary table
        data = [
            ["Metric", "Value", "Notes"],
            ["Total Questions in Bank", str(total_questions), "All registered questions"],
            ["Calibrated with Student Evidence", str(calibrated_count), "Met minimum attempt threshold (10+)"],
            ["Overall Predictive Agreement", f"{stats.get('overall_agreement', 0)*100:.1f}%" if stats.get('overall_agreement') is not None else "N/A", "AI vs Real Student Performance"],
            ["Macro F1-Score", f"{stats.get('macro_f1', 0):.3f}" if stats.get('macro_f1') is not None else "N/A", "Balanced across Easy/Medium/Hard"],
            ["Weighted Cohen's Kappa", f"{stats.get('weighted_kappa', 0):.3f}" if stats.get('weighted_kappa') is not None else "N/A", "Inter-rater reliability (AI vs Real)"],
        ]
        t = Table(data, colWidths=[180, 100, 220])
        t.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor("#F1F5F9")),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.HexColor("#0F172A")),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor("#CBD5E1")),
            ('PADDING', (0, 0), (-1, -1), 6),
        ]))
        elements.append(t)
        elements.append(Spacer(1, 16))

        # Methodology text
        methodology = """
        <b>METHODOLOGY & EVIDENCE THRESHOLDS:</b><br/>
        • <b>AI Estimation:</b> Questions initially evaluated along 6 dimensions: Cognitive Demand, Reasoning, Procedural Complexity, Prerequisite Breadth, Application, and Solution Depth.<br/>
        • <b>Observed Calibration:</b> Student responses evaluated after a minimum of 10 unique student attempts.<br/>
        • <b>Wilson Confidence Intervals (95%):</b> Computed for objective response proportions to measure statistical uncertainty.<br/>
        • <b>Data Integrity:</b> Cold-start questions remain strictly marked AI_ESTIMATED until sufficient valid student response evidence is acquired.
        """
        elements.append(Paragraph(methodology, styles["Normal"]))

        doc.build(elements, canvasmaker=NumberedCanvas)
        return buffer.getvalue()
