"""Initial Difficulty Estimation Engine.
Analyses educational and cognitive features:
1. Cognitive demand (mental workload, abstraction)
2. Reasoning complexity (number of inference steps)
3. Procedural complexity (calculations, algorithmic steps)
4. Prerequisite breadth (domain foundations needed)
5. Application complexity (novel/real-world context)
6. Expected solution depth (derivation/explanation breadth)

Calculates composite score, assigns initial level (Easy, Medium, Hard),
and labels question as AI_ESTIMATED (cold-start state).
"""
import logging
from typing import Dict, Any, Optional
from app.core.config import settings

logger = logging.getLogger(__name__)


class DifficultyEstimator:
    """Estimates initial difficulty dimensions and composite score for newly created questions."""

    # Default weights for the 6 cognitive dimensions
    WEIGHTS = {
        "cognitive_demand": 0.20,
        "reasoning_complexity": 0.25,
        "procedural_complexity": 0.15,
        "prerequisite_breadth": 0.15,
        "application_complexity": 0.15,
        "solution_depth": 0.10,
    }

    @classmethod
    def calculate_composite_score(cls, features: Dict[str, float]) -> float:
        """Calculate weighted composite difficulty score on a 0-100 scale.
        Features are rated on a 1.0 - 5.0 scale.
        """
        weighted_sum = 0.0
        total_weight = 0.0

        for dim, weight in cls.WEIGHTS.items():
            val = float(features.get(dim, 2.5))
            val = max(1.0, min(5.0, val))
            weighted_sum += val * weight
            total_weight += weight

        # Normalize 1.0-5.0 to 0-100 scale: (weighted_avg - 1.0) / 4.0 * 100
        weighted_avg = weighted_sum / max(0.01, total_weight)
        score = ((weighted_avg - 1.0) / 4.0) * 100.0
        return round(max(0.0, min(100.0, score)), 2)

    @classmethod
    def classify_difficulty(cls, score: float) -> str:
        """Classify into Easy, Medium, or Hard based on configurable score ranges."""
        # Using settings thresholds: score >= 65 -> hard, score >= 35 -> medium, else easy
        if score >= 65.0:
            return "hard"
        elif score >= 35.0:
            return "medium"
        else:
            return "easy"

    @classmethod
    def create_assessment_dict(
        cls,
        features: Dict[str, float],
        bloom_level: str = "understand",
        reasoning: str = "",
        model_id: str = "ai_rule_engine",
        rubric_version: str = "v1.0"
    ) -> Dict[str, Any]:
        """Produce a complete difficulty assessment record dictionary."""
        score = cls.calculate_composite_score(features)
        level = cls.classify_difficulty(score)

        return {
            "assessment_type": "ai_initial",
            "difficulty_level": level,
            "difficulty_score": score,
            "cognitive_demand": round(float(features.get("cognitive_demand", 2.5)), 2),
            "reasoning_complexity": round(float(features.get("reasoning_complexity", 2.5)), 2),
            "procedural_complexity": round(float(features.get("procedural_complexity", 2.5)), 2),
            "prerequisite_breadth": round(float(features.get("prerequisite_breadth", 2.5)), 2),
            "application_complexity": round(float(features.get("application_complexity", 2.5)), 2),
            "solution_depth": round(float(features.get("solution_depth", 2.5)), 2),
            "bloom_level": bloom_level,
            "reasoning": reasoning or f"Initial AI estimate based on cognitive demand ({features.get('cognitive_demand', 2.5)}) and reasoning ({features.get('reasoning_complexity', 2.5)}).",
            "model_id": model_id,
            "rubric_version": rubric_version,
            "evidence_status": "ai_estimated"
        }
