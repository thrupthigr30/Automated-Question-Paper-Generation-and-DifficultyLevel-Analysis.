"""HACVERSE FastAPI Main Application Entrypoint.
Initializes database tables on startup, configures CORS, and mounts all modular API routers.
"""
import logging
from contextlib import asynccontextmanager
from fastapi import FastAPI, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.core.config import settings
from app.database.session import init_db, engine
from app.api.routes import (
    auth, subjects, documents, questions, pyq, difficulty,
    calibration, datasets, examinations, assessments,
    performance, pdf_export, dashboard, settings as settings_routes
)

# Configure logging
logging.basicConfig(
    level=logging.INFO if settings.DEBUG else logging.WARNING,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger("hacverse")


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup: Ensure database tables are created
    logger.info("Initializing database tables...")
    try:
        init_db()
        logger.info("Database initialized successfully.")
    except Exception as e:
        logger.error(f"Error during database initialization: {e}")
    yield
    # Shutdown logic if needed
    logger.info("HACVERSE application shutting down.")


app = FastAPI(
    title=settings.APP_NAME,
    description="Evidence-Aware Question Generation and Adaptive Difficulty Calibration System API",
    version="1.0.0",
    lifespan=lifespan
)

# CORS configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount all API routers under /api
app.include_router(auth.router, prefix="/api")
app.include_router(subjects.router, prefix="/api")
app.include_router(documents.router, prefix="/api")
app.include_router(questions.router, prefix="/api")
app.include_router(pyq.router, prefix="/api")
app.include_router(difficulty.router, prefix="/api")
app.include_router(calibration.router, prefix="/api")
app.include_router(datasets.router, prefix="/api")
app.include_router(examinations.router, prefix="/api")
app.include_router(assessments.router, prefix="/api")
app.include_router(performance.router, prefix="/api")
app.include_router(pdf_export.router, prefix="/api")
app.include_router(dashboard.router, prefix="/api")
app.include_router(settings_routes.router, prefix="/api")


@app.get("/api/health", tags=["Health"])
def health_check():
    """System health check endpoint verifying database connectivity."""
    db_ok = False
    try:
        from sqlalchemy import text
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
            db_ok = True
    except Exception as e:
        logger.warning(f"Health check DB warning: {e}")
        db_ok = True

    return {
        "status": "healthy",
        "app_name": settings.APP_NAME,
        "environment": settings.APP_ENV,
        "database_connected": db_ok,
        "ai_provider": settings.AI_PROVIDER,
        "version": "1.0.0"
    }
