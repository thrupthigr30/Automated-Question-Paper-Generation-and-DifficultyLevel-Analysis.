"""Direct test runner to verify API endpoints and business logic."""
import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def run():
    print("1. Testing Health...")
    r = client.get("/api/health")
    assert r.status_code == 200, f"Health failed: {r.text}"
    print("   -> Health OK:", r.json())

    print("2. Testing Login Admin...")
    r = client.post("/api/auth/login", data={"username": "admin", "password": "admin1234"})
    assert r.status_code == 200, f"Admin login failed: {r.text}"
    admin_token = r.json()["access_token"]
    print("   -> Admin Login OK, token received")

    print("3. Testing Login Teacher...")
    r = client.post("/api/auth/login", data={"username": "teacher", "password": "teacher1234"})
    assert r.status_code == 200, f"Teacher login failed: {r.text}"
    teacher_token = r.json()["access_token"]
    headers = {"Authorization": f"Bearer {teacher_token}"}
    print("   -> Teacher Login OK")

    print("4. Testing Subject Creation...")
    r = client.post(
        "/api/subjects",
        json={"name": "Database Management Systems", "code": "CS301", "description": "Relational databases and transactions."},
        headers=headers
    )
    if r.status_code == 201:
        subj = r.json()
        print(f"   -> Subject Created: ID {subj['id']}, Name: {subj['name']}")
    elif r.status_code == 400:
        print("   -> Subject already exists, fetching existing...")
        r2 = client.get("/api/subjects", headers=headers)
        subj = r2.json()[0]
        print(f"   -> Existing Subject: ID {subj['id']}, Name: {subj['name']}")
    else:
        assert False, f"Unexpected status: {r.status_code}, {r.text}"

    print("5. Testing Unit and Topic Creation...")
    r_unit = client.post(
        "/api/subjects/units",
        json={"name": "Relational Data Model & SQL", "unit_number": 1, "description": "Basics of relational algebra", "subject_id": subj["id"]},
        headers=headers
    )
    if r_unit.status_code in [200, 201]:
        unit = r_unit.json()
        print(f"   -> Unit Created or Exists: ID {unit['id']}")
        r_topic = client.post(
            "/api/subjects/topics",
            json={"name": "Relational Algebra", "unit_id": unit["id"], "description": "Selection, projection, joins"},
            headers=headers
        )
        assert r_topic.status_code in [200, 201]
        topic = r_topic.json()
        print(f"   -> Topic Created or Exists: ID {topic['id']}")
    else:
        print(f"   -> Unit error: {r_unit.status_code}, {r_unit.text}")

    print("6. Testing Manual Question Creation & Cold-Start Status...")
    r_q = client.post(
        "/api/questions/create",
        json={
            "question_text": "What is the primary role of the Write-Ahead Logging (WAL) protocol in DBMS?",
            "subject_id": subj["id"],
            "question_type": "short_answer",
            "marks": 4,
            "correct_answer": "Ensures atomicity and durability by writing log records to non-volatile storage before applying changes to database pages.",
            "explanation": "WAL guarantees ACID durability during system crashes."
        },
        headers=headers
    )
    assert r_q.status_code == 201, f"Question create failed: {r_q.text}"
    q = r_q.json()
    print(f"   -> Question Created: ID {q['id']}")
    print(f"   -> Evidence Status: {q['evidence_status']} (Should be 'ai_estimated')")
    print(f"   -> Valid Attempts: {q['valid_attempt_count']} (Should be 0)")
    assert q["evidence_status"] == "ai_estimated"
    assert q["valid_attempt_count"] == 0

    print("7. Testing Examination Creation & Paper Assembly...")
    r_exam = client.post(
        "/api/examinations",
        json={
            "name": "DBMS Mid-Term Examination",
            "subject_id": subj["id"],
            "exam_type": "mock",
            "total_marks": 20,
            "duration_minutes": 60,
            "instructions": "Answer all questions. Calculator not allowed.",
            "easy_percent": 30.0,
            "medium_percent": 40.0,
            "hard_percent": 30.0
        },
        headers=headers
    )
    assert r_exam.status_code == 201, f"Exam create failed: {r_exam.text}"
    exam = r_exam.json()
    print(f"   -> Examination Created: ID {exam['id']}, Name: {exam['name']}")

    print("8. Testing PDF Export for Question Paper...")
    r_pdf = client.get(f"/api/examinations/{exam['id']}/question-paper.pdf", headers=headers)
    assert r_pdf.status_code == 200, f"Question paper PDF failed: {r_pdf.status_code}"
    assert len(r_pdf.content) > 500
    print(f"   -> Question Paper PDF Generated successfully! Size: {len(r_pdf.content)} bytes")

    print("9. Testing PDF Export for Answer Key...")
    r_key_pdf = client.get(f"/api/examinations/{exam['id']}/answer-key.pdf", headers=headers)
    assert r_key_pdf.status_code == 200
    assert len(r_key_pdf.content) > 500
    print(f"   -> Answer Key PDF Generated successfully! Size: {len(r_key_pdf.content)} bytes")

    print("10. Testing Datasets Summary & Export...")
    r_ds = client.get("/api/datasets/summary", headers=headers)
    assert r_ds.status_code == 200
    ds = r_ds.json()
    print(f"   -> Datasets Summary: {ds}")

    r_exp = client.get("/api/datasets/export?type=questions&format=csv", headers=headers)
    assert r_exp.status_code == 200
    assert "question_id" in r_exp.text
    print(f"   -> CSV Export OK, rows exported: {len(r_exp.text.splitlines())}")

    print("11. Testing Synthetic Test Data Generation and Cleanup...")
    r_synth = client.post(f"/api/datasets/synthetic?subject_id={subj['id']}", headers=headers)
    assert r_synth.status_code == 201
    synth_res = r_synth.json()
    print(f"   -> Synthetic Data Generated: {synth_res['details']}")

    print("12. Testing Difficulty Calibration Calculation with Student Evidence...")
    r_calib = client.post(f"/api/calibration/run?subject_id={subj['id']}", headers=headers)
    assert r_calib.status_code == 200
    calib = r_calib.json()
    print(f"   -> Calibration Run complete! Eligible questions: {calib['eligible_questions']}, Correct preds: {calib['correct_predictions']}")

    # Clean up synthetic data
    r_clean = client.delete("/api/datasets/synthetic", headers=headers)
    assert r_clean.status_code == 200
    print(f"   -> Synthetic data cleaned up: {r_clean.json()['details']}")

    print("\n==========================================")
    print("ALL BACKEND INTEGRATION TESTS PASSED 100%!")
    print("==========================================")


if __name__ == "__main__":
    run()
