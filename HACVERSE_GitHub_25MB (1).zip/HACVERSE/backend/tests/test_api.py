"""Backend API Integration Tests.
Tests:
1. Health endpoint
2. Authentication (login with seeded admin/teacher/student, token generation)
3. Subject & syllabus creation and persistence
4. Question creation and cold-start difficulty verification (AI_ESTIMATED)
5. Document upload and processing pipeline
6. Calibration engine with mock response evidence
"""
import pytest
from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)


def test_health_check():
    response = client.get("/api/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "healthy"
    assert data["app_name"] == "HACVERSE"


def test_auth_login_admin():
    response = client.post(
        "/api/auth/login",
        data={"username": "admin", "password": "admin1234"}
    )
    assert response.status_code == 200
    data = response.json()
    assert "access_token" in data
    assert data["user"]["role"] == "admin"


def test_auth_login_teacher():
    response = client.post(
        "/api/auth/login",
        data={"username": "teacher", "password": "teacher1234"}
    )
    assert response.status_code == 200
    data = response.json()
    assert "access_token" in data
    assert data["user"]["role"] == "teacher"


def test_subject_lifecycle():
    # Login as teacher
    login_res = client.post("/api/auth/login", data={"username": "teacher", "password": "teacher1234"})
    token = login_res.json()["access_token"]
    headers = {"Authorization": f"Bearer {token}"}

    # Create subject
    subj_res = client.post(
        "/api/subjects",
        json={"name": "Database Management Systems", "code": "CS301", "description": "Relational databases and transactions."},
        headers=headers
    )
    assert subj_res.status_code in [201, 400]  # 400 if already created in earlier test run

    # List subjects
    list_res = client.get("/api/subjects", headers=headers)
    assert list_res.status_code == 200
    subjects = list_res.json()
    assert len(subjects) >= 1


def test_cold_start_question_difficulty():
    login_res = client.post("/api/auth/login", data={"username": "teacher", "password": "teacher1234"})
    token = login_res.json()["access_token"]
    headers = {"Authorization": f"Bearer {token}"}

    # Fetch first subject
    subj = client.get("/api/subjects", headers=headers).json()[0]

    # Create manual question
    q_res = client.post(
        "/api/questions/create",
        json={
            "question_text": "What is the function of the Write-Ahead Logging (WAL) protocol?",
            "subject_id": subj["id"],
            "question_type": "short_answer",
            "marks": 4,
            "correct_answer": "Ensures atomicity and durability by writing log records before data changes.",
            "explanation": "WAL guarantees ACID durability."
        },
        headers=headers
    )
    assert q_res.status_code == 201
    q_data = q_res.json()

    # Verify cold start status: AI_ESTIMATED, 0 attempts, NOT calibrated
    assert q_data["evidence_status"] == "ai_estimated"
    assert q_data["valid_attempt_count"] == 0
    assert q_data["observed_difficulty_level"] is None
