"""CLI utility to seed initial administrator and faculty accounts."""
import sys
import os

# Ensure backend directory is in sys.path
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))

from app.database.session import SessionLocal, init_db
from app.models import User
from app.core.security import hash_password


def seed_users():
    init_db()
    db = SessionLocal()
    try:
        # 1. Admin
        admin = db.query(User).filter(User.username == "admin").first()
        if not admin:
            admin = User(
                username="admin",
                email="admin@hacverse.edu",
                full_name="System Administrator",
                hashed_password=hash_password("admin1234"),
                role="admin",
                is_active=True
            )
            db.add(admin)
            print("Created Admin user: admin / admin1234")

        # 2. Teacher
        teacher = db.query(User).filter(User.username == "teacher").first()
        if not teacher:
            teacher = User(
                username="teacher",
                email="faculty@hacverse.edu",
                full_name="Prof. Sarah Jenkins",
                hashed_password=hash_password("teacher1234"),
                role="teacher",
                is_active=True
            )
            db.add(teacher)
            print("Created Teacher user: teacher / teacher1234")

        # 3. Student
        student = db.query(User).filter(User.username == "student").first()
        if not student:
            student = User(
                username="student",
                email="student@hacverse.edu",
                full_name="Alex Mercer",
                hashed_password=hash_password("student1234"),
                role="student",
                is_active=True
            )
            db.add(student)
            print("Created Student user: student / student1234")

        db.commit()
        print("Initial users seeded successfully.")
    except Exception as e:
        db.rollback()
        print(f"Error seeding users: {e}")
    finally:
        db.close()


if __name__ == "__main__":
    seed_users()
