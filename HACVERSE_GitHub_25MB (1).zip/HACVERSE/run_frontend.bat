@echo off
title HACVERSE - Frontend Server
echo Starting HACVERSE Frontend on http://localhost:5173...
set "PATH=%~dp0tools\node-v20.18.1-win-x64;%PATH%"
cd /d "%~dp0frontend"
call npm run dev
pause
