@echo off
title HACVERSE - Backend Server
echo Starting HACVERSE Backend on http://127.0.0.1:8000...
cd /d "%~dp0backend"
"D:\Anaconda\python.exe" -m uvicorn app.main:app --host 127.0.0.1 --port 8000 --reload
pause
