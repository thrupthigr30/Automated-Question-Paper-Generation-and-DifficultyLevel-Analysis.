# HACVERSE — Evidence-Aware Question Generation and Adaptive Difficulty Calibration System

An intelligent assessment platform that generates syllabus-aligned questions, estimates initial cognitive difficulty, and refines estimates using empirical student performance data with rigorous statistical calibration.

---

## 1. System Architecture & Core Innovation

Most AI assessment tools simply generate questions and assign arbitrary "Easy", "Medium", or "Hard" labels that never change.

**HACVERSE solves the fundamental gap between AI prediction and real student performance:**
1. **Evidence-Grounded Ingestion**: Textbooks, lecture notes, and syllabi (PDF, DOCX, TXT) are extracted and chunked with token indexing.
2. **Multi-Provider AI Generation**: Decoupled AI generation architecture supporting **Google Gemini** (via official `google-genai`), **OpenAI**, **Anthropic Claude**, **Groq**, **OpenRouter**, and **Local Ollama**.
3. **Cold-Start 6-Dimensional Cognitive Vector**: Every newly synthesized item is evaluated across 6 cognitive dimensions:
   - *Conceptual Complexity* ($w_1 = 0.25$)
   - *Computational Steps* ($w_2 = 0.20$)
   - *Analytical Depth* ($w_3 = 0.20$)
   - *Retrieval Dependency* ($w_4 = 0.15$)
   - *Linguistic Complexity* ($w_5 = 0.10$)
   - *Novelty / Transfer Ratio* ($w_6 = 0.10$)
   - Combined Composite Score ($0 - 100$) mapped to `EASY`, `MEDIUM`, or `HARD` with initial status `AI_ESTIMATED`.
4. **Empirical Performance Collection**: When students take examinations, unique candidates' attempts are recorded in the relational database.
5. **Wilson Score 95% Confidence Interval Calibration**: Once an item has $\ge 10$ unique student attempts, the calibration engine transitions the item to `CALIBRATED` using the Wilson score interval:
   $$\hat{p} = \frac{n_{\text{correct}} + \frac{z^2}{2}}{n + z^2} \pm \frac{z}{n + z^2}\sqrt{\frac{n_{\text{correct}}(n - n_{\text{correct}})}{n} + \frac{z^2}{4}}$$
6. **Psychometric Research & Evaluation**: Continuous tracking of prediction accuracy, **Weighted Cohen's Kappa ($\kappa$)**, **Balanced Accuracy**, **Macro F1**, and a live **$3 \times 3$ Confusion Matrix**.
7. **Publication-Ready PDF Generation**: Custom ReportLab engine producing official **Student Question Papers** (without answers), **Marking Schemes & Solutions**, and **Psychometric Calibration Reports**.
8. **5 Mandatory Relational Datasets**: Comprehensive tabular data export (CSV, JSON, Excel) and synthetic cohort simulation for empirical benchmarking.

---

## 2. Technology Stack

- **Backend**: Python 3.11+ / 3.13, FastAPI, SQLAlchemy 2.0, Pydantic v2, ReportLab, scikit-learn, RapidFuzz, PyMuPDF.
- **Frontend**: React 18, TypeScript, Vite, Tailwind CSS, Lucide Icons, Recharts, Axios.
- **Database**: SQLite with Write-Ahead Logging (WAL) and foreign key enforcement (PostgreSQL compatible).
- **AI Integrations**: Google Gemini (`google-genai`), OpenAI (`openai`), Anthropic (`anthropic`), Groq, OpenRouter, and Ollama.

---

## 3. Quick Start & Local Execution

### Pre-requisites
- Python 3.11+ (Python 3.13 tested)
- Node.js 18+ (Node v20.18 included in `tools/node-v20.18.1-win-x64`)

### Setup Database & Admin Seed Accounts
```powershell
# In the project root directory
& "D:\Anaconda\python.exe" backend/create_admin.py
```
This initializes the database schema and creates three default users:
- **Administrator**: `admin` / `admin1234`
- **Teacher**: `teacher` / `teacher1234`
- **Student**: `student` / `student1234`

### Run Backend API Server
```powershell
# Using the PowerShell runner script:
.\run_backend.ps1

# Or manually:
cd backend
& "D:\Anaconda\python.exe" -m uvicorn app.main:app --host 127.0.0.1 --port 8000 --reload
```
- API Base URL: `http://127.0.0.1:8000`
- Interactive OpenAPI Docs: `http://127.0.0.1:8000/docs`

### Run Frontend Development Server
```powershell
# Using the PowerShell runner script:
.\run_frontend.ps1

# Or manually:
cd frontend
$env:PATH = "$PSScriptRoot\tools\node-v20.18.1-win-x64;" + $env:PATH
npm run dev
```
- Frontend Web App: `http://localhost:5173`

### Run Automated Test Suite
```powershell
& "D:\Anaconda\python.exe" backend/tests/run_tests.py
```
*Executes all 10 integration tests: Health check, multi-role auth, syllabus tree creation, cold-start question difficulty verification, exam assembly, ReportLab PDF generation, dataset export, synthetic student simulation, and Wilson score calibration.*

---

## 4. Platform Navigation & Features

| Feature Module | Route | Key Capabilities |
| :--- | :--- | :--- |
| **Dashboard** | `/dashboard` | System KPIs, AI vs Observed difficulty distribution charts, live audit log. |
| **Subjects & Syllabus** | `/subjects` | Curriculum tree: Subjects, Units, and Topics management. |
| **Academic Resources** | `/documents` | Ingest PDF, DOCX, TXT; chunk inspector, token indexing. |
| **Question Bank** | `/questions` | Search/filter repository, 6-D cognitive inspector, approval workflow. |
| **Generate Questions** | `/generate` | Grounded AI synthesis, duplicate detection, initial cold-start scoring. |
| **PYQ Analysis** | `/pyq` | Historical examination paper parsing, topic weightage, question repetition. |
| **Structured Datasets** | `/datasets` | 5 relational datasets preview & export (CSV/JSON/XLSX), synthetic data generator. |
| **Examinations** | `/examinations` | Multi-section paper assembly with target difficulty ratio (e.g. 30/40/30). |
| **Student Assessments** | `/assessments` | Candidate exam-taking UI, automated objective scoring, timed sessions. |
| **Difficulty Calibration** | `/difficulty` | Wilson score engine, Cohen's Kappa, 3x3 confusion matrix, manual override. |
| **Performance Analytics**| `/performance` | Cohort accuracy, Bloom's taxonomy performance, topic mastery. |
| **Reports** | `/reports` | One-click ReportLab PDF downloads (Question Paper, Answer Key, Psychometrics). |
| **Settings** | `/settings` | Multi-provider selector (Gemini/OpenAI/Claude/Groq/Ollama), threshold calibration. |

---

## 5. Difficulty Lifecycle Specifications

```
  [ Academic Content ]
           │
           ▼
[ Grounded AI Generation ] ───► [ 6-Dimensional Cognitive Scoring ]
                                                │
                                                ▼
                                    Status: AI_ESTIMATED
                                 (Cold-start item label)
                                                │
                                                ▼
                                    [ Student Assessments ]
                               (Unique candidate attempts)
                                                │
                         Attempts < 10          │          Attempts >= 10
                       ┌────────────────────────┴────────────────────────┐
                       ▼                                                 ▼
             INSUFFICIENT_DATA                                  [ Wilson 95% CI ]
             (Keep estimate)                                             │
                                                                         ▼
                                                                Status: CALIBRATED
                                                            (Real observed difficulty)
                                                                         │
                                                                         ▼
                                                             [ Faculty Review / Override ]
```

---

## 6. Security and Compliance
- Password hashing with bcrypt.
- JWT bearer token authentication with role-based access control (Admin, Teacher, Student).
- Isolated API key storage via server environment variables (`.env`).
- Full audit logging of all administrative actions in SQLite `activity_logs`.
